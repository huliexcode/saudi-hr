/* HR integrity engine 2026-10-05. Pure calculations, shared by the UI and tests. */
const HRIntegrity = (() => {
    'use strict';
    const D = 86400000, money = n => {
        n=Number(n);if(!Number.isFinite(n))return NaN;
        const stable=Number(Math.abs(n).toFixed(8));return Math.sign(n)*Math.round(Number(String(stable)+'e2'))/100;
    };
    const validNumber = v => (typeof v === 'number' || typeof v === 'string' && v.trim() !== '') && Number.isFinite(Number(v));
    const number = (v, label, errors, fallback = 0) => {
        if (!validNumber(v) || Number(v) < 0 || Number(v)>1000000000) { errors.push(label + ' غير صالح'); return fallback; }
        return Number(v);
    };
    const iso = d => d.toISOString().slice(0, 10);
    const parse = v => HRCore.date(v);
    const today = (now = new Date()) => {
        const p = new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Riyadh', year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now);
        const v = t => p.find(x => x.type === t).value;
        return `${v('year')}-${v('month')}-${v('day')}`;
    };
    const anniversary = (d, years = 1) => {
        const y = d.getUTCFullYear() + years, m = d.getUTCMonth();
        return new Date(Date.UTC(y, m, Math.min(d.getUTCDate(), new Date(Date.UTC(y,m+1,0)).getUTCDate())));
    };
    const approved = o => !['stopped','cancelled','rejected'].includes(o.status) &&
        ['approved','authorized','completed'].includes(o.data?.flow?.state);
    function isSaudi(value) {
        const s=String(value||'').normalize('NFKC').toLowerCase().replace(/[\s\u064B-\u0652\u0640-]/g,'').replace(/ى/g,'ي');
        return !/غير|non/.test(s)&&/^(سعودية?|السعودية|المملكةالعربيةالسعودية|saudi(?:arabia)?|ksa|sa)$/.test(s);
    }
    function ibanValid(value) {
        const s = String(value || '').replace(/\s+/g,'').toUpperCase();
        if (!/^SA\d{22}$/.test(s)) return false;
        const digits = s.slice(4) + '2810' + s.slice(2,4);
        let remainder = 0;
        for (const c of digits) remainder = (remainder * 10 + Number(c)) % 97;
        return remainder === 1;
    }
    function gosiRate(asOf, isNew, saudi) {
        if (!saudi) return {emp:0, co:2};
        let step = 0;
        if (isNew) for (const d of ['2025-07-01','2026-07-01','2027-07-01','2028-07-01']) if (asOf >= d) step++;
        return {emp:9.75 + step*.5, co:11.75 + step*.5};
    }
    function gosiFactor(start, end, month, isNew) {
        const s = HRCore.servicePeriod(start,end,month);
        return isNew ? s.ratio : (HRCore.gosiDue(start,end,month) ? 1 : 0);
    }
    function compensation(emp, month) {
        const c=typeof HRContracts!=='undefined'&&HRContracts.active(emp,month+'-01');if(c)return {...emp,financials:{...c.financials},compensationVersion:'contract:'+c.id};
        const rows = [...(emp.compensationHistory || [])].filter(x => x.effective_from <= month + '-01')
            .sort((a,b) => b.effective_from.localeCompare(a.effective_from));
        const v = rows[0];
        if (v) return {...emp,financials:{...v.financials},gosiStatus:v.gosi_status || emp.gosiStatus,compensationVersion:v.id};
        return {...emp,financials:{...emp.financials},compensationVersion:null};
    }
    function requestDays(requests, employeeId, errors) {
        const days = new Map();
        const rows = requests.filter(r => r.employee_id === employeeId && r.request_type === 'leave' && r.status === 'approved')
            .sort((a,b) => String(a.date_from).localeCompare(String(b.date_from)));
        for (const r of rows) {
            const a = parse(r.date_from), b = parse(r.date_to || r.date_from);
            const count = a && b ? (b-a)/D + 1 : 0;
            if (!a || !b || b < a || count > 3660 || !Number.isInteger(Number(r.days)) || Number(r.days) !== count) {
                errors.push('تواريخ/عدد أيام الإجازة غير متطابقة: ' + (r.id || r.sub_type || '')); continue;
            }
            for (let d = a; d <= b; d = new Date(+d + D)) {
                const key = iso(d);
                if (days.has(key)) errors.push('إجازتان معتمدتان متداخلتان في ' + key);
                else days.set(key,r);
            }
        }
        return days;
    }
    function leavePayroll(requests, emp, service, unpaidNames) {
        const errors=[], dates = requestDays(requests,emp.id,errors), reductions=[];
        let anchor=null, sickCount=0, lost=0, count=0,lostMoney=0;
        const isUnpaid = r => unpaidNames.includes(r.sub_type) || /غير مدفوعة|دون أجر|بدون أجر/.test(r.sub_type || '');
        for (const [key,r] of [...dates].sort(([a],[b])=>a.localeCompare(b))) {
            const d=parse(key); let fraction=0;
            const contract=typeof HRContracts!=='undefined'&&HRContracts.active(emp,key), cp=contract&&HRContracts.policy(contract,emp,key);
            if(cp?.unit) continue;
            if(cp&&!cp.sick&&/مرض/.test(r.sub_type||'')){errors.push('المرضية تحتاج ميزة تعاقدية موثقة لهذا النوع');continue;}
            if(cp&&!cp.annual&&/سنوي/.test(r.sub_type||'')){errors.push('الإجازة السنوية خارج استحقاق العقد');continue;}
            if (isUnpaid(r)) fraction=1;
            else if (/مرض/.test(r.sub_type || '')) {
                if (!anchor || d >= anniversary(anchor)) {anchor=d;sickCount=0;}
                sickCount++;
                fraction=sickCount<=30 ? 0 : sickCount<=90 ? .25 : 1;
                if (sickCount>120 && key.slice(0,7)===iso(service.first).slice(0,7)) errors.push('المرضية تتجاوز 120 يومًا في سنة الاستحقاق؛ راجع القرار');
            }
            if (service.eligible && d>=service.from && d<=service.to) {
                count++; lost+=fraction;if(contract)lostMoney+=Number(contract.financials.total)/30*fraction;
                if(fraction) reductions.push({date:key,fraction,request_id:r.id||null,reason:r.sub_type});
            }
        }
        // Whole unpaid calendar months have zero earned wage even in February.
        if(lost===service.calendarDays&&service.calendarDays>0)lostMoney=null;
        if (lost === service.calendarDays && service.calendarDays>0) lost=service.payDays;
        return {errors:[...new Set(errors)],lostDays:Math.min(service.payDays,lost),lostMoney:emp.contracts?.length?lostMoney:null,reductions,dates,count};
    }
    function payroll(ctx) {
        const {month,modules} = ctx, original=ctx.emp, emp=compensation(original,month), f=emp.financials||{};
        const cb=typeof HRContracts!=='undefined'?HRContracts.monthBase(original,month,ctx.end,{requests:ctx.requests||[]}):null;
        const service=cb&&!cb.legacy?cb.service:HRCore.servicePeriod(parse(emp.startDate),ctx.end ? parse(ctx.end) : null,month);
        const registered=cb&&!cb.legacy;
        if(registered){for(const k of ['basic','housing','transport','other'])f[k]=service.ratio?cb.components[k]/service.ratio:0;f.total=cb.monthlyTotal;}
        const errors=[...service.errors,...(ctx.loadErrors||[]),...(cb?.errors||[])], adds=[], deds=[];let timeDeductions=0,absenceSeen=false;
        if(emp.gosiStatus&&/^سعودي|^أجنبي/.test(emp.gosiStatus)&&/^سعودي/.test(emp.gosiStatus)!==isSaudi(emp.nationality))errors.push('الجنسية لا تطابق صفة التأمينات؛ صحح التصنيف من البيان');
        const monthlyTotal=number(f.total,'إجمالي الراتب',errors), basicMonthly=number(f.basic,'الأساسي',errors), housingMonthly=number(f.housing,'السكن',errors), transportMonthly=number(f.transport,'النقل',errors);
        const otherMonthly=f.other==null ? money(monthlyTotal-basicMonthly-housingMonthly-transportMonthly) : number(f.other,'البدلات الأخرى',errors);
        if (otherMonthly<0 || Math.abs(monthlyTotal-basicMonthly-housingMonthly-transportMonthly-otherMonthly)>.011) errors.push('إجمالي الأجر لا يطابق مجموع بنوده');
        if(service.eligible && monthlyTotal<=0 && !registered) errors.push('أجر الموظف المستحق يجب أن يكون موجبًا');
        const total=registered?cb.gross:money(monthlyTotal*service.ratio), daily=monthlyTotal/30;
        const insured=number(f.basic,'الأجر الخاضع',[])+number(f.housing,'السكن الخاضع',[]);
        const factor=gosiFactor(parse(emp.startDate),ctx.end ? parse(ctx.end) : null,month,!!f.isNewGosi);
        const gosi=registered?cb.gosi:money(Math.min(45000,insured)*ctx.rate.emp/100*factor);
        const companyGosi=registered?cb.companyGosi:money(Math.min(45000,insured)*ctx.rate.co/100*factor);
        if(!registered&&(!validNumber(f.gosi)||Number(f.gosi)<0))errors.push('خصم التأمينات المحفوظ غير صالح');
        if (!registered && validNumber(f.gosi) && !f.isNewGosi && factor===1 && Math.abs(Number(f.gosi)-gosi)>.011) errors.push('خصم التأمينات المحفوظ يخالف الحساب؛ أعد حسابه واعتمده');
        if (ctx.historyRequired && !registered && !emp.compensationVersion) errors.push('لا يوجد أجر مؤرخ أو مسير مقفل لهذا الشهر؛ المبالغ المعروضة معاينة فقط');
        if(emp.isArchived&&!ctx.end)errors.push('الموظف المؤرشف يحتاج تاريخ انتهاء خدمة معتمدًا');
        if(emp.isTerminated&&!ctx.end)errors.push('الموظف المنتهي يحتاج تاريخ آخر يوم عمل معتمدًا');
        const leave=leavePayroll(ctx.requests||[],emp,service,ctx.unpaidNames||[]);
        errors.push(...leave.errors);
        if(leave.lostDays) {timeDeductions=money(Math.min(total,(leave.lostMoney??daily*leave.lostDays)));deds.push({label:'الإجازات: غير مدفوعة/مرضية',amount:timeDeductions,source:'leave',detail:leave.reductions});}
        const seen = new Set();
        for(const o of ctx.operations||[]) {
            if(o.employee_id!==emp.id || o.company_id!==ctx.companyId || !modules[o.module]?.payroll || !service.eligible) continue;
            if(['stopped','cancelled','rejected'].includes(o.status)||['cancelled','rejected'].includes(o.data?.flow?.state)) continue;
            const em=o.effective_month;
            if(o.module==='fin_repay'&&(!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(em||''))||!validNumber(o.amount)||Number(o.amount)<=0||!Number.isInteger(Number(o.data?.installments??1))||Number(o.data?.installments??1)<1||Number(o.data?.installments??1)>120)) {errors.push('بيانات السلفة أو جدول أقساطها غير صالحة: '+(o.ref_no||o.id));continue;}
            const relevant=o.module==='fin_repay' ? em && em<=month && ctx.installment(o,month)>0 : o.recurring ? em&&em<=month : em===month;
            if(!relevant) continue;
            if(seen.has(o.id)) {errors.push('حركة مالية مكررة: '+o.id);continue;} seen.add(o.id);
            let amt=0;
            if(registered&&cb.unit&&['fin_absence','fin_overtime'].includes(o.module)){errors.push('الأجر بالوحدات: أثبت العمل والإضافي في سجل العقد لمنع الازدواج');continue;}
            if(o.module==='fin_absence') {
                const days=number(o.days,'أيام الغياب '+(o.ref_no||o.id),errors);
                if(days>service.calendarDays || !Number.isInteger(days)) errors.push('عدد أيام الغياب يتجاوز المدة أو ليس صحيحًا');
                const absDates=o.data?.absence_dates;
                if(Array.isArray(absDates) && (new Set(absDates).size!==days || absDates.some(d=>!parse(d)||d.slice(0,7)!==month||parse(d)<service.from||parse(d)>service.to||leave.dates.has(d)))) errors.push('تواريخ الغياب غير صالحة أو متداخلة مع الإجازات');
                else if(days>0 && !Array.isArray(absDates) && leave.count>0) errors.push('حدد تواريخ الغياب لمنع ازدواج خصم الإجازة');
                amt=money(registered&&Array.isArray(absDates)?absDates.reduce((sum,on)=>sum+Number(HRContracts.active(emp,on)?.financials.total||0)/30,0):daily*days);
                if(registered&&cb.contractIds.length>1&&days>0&&!Array.isArray(absDates))errors.push('تغير الأجر وسط الشهر؛ حدد تواريخ الغياب');
            } else {
                const value=number(o.amount,'مبلغ الحركة '+(o.ref_no||o.id),errors);
                if(o.module==='fin_repay') {
                    if(!Number.isInteger(Number(o.data?.installments||1))||Number(o.data?.installments||1)<1) errors.push('عدد أقساط غير صالح');
                    amt=ctx.installment(o,month);
                } else amt=value;
            }
            if(!approved(o)) {errors.push('حركة مالية لم تعتمد: '+(o.ref_no||o.id));continue;}
            if(o.module==='fin_absence') {if(absenceSeen)errors.push('يوجد أكثر من سجل غياب فعال لهذا الشهر؛ راجع وادمج السجلات لمنع التكرار');absenceSeen=true;timeDeductions=money(timeDeductions+amt);}
            if(o.module==='fin_extra' && o.data?.auto && !o.data?.verified_unpaid_period) {errors.push('راجع أيام ما قبل الدورة لمنع ازدواج راتب المباشرة');continue;}
            if(amt) (modules[o.module].payroll>0?adds:deds).push({label:`${modules[o.module].title}: ${o.sub_type||''}`,amount:amt,source:o.id});
        }
        for(const a of ctx.adjustments||[]) {
            if(!service.eligible||a.employee_id!==emp.id||!(a.month===month||a.is_recurring&&a.month<=month)) continue;
            if(!['increase','allowance','bonus','deduction'].includes(a.adjustment_type)) {errors.push('نوع تعديل راتب غير صالح');continue;}
            const amount=number(a.amount,'تعديل الراتب '+(a.id||''),errors);
            (a.adjustment_type==='deduction'?deds:adds).push({label:({increase:'زيادة',allowance:'علاوة',bonus:'مكافأة',deduction:'خصم'})[a.adjustment_type]+(a.description?': '+a.description:''),amount,source:a.id});
        }
        const loanTotal=deds.filter(x=>x.label.startsWith(modules.fin_repay.title)).reduce((s,x)=>s+x.amount,0);
        if(loanTotal>money(Math.max(0,total-timeDeductions)*.1)) errors.push('أقساط قروض صاحب العمل تتجاوز 10% من الأجر المستحق');
        const addT=money(adds.reduce((s,x)=>s+x.amount,0)),dedT=money(deds.reduce((s,x)=>s+x.amount,0));
        const basic=money(basicMonthly*service.ratio), housing=money(housingMonthly*service.ratio),transport=money(transportMonthly*service.ratio),other=money(total-basic-housing-transport);
        const net=money(total+addT-gosi-dedT);
        if([addT,dedT,net].some(v=>Math.abs(v)>1000000000||!Number.isSafeInteger(Math.round(v*100))))errors.push('مجموع مالي يتجاوز حدود المعالجة الآمنة');
        return {basic,housing,transport,other,total,monthlyTotal,gosi,companyGosi,adds,deds,addT,dedT,net,timeDeductions,earnedWage:money(total-timeDeductions),service,errors:[...new Set(errors)],overCap:gosi+dedT-timeDeductions>(total-timeDeductions+addT)/2,compensationVersion:emp.compensationVersion,contractIds:cb?.contractIds||[],contractSummary:cb?.summary||'عقد قديم — يلزم المراجعة',contractStatementId:cb?.statement?.id||null,calculationVersion:'2026-10-05.contracts.1'};
    }
    // Inclusive 30/360: whole calendar months = 30, partial months = real days (capped at 30).
    function serviceDays(a,b) {
        if(!a||!b||b<a) return 0;
        let sum=0;
        for(let cur=new Date(Date.UTC(a.getUTCFullYear(),a.getUTCMonth(),1));cur<=b;cur=new Date(Date.UTC(cur.getUTCFullYear(),cur.getUTCMonth()+1,1))) {
            const end=new Date(Date.UTC(cur.getUTCFullYear(),cur.getUTCMonth()+1,0)), from=a>cur?a:cur,to=b<end?b:end;
            sum+=from<=cur&&to>=end?30:Math.min(30,(to-from)/D+1);
        }
        return sum;
    }
    function eos(startValue,endValue,salaryValue,mode,deductions) {
        const a=parse(startValue),b=parse(endValue),errors=[];
        const salary=number(salaryValue,'الأجر',errors);
        const empty={rows:[],totalDays:0,totalDeducted:0,total:0,eligibilityDays:0,payRatio:0};
        if(!a||!b||b<a||salary<=0||errors.length||!['full','resignation','none'].includes(mode)) return {...empty,error:'تحقق من تاريخ الخدمة والأجر وسبب الاستحقاق'};
        const totalDays=serviceDays(a,b), excluded=new Set();
        for(const x of deductions||[]) {
            const from=parse(x.date),count=Number(x.days);
            if(!from||!Number.isInteger(count)||count<0||count>36600) return {...empty,error:'فترة استبعاد خدمة غير صالحة'};
            for(let d=from,i=0;i<count;i++,d=new Date(+d+D)) if(d>=a&&d<=b) excluded.add(iso(d));
        }
        const periods=[];let totalDeducted=0;
        for(let cur=new Date(Date.UTC(a.getUTCFullYear(),a.getUTCMonth(),1));cur<=b;cur=new Date(Date.UTC(cur.getUTCFullYear(),cur.getUTCMonth()+1,1))) {
            const end=new Date(Date.UTC(cur.getUTCFullYear(),cur.getUTCMonth()+1,0)),from=a>cur?a:cur,to=b<end?b:end,days=serviceDays(from,to);
            let count=0;for(let d=from;d<=to;d=new Date(+d+D))if(excluded.has(iso(d)))count++;
            const deducted=count===(to-from)/D+1?days:Math.min(Math.max(0,days-1),count);totalDeducted+=deducted;periods.push({from,to,days,deducted});
        }
        const eligible=totalDays-totalDeducted,years=eligible/360;
        const payRatio=mode==='none'?0:mode==='resignation'?(years<2?0:years<=5?1/3:years<10?2/3:1):1;
        const rows=[];
        let counted=0;
        for(const period of periods) {
            const net=period.days-period.deducted,half=Math.min(net,Math.max(0,1800-counted)),full=net-half,calcRatio=net?(half*.5+full)/net:0;
            rows.push({...period,calcRatio,payRatio,amount:money(salary/360*(half*.5+full)*payRatio)});counted+=net;
        }
        // Round the aggregate once. Adjust the last display row to reconcile to the exact total.
        const total=money(salary*(Math.min(eligible,1800)/360*.5+Math.max(0,eligible-1800)/360)*payRatio);
        if(rows.length) rows.at(-1).amount=money(total-rows.slice(0,-1).reduce((s,r)=>s+r.amount,0));
        return {rows,totalDays,totalDeducted,total,payRatio,eligibilityDays:money(total/(salary/30)),eligibleServiceDays:eligible};
    }
    function leaveBalance(emp,requests,contractDays,asOf=today()) {
        const start=parse(emp.start_date||emp.startDate),now=parse(asOf),errors=[];
        if(!start||!now) return {entitled:0,accrued:0,used:0,balance:0,errors:['تاريخ رصيد الإجازة غير صالح']};
        const year=now.getUTCFullYear(),yearStart=new Date(Date.UTC(year,0,1)),yearEnd=new Date(Date.UTC(year+1,0,1));
        const fifth=anniversary(start,5), statutory=now>=fifth?30:21;
        const contract=validNumber(emp.annual_leave_days??contractDays)?Number(emp.annual_leave_days??contractDays):0;
        const entitled=Math.max(statutory,contract),from=start>yearStart?start:yearStart;
        let accrued=0;
        for(let d=from;d<=now;d=new Date(+d+D)) accrued+=Math.max(d>=fifth?30:21,contract)/((yearEnd-yearStart)/D);
        const dates=requestDays(requests,emp.id,errors);let used=0;
        for(const [date,r] of dates) if(date>=iso(from)&&date<=iso(new Date(+yearEnd-D))&&/سنوي/.test(r.sub_type||'')) used++;
        const opening=emp.leave_opening_balance||emp.leaveOpeningBalance||{};
        const carry=opening.year===year&&validNumber(opening.days)?Number(opening.days):0;
        if(start<yearStart&&(opening.year!==year||!String(opening.evidence||'').trim()))errors.push('لم يعتمد الرصيد الافتتاحي/المرحّل لهذه السنة');
        if(carry<0) errors.push('الرصيد الافتتاحي غير صالح');
        return {entitled,accrued:money(accrued),used,opening:carry,balance:money(accrued+carry-used),errors:[...new Set(errors)]};
    }
    return {money,validNumber,number,today,anniversary,approved,isSaudi,ibanValid,gosiRate,gosiFactor,compensation,requestDays,leavePayroll,payroll,serviceDays,eos,leaveBalance};
})();
if(typeof window!=='undefined') window.HRIntegrity=HRIntegrity;
if(typeof module!=='undefined') module.exports=HRIntegrity;
