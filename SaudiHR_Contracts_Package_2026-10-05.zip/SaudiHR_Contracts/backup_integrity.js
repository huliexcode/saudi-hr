/* Complete, verifiable backup. Restore is handled by the administrative restore utility. */
async function integritySha256(bytes) {
    const result=await crypto.subtle.digest('SHA-256',bytes);
    return [...new Uint8Array(result)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
function integrityBackupOwner() {
    if(!['owner','admin'].includes(myRole))throw new Error('النسخ والاستعادة متاحة لمالك المنشأة أو مديرها فقط');
}
async function integrityBuildBackup() {
    integrityBackupOwner();
    const comp=getActiveCompany();if(!comp)throw new Error('لا توجد منشأة نشطة');
    const companyId=comp.id,revision=companyRevision;
    const before=await supabaseClient.rpc('hr_backup_fingerprint',{p_company_id:companyId});if(before.error||typeof before.data!=='string')throw new Error('تعذر تثبيت مصادر النسخة');
    const data={},warnings=[];
    const co=await supabaseClient.from('companies').select('*').eq('id',companyId).single();
    if(co.error||!co.data)throw new Error('تعذر قراءة سجل المنشأة');data.companies=[co.data];
    data.employees=await integrityReadAll('employees',q=>q.eq('company_id',companyId).order('id'));
    const ids=data.employees.map(x=>x.id);
    for(const [table,key,order='id'] of BACKUP_TABLES) {
        if(table==='employees')continue;
        if(key==='company_id')data[table]=await integrityReadAll(table,q=>q.eq('company_id',companyId).order(order));
        else {
            data[table]=[];
            for(let i=0;i<ids.length;i+=100)data[table].push(...await integrityReadAll(table,q=>q.in('employee_id',ids.slice(i,i+100)).order('id')));
        }
    }
    const manifest=await supabaseClient.rpc('hr_backup_manifest',{p_company_id:companyId});
    if(manifest.error||!Array.isArray(manifest.data))throw new Error('تعذر جرد المرفقات؛ لا يمكن إعلان نسخة كاملة');
    const files=[];let totalBytes=0;
    for(const item of manifest.data) {
        const object=await supabaseClient.storage.from(item.bucket).download(item.path);
        if(object.error||!object.data)throw new Error('تعذر نسخ المرفق: '+item.path);
        const bytes=await object.data.arrayBuffer();totalBytes+=bytes.byteLength;
        if(totalBytes>100*1024*1024)throw new Error('المرفقات تتجاوز 100 ميجابايت؛ استخدم نسخ الخادم بدل تحميل جزئي');
        files.push({...item,bytes:bytes.byteLength,sha256:await integritySha256(bytes),base64:await blobToBase64(object.data)});
    }
    if(companyId!==activeCompanyId||revision!==companyRevision)throw new Error('تغيرت المنشأة أثناء النسخ');
    const after=await supabaseClient.rpc('hr_backup_fingerprint',{p_company_id:companyId});if(after.error||after.data!==before.data)throw new Error('تغيرت البيانات أثناء النسخ؛ أعد النسخ بعد إيقاف التعديلات مؤقتًا');
    const today=HRIntegrity.today();
    const todayChanges=Object.fromEntries(Object.entries(data).map(([table,rows])=>[table,rows.filter(r=>String(r.created_at||'').startsWith(today)||String(r.updated_at||'').startsWith(today)).length]));
    const content=JSON.stringify({data,files});
    return {meta:{platform:'منصة سعودي HR',version:2,complete:true,companyId,companyName:comp.nameAr,createdAt:new Date().toISOString(),createdBy:currentUser?.email,
        counts:Object.fromEntries(Object.entries(data).map(([table,rows])=>[table,rows.length])),fileCount:files.length,totalBytes,todayChanges,skippedTables:warnings,
        payloadSha256:await integritySha256(new TextEncoder().encode(content))},data,files};
}
async function integrityVerifyBackup(b,companyId) {
    if(b?.meta?.version!==2||b.meta.complete!==true||!b.data||!Array.isArray(b.files))throw new Error('هذه النسخة ليست كاملة بالإصدار الجديد');
    if(b.meta.companyId!==companyId)throw new Error('النسخة تخص منشأة أخرى');
    const required=['companies',...BACKUP_TABLES.map(x=>x[0])];
    for(const table of required) {
        if(!Array.isArray(b.data[table])||b.data[table].length!==b.meta.counts?.[table])throw new Error('جدول ناقص أو عدد غير مطابق: '+table);
        const keys=new Set();
        for(const row of b.data[table]) {
            const key=table==='hr_finance_commands'?row?.request_id:row?.id;
            if(typeof key!=='string'||!key||keys.has(key))throw new Error('هوية سجل ناقصة أو مكررة: '+table);
            keys.add(key);
        }
    }
    const company=b.data.companies;if(company.length!==1||company[0].id!==companyId)throw new Error('سجل المنشأة غير مطابق');
    const ids=new Set(b.data.employees.map(e=>e.id));
    for(const [table,key]of BACKUP_TABLES)for(const row of b.data[table])if(key==='company_id'?row.company_id!==companyId:!ids.has(row.employee_id))throw new Error('سجل خارج المنشأة: '+table);
    if(b.files.length!==b.meta.fileCount||!Number.isSafeInteger(b.meta.totalBytes)||b.meta.totalBytes<0)throw new Error('عدد المرفقات أو حجمها غير مطابق');
    const fileKeys=new Set();let totalBytes=0;
    for(const f of b.files) {
        if(!['employee-docs','hr-documents','company-assets'].includes(f.bucket)||typeof f.path!=='string'||!f.path||f.path.split('/').some(x=>x==='..'||x==='.')||fileKeys.has(f.bucket+'/'+f.path))throw new Error('مسار مرفق غير صالح أو مكرر');
        fileKeys.add(f.bucket+'/'+f.path);
        if(!Number.isSafeInteger(f.bytes)||f.bytes<0||typeof f.base64!=='string'||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(f.base64))throw new Error('بيانات المرفق غير صالحة');
        const bytes=Uint8Array.from(atob(f.base64),c=>c.charCodeAt(0));
        if(bytes.byteLength!==f.bytes||await integritySha256(bytes)!==f.sha256)throw new Error('بصمة مرفق غير مطابقة: '+f.path);
        totalBytes+=bytes.byteLength;
    }
    if(totalBytes!==b.meta.totalBytes)throw new Error('إجمالي حجم المرفقات غير مطابق');
    if(await integritySha256(new TextEncoder().encode(JSON.stringify({data:b.data,files:b.files})))!==b.meta.payloadSha256)throw new Error('بصمة محتوى النسخة غير مطابقة');
    return true;
}
window.verifyBackupFile=async function(input) {
    const file=input.files?.[0];input.value='';if(!file)return;
    try{integrityBackupOwner();const b=JSON.parse(await file.text());await integrityVerifyBackup(b,activeCompanyId);window.showToast('النسخة سليمة: '+b.data.employees.length+' موظف، '+b.files.length+' مرفق. الاستعادة عبر أداة المسؤول المرفقة.');}
    catch(e){window.showToast('تعذر التحقق: '+e.message,'error');}
};
