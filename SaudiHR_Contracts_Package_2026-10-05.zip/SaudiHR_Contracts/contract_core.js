/* Saudi contract register. Civil dates, explicit versions, evidenced work and insurance. */
const HRContracts=(()=>{
 'use strict';
 const D=86400000,iso=d=>HRCore.iso(d),date=v=>HRCore.date(v),money=n=>HRIntegrity.money(n);
 const labels={term:{fixed:'محدد المدة',indefinite:'غير محدد المدة',task:'لإنجاز عمل معين',training:'تأهيل وتدريب'},nature:{ordinary:'اعتيادي',temporary:'مؤقت',incidental:'عرضي',seasonal:'موسمي'},pattern:{full:'دوام كامل',part:'لبعض الوقت',flex:'عمل مرن'},location:{onsite:'حضوري',remote:'عن بُعد',hybrid:'هجين'},basis:{monthly:'شهري',hourly:'بالساعة',daily:'باليوم',milestone:'إنجاز معتمد'}};
 const approved=c=>c.status==='approved';
 const rows=e=>(e.contracts||[]).filter(approved).sort((a,b)=>a.start_date.localeCompare(b.start_date));
 const active=(e,on)=>rows(e).find(c=>c.start_date<=on&&(!c.end_date||c.end_date>=on))||null;
 const summary=c=>c?[labels.term[c.term],labels.nature[c.nature],labels.pattern[c.pattern],labels.location[c.location]].filter(Boolean).join(' • '):'لم يعتمد عقد';
 function validate(c,e,all=[]){
  const errors=[],a=date(c.start_date),b=c.end_date?date(c.end_date):null,f=c.financials||{};
  for(const k of ['term','nature','pattern','location','basis'])if(!labels[k][c[k]])errors.push('تصنيف العقد غير صالح: '+k);
  if(!a||c.end_date&&!b||b&&b<a)errors.push('تواريخ العقد غير صالحة');
  if(a&&date(e.startDate||e.start_date)&&a<date(e.startDate||e.start_date))errors.push('العقد يسبق بداية خدمة الموظف');
  if(c.term==='indefinite'&&c.end_date&&!c.closure_evidence)errors.push('العقد غير المحدد لا يحمل تاريخ انتهاء');
  if(c.term!=='indefinite'&&c.term!=='task'&&!b)errors.push('حدد تاريخ نهاية العقد');
  if(!HRIntegrity.isSaudi(e.nationality)&&c.term==='indefinite')errors.push('عقد غير السعودي يجب أن يكون محددًا');
  if(c.pattern==='part'&&(c.term!=='fixed'||!(Number(c.daily_hours)>0&&Number(c.daily_hours)<Number(c.facility_hours)/2)))errors.push('العمل لبعض الوقت: عقد محدد وساعاته أقل من نصف ساعات المنشأة');
  if(c.pattern==='flex'){
   if(!HRIntegrity.isSaudi(e.nationality)||c.term!=='fixed'||c.basis!=='hourly'||!c.platform_reference)errors.push('المرن يتطلب سعوديًا وعقدًا محددًا بالساعة ومرجع منصة التوثيق');
   if(Number(c.probation_days))errors.push('لا فترة تجربة في العمل المرن');
   if(a&&b&&b>=HRIntegrity.anniversary(a)&&!c.extension_consent)errors.push('تمديد المرن بعد سنة يحتاج إثبات موافقة العامل');
  }
  if(['temporary','incidental'].includes(c.nature)&&(!b||a&&(b-a)/D+1>90))errors.push('المؤقت والعرضي لا يتجاوزان 90 يومًا؛ سجل الاستمرار كعقد اعتيادي');
  if(c.nature==='seasonal'&&!String(c.scope||'').trim())errors.push('حدد الموسم');
  if(c.term==='task'&&!String(c.scope||'').trim())errors.push('حدد العمل ومعيار اكتماله');
  if(c.term==='training'&&(!String(c.scope||'').trim()||c.basis==='milestone'))errors.push('التدريب يحتاج خطة ومراحل، ومكافأته لا ترتبط بالإنتاج');
  if(c.basis==='milestone'&&c.term!=='task')errors.push('أجر الإنجاز مخصص للعمل المعين');
  if(!Number.isInteger(Number(c.probation_days||0))||Number(c.probation_days||0)<0||Number(c.probation_days||0)>180)errors.push('التجربة بين صفر و180 يومًا');
  if(!(Number(c.daily_hours)>0&&Number(c.daily_hours)<=8&&Number(c.facility_hours)>0&&Number(c.facility_hours)<=8)||!Array.isArray(c.work_days)||!c.work_days.length||new Set(c.work_days).size!==c.work_days.length||c.work_days.some(x=>!Number.isInteger(x)||x<0||x>6)||Number(c.daily_hours)*c.work_days.length>48)errors.push('جدول العمل غير صالح');
  if(!['statutory','none'].includes(c.eos_policy)||!Number.isFinite(Number(c.annual_days))||Number(c.annual_days)<0||Number(c.annual_days)>365)errors.push('سياسة الاستحقاقات غير صالحة');
  const ordinary=c.term!=='training'&&c.pattern==='full'&&c.nature==='ordinary';
  if(ordinary&&c.eos_policy!=='statutory')errors.push('العقد الاعتيادي يحتاج سياسة نهاية الخدمة النظامية');
  if(c.pattern==='flex'&&(Number(c.annual_days)!==0||c.eos_policy!=='none'))errors.push('استحقاقات المرن الخاصة لا تشمل رصيد إجازة مدفوعة أو مكافأة نهاية خدمة');
  for(const k of ['total','basic','housing','transport','other'])if(!HRIntegrity.validNumber(f[k])||Number(f[k])<0||Number(f[k])>1e9)errors.push('أجر/سعر الوحدة غير صالح');
  if(!(Number(f.total)>0)||Math.abs(Number(f.total)-['basic','housing','transport','other'].reduce((s,k)=>s+Number(f[k]),0))>.01)errors.push('مجموع بنود الأجر لا يطابق الإجمالي');
  if(c.renewal_of){const previous=all.find(x=>x.id===c.renewal_of&&approved(x));if(!previous||!previous.end_date||c.start_date!==iso(new Date(+date(previous.end_date)+D)))errors.push('التجديد يجب أن يتبع عقدًا معتمدًا دون فجوة');
   const chain=[];let x=previous;while(x&&!chain.some(y=>y.id===x.id)&&chain.length<100){chain.push(x);x=all.find(y=>y.id===x.renewal_of);}if(HRIntegrity.isSaudi(e.nationality)&&c.pattern==='full'&&c.nature==='ordinary'&&c.term==='fixed'&&(chain.filter(x=>x.renewal_of).length>=3||chain.length&&date(c.start_date)>=HRIntegrity.anniversary(date(chain.at(-1).start_date),4)))errors.push('مراجعة المادة 55: الاستمرار بعد حد التجديد يتطلب عقدًا غير محدد للسعودي');}
  if(c.basis!=='monthly'&&all.some(x=>x.id!==c.id&&approved(x)&&x.basis==='monthly'&&x.term!=='training'&&x.start_date<c.start_date)&&!String(c.extension_consent||'').trim())errors.push('نقل الأجر الشهري إلى الوحدات يتطلب موافقة العامل المكتوبة');
  if(!String(c.evidence||'').trim())errors.push('مرجع العقد الموقع مطلوب');
  if(c.flex_same_rate&&!String(c.extension_consent||'').trim())errors.push('أرفق اتفاق أجر ساعات المرن الإضافية');
  if(all.some(x=>x.id!==c.id&&approved(x)&&x.start_date<=(c.end_date||'9999-12-31')&&(x.end_date||'9999-12-31')>=c.start_date))errors.push('تداخل مع عقد معتمد؛ أنهِ الفترة السابقة قبل اعتماد النسخة الجديدة');
  return [...new Set(errors)];
 }
 function policy(c,e,on){
  if(!c)return {annual:0,sick:false,eos:false,error:'العقد غير معتمد'};
  const ordinary=c.nature==='ordinary'&&c.term!=='training'&&c.pattern==='full',part=c.pattern==='part',training=c.term==='training',flex=c.pattern==='flex';
  const start=date(e.startDate||e.start_date),fifth=start&&HRIntegrity.anniversary(start,5),stat=fifth&&date(on)>=fifth?30:21;
  return {annual:flex?0:Math.max(Number(c.annual_days)||0,ordinary||part||training?stat:0),sick:ordinary||part,eos:!flex&&c.eos_policy==='statutory',training,unit:c.basis!=='monthly',notice:training?7:ordinary&&c.term==='indefinite'?(c.basis==='monthly'?60:30):null};
 }
 function monthBase(e,month,end,options={}){
  const service=HRCore.servicePeriod(date(e.startDate||e.start_date),end?date(end):null,month),errors=[...service.errors],cs=rows(e),components={basic:0,housing:0,transport:0,other:0},used=[],covered=[];
  if(!cs.length)return {legacy:true,service,errors:e.contractsRequired?['لم يعتمد عقد الموظف؛ المسير موقوف']:[]};
  const entries=(e.contractEntries||[]).filter(x=>x.work_date.slice(0,7)===month),statements=(e.contractMonths||[]).filter(x=>x.month===month&&approved(x));
  const weight=service.calendarDays?service.payDays/service.calendarDays:0;
  for(let d=service.from;service.eligible&&d<=service.to;d=new Date(+d+D)){
   const key=iso(d),c=active(e,key);if(!c){errors.push('فجوة عقد في '+key);continue;}covered.push(key);if(!used.some(x=>x.id===c.id))used.push(c);
   if(c.basis==='monthly')for(const k of Object.keys(components))components[k]+=Number(c.financials[k])/30*weight;
  }
  for(const c of used){
   errors.push(...validate(c,e,cs));
   const work=entries.filter(x=>x.contract_id===c.id),approvedWork=work.filter(approved);
   if(work.some(x=>x.status==='draft'))errors.push('وحدات عمل لم تعتمد');
   if(c.basis==='monthly'&&approvedWork.length)errors.push('لا تضاف وحدات عمل إلى أجر شهري');
   let hours=0;
   for(const x of approvedWork.sort((a,b)=>(a.work_date+a.id).localeCompare(b.work_date+b.id))){
    const qty=Number(x.quantity),on=x.work_date;
    if(!date(on)||active(e,on)?.id!==c.id||!covered.includes(on)||!Number.isFinite(qty)||qty<=0||!x.evidence){errors.push('وحدة عمل خارج العقد أو غير موثقة');continue;}
    if(c.basis==='monthly')continue;
    if(c.basis==='daily'&&x.kind!=='overtime'&&qty>1||c.basis==='hourly'&&qty>12||c.basis==='milestone'&&(qty!==1||!x.unit_reference))errors.push('كمية الوحدة غير صالحة');
    const p=policy(c,e,on);let leaveFactor=1;if(x.kind==='paid_leave'){const requests=options.requests||e.contractRequests||[],r=requests.find(r=>r.id===x.leave_request_id&&r.employee_id===e.id&&r.request_type==='leave'&&r.status==='approved'&&r.date_from<=on&&(r.date_to||r.date_from)>=on);if(!r){errors.push('وحدة الإجازة تحتاج طلبًا معتمدًا يغطي التاريخ');continue;}if(/غير مدفوعة|دون أجر|بدون أجر/.test(r.sub_type||'')){errors.push('لا أجر لوحدة الإجازة غير المدفوعة');continue;}if(/مرض/.test(r.sub_type||'')){if(!p.sick){errors.push('المرضية خارج نطاق العقد');continue;}const days=HRIntegrity.requestDays(requests,e.id,errors);let anchor=null,count=0;for(const [key,leave]of [...days].sort(([a],[b])=>a.localeCompare(b))){if(key>on)break;if(!/مرض/.test(leave.sub_type||''))continue;const d=date(key);if(!anchor||d>=HRIntegrity.anniversary(anchor)){anchor=d;count=0;}count++;}if(count>120)errors.push('المرضية تتجاوز 120 يومًا');leaveFactor=count<=30?1:count<=90?.75:0;}else if(/سنوي/.test(r.sub_type||'')&&!p.annual){errors.push('إجازة سنوية خارج الاستحقاق');continue;}}
    if(c.pattern==='flex'&&x.kind!=='work')errors.push('سجل المرن يقبل ساعات العمل فقط');
    if(x.kind==='overtime'&&(c.pattern==='flex'||c.term==='training'||c.basis==='milestone'))errors.push('الإضافي غير مناسب لهذه الوحدة');
    const paidQty=x.kind==='overtime'&&c.basis==='daily'?qty/Number(c.daily_hours):qty;
    const payableQty=paidQty*leaveFactor;
    const old=hours;hours+=qty;
    for(const k of Object.keys(components))components[k]+=Number(c.financials[k])*payableQty;
    if(x.kind==='overtime')components.basic+=Number(c.financials.basic)*.5*paidQty;
    if(c.pattern==='flex'&&!c.flex_same_rate){const extra=Math.max(0,hours-95)-Math.max(0,old-95);components.basic+=Number(c.financials.basic)*.5*extra;}
   }
   if(c.pattern==='flex'&&hours>160)errors.push('ساعات المرن تتجاوز 160 شهريًا لدى المنشأة');
   const byDate=new Map();for(const x of approvedWork){const v=byDate.get(x.work_date)||{work:0,ot:0};v[x.kind==='overtime'?'ot':'work']+=Number(x.quantity);byDate.set(x.work_date,v);}for(const v of byDate.values()){if(c.basis==='daily'&&(v.work>1||v.work*Number(c.daily_hours)+v.ot>12)||c.basis==='hourly'&&(v.work+v.ot>12||c.pattern!=='flex'&&v.work>Number(c.daily_hours)))errors.push('وحدات يوم العمل متكررة أو تتجاوز الحد');}
  }
  if(used.some(c=>c.pattern==='flex')&&used.length>1)errors.push('تغيير عقد المرن داخل الشهر يتطلب شهرًا مستقلًا لتجميع حد الساعات');
  const gross=money(Object.values(components).reduce((a,b)=>a+b,0));for(const k of Object.keys(components))components[k]=money(components[k]);components.other=money(gross-components.basic-components.housing-components.transport);
  const statement=statements[0];
  if(options.insurance!==false&&(statements.length!==1||!statement?.evidence))errors.push('يلزم بيان تأمينات شهري معتمد، بما فيه حالات عدم الشمول');
  const gosi=Number(statement?.gosi_employee||0),companyGosi=Number(statement?.gosi_company||0);
  if(![gosi,companyGosi].every(x=>Number.isFinite(x)&&x>=0&&x<=1e9))errors.push('مبالغ بيان التأمينات غير صالحة');
  return {legacy:false,service,components,gross,monthlyTotal:service.ratio?money(gross/service.ratio):0,gosi,companyGosi,statement,contracts:used,contractIds:used.map(x=>x.id),summary:used.map(summary).join(' / '),unit:used.some(c=>c.basis!=='monthly'),errors:[...new Set(errors)]};
 }
 function leave(e,requests,asOf=HRIntegrity.today()){
  if(!rows(e).length&&!e.contractsRequired)return null;
  const now=date(asOf),start=date(e.startDate||e.start_date),errors=[],year=now?.getUTCFullYear();if(!now||!start)return {entitled:0,balance:0,errors:['تواريخ الخدمة غير صالحة']};
  const first=new Date(Date.UTC(year,0,1)),end=new Date(Date.UTC(year+1,0,1));let accrued=0;
  for(let d=start>first?start:first;d<=now;d=new Date(+d+D)){const c=active(e,iso(d));if(c)accrued+=policy(c,e,iso(d)).annual/((end-first)/D);else errors.push('فجوة في سجل العقود');}
  const entitled=policy(active(e,asOf),e,asOf).annual,dates=HRIntegrity.requestDays(requests,e.id,errors);let used=0;
  for(const [on,r]of dates)if(on>=iso(first)&&on<iso(end)&&/سنوي/.test(r.sub_type||'')){used++;if(!policy(active(e,on),e,on).annual)errors.push('إجازة سنوية خارج استحقاق العقد');}
  const o=e.leaveOpeningBalance||e.leave_opening_balance||{},opening=o.year===year?Number(o.days||0):0;
  if(start<first&&entitled&&(o.year!==year||!o.evidence))errors.push('اعتمد الرصيد المرحل للسنة');
  return {entitled,accrued:money(accrued),opening,used,balance:money(accrued+opening-used),errors:[...new Set(errors)]};
 }
 function eos(e,to,salary,mode,deductions){
  const cs=rows(e);if(!cs.length)return e.contractsRequired?{error:'اعتمد سجل العقود قبل التسوية',total:0}:null;
  const c=active(e,to);if(!c)return {error:'لا يوجد عقد يغطي تاريخ التسوية',total:0};if(!c)return {error:'لا يوجد عقد يغطي التسوية',total:0};
  if(!policy(c,e,to).eos&&cs.some(x=>x.id!==c.id&&x.start_date<=to&&policy(x,e,to).eos))return {error:'تغير العقد بعد اكتساب حقوق نهاية خدمة؛ راجع التسوية لحفظ الحقوق السابقة',total:0};
  if(!policy(c,e,to).eos)return {total:0,rows:[],totalDays:0,totalDeducted:0,eligibilityDays:0,payRatio:0,excluded:true,note:'هذا العقد لا ينشئ استحقاق نهاية خدمة؛ راجع أي ميزة تعاقدية إضافية'};
  if(cs[0].start_date>(e.startDate||e.start_date))return {error:'أكمل سجل العقود التاريخي قبل تسوية نهاية الخدمة',total:0};
  let coveredThrough=e.startDate||e.start_date;for(const x of cs.filter(x=>x.start_date<=to)){if(x.start_date>coveredThrough)return {error:'فجوة في سجل الخدمة؛ راجع أساس التسوية',total:0};const next=x.end_date?iso(new Date(+date(x.end_date)+D)):iso(new Date(+date(to)+D));if(next>coveredThrough)coveredThrough=next;}if(coveredThrough<=to)return {error:'سجل العقود لا يغطي كامل الخدمة',total:0};
  if(cs.some(x=>x.start_date<=to&&!policy(x,e,to).eos))return {error:'تغير نطاق استحقاق نهاية الخدمة؛ يلزم مراجعة التسوية وتوثيق الفترات المستحقة',total:0};
  let wage=salary;if(c.basis!=='monthly'){const s=(e.contractMonths||[]).filter(x=>approved(x)&&x.month<=to.slice(0,7)&&Number(x.eos_wage)>0&&(x.eos_evidence||x.eos_basis_verified)).sort((a,b)=>b.month.localeCompare(a.month))[0];if(!s||s.month!==to.slice(0,7))return {error:'وثق أساس أجر التسوية للأجر المتغير في بيان الشهر',total:0};wage=Number(s.eos_wage);}else wage=Number(c.financials.total);
  return HRIntegrity.eos(e.startDate||e.start_date,to,wage,mode,deductions);
 }
 function settlement(e,to){
  const cs=rows(e);if(!cs.length)return e.contractsRequired?{error:'اعتمد العقد قبل إصدار المخالصة'}:null;
  const c=active(e,to);if(!c)return {error:'لا عقد يغطي تاريخ المخالصة'};const p=policy(c,e,to);
  if(c.basis==='monthly')return {wage:Number(c.financials.total),annual:p.annual,unit:false};
  const s=(e.contractMonths||[]).find(x=>x.month===to.slice(0,7)&&approved(x));if(!s||!s.evidence)return {error:'اعتمد بيان شهر التصفية'};
  if((p.annual||p.eos)&&(!(Number(s.eos_wage)>0)||!(s.eos_evidence||s.eos_basis_verified)))return {error:'وثق أساس أجر بدل الإجازة/نهاية الخدمة للأجر المتغير'};
  if(!s.unpaid_evidence)return {error:'وثق كشف الأجر غير المصروف، بما فيه الرصيد صفر'};
  return {wage:Number(s.eos_wage)||monthBase(e,to.slice(0,7),to).gross,annual:p.annual,unit:true,unpaid:Number(s.unpaid_wage||0)};
 }
 return {labels,rows,active,summary,validate,policy,monthBase,leave,eos,settlement};
})();
if(typeof window!=='undefined')window.HRContracts=HRContracts;
if(typeof module!=='undefined')module.exports=HRContracts;
