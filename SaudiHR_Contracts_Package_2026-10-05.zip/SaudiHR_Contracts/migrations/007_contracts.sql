-- Saudi contract registry and independent payable-unit verification. Apply on staging first.
begin;
create table if not exists public.hr_contracts(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references public.companies(id),employee_id uuid not null references public.employees(id),
 status text not null default 'draft' check(status in ('draft','approved')),
 term text not null check(term in ('fixed','indefinite','task','training')),nature text not null check(nature in ('ordinary','temporary','incidental','seasonal')),
 pattern text not null check(pattern in ('full','part','flex')),location text not null check(location in ('onsite','remote','hybrid')),basis text not null check(basis in ('monthly','hourly','daily','milestone')),
 start_date date not null,end_date date,financials jsonb not null,daily_hours numeric not null default 8,facility_hours numeric not null default 8,work_days jsonb not null default '[0,1,2,3,4,6]',
 annual_days numeric not null default 21,eos_policy text not null default 'statutory' check(eos_policy in ('statutory','none')),probation_days integer not null default 0,
 scope text not null default '',evidence text not null default '',platform_reference text not null default '',extension_consent text not null default '',flex_same_rate boolean not null default false,closure_evidence text not null default '',historical_record boolean not null default false,renewal_of uuid references public.hr_contracts(id),created_at timestamptz not null default now()
);
create index if not exists hr_contract_employee_period on public.hr_contracts(employee_id,start_date,end_date);
create table if not exists public.hr_contract_entries(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references public.companies(id),employee_id uuid not null references public.employees(id),contract_id uuid not null references public.hr_contracts(id),
 work_date date not null,quantity numeric not null,leave_request_id uuid references public.employee_requests(id),kind text not null default 'work' check(kind in ('work','paid_leave','paid_holiday','overtime')),unit_reference text not null,evidence text not null,status text not null default 'draft' check(status in ('draft','approved')),created_at timestamptz not null default now(),unique(contract_id,unit_reference)
);
create table if not exists public.hr_contract_months(
 id uuid primary key default gen_random_uuid(),company_id uuid not null references public.companies(id),employee_id uuid not null references public.employees(id),month text not null check(month ~ '^\d{4}-(0[1-9]|1[0-2])$'),
 gosi_employee numeric not null,gosi_company numeric not null,evidence text not null,eos_wage numeric not null default 0,eos_evidence text not null default '',unpaid_wage numeric not null default 0,unpaid_evidence text not null default '',status text not null default 'approved' check(status in ('draft','approved')),created_at timestamptz not null default now(),unique(employee_id,month)
);
-- Existing employees must be reviewed; no historical term or special entitlement is fabricated.
update public.companies set policy_settings=coalesce(policy_settings,'{}')||jsonb_build_object('hr_contracts_required',true) where not coalesce(policy_settings,'{}') ? 'hr_contracts_required';
create or replace function public.hr_contract_leave_factor(p_employee_id uuid,p_date date,p_request_id uuid) returns numeric language plpgsql security definer set search_path=pg_catalog,public as $$
declare r jsonb;c public.hr_contracts;d record;anchor date;sick integer:=0;begin
 select to_jsonb(x) into r from public.employee_requests x where id=p_request_id and employee_id=p_employee_id and request_type='leave' and status='approved' and p_date between hr_parse_date(to_jsonb(x)->>'date_from') and hr_parse_date(to_jsonb(x)->>'date_to');
 if r is null then raise exception 'Payable leave unit requires matching approved request';end if;
 select * into c from hr_contracts where employee_id=p_employee_id and status='approved' and p_date between start_date and coalesce(end_date,'9999-12-31');
 if r->>'sub_type' ~ 'غير مدفوعة|دون أجر|بدون أجر' then raise exception 'Unpaid leave cannot produce wage units';end if;
 if r->>'sub_type' ~ 'سنوي' and c.annual_days=0 and not(c.pattern='part' or c.term='training' or c.nature='ordinary' and c.pattern='full') then raise exception 'Annual leave outside entitlement';end if;
 if r->>'sub_type' !~ 'مرض' then return 1;end if;
 if not(c.pattern='part' or c.pattern='full' and c.nature='ordinary' and c.term<>'training') then raise exception 'Sick leave outside entitlement';end if;
 for d in select dd::date work_day from public.employee_requests x cross join lateral generate_series(hr_parse_date(to_jsonb(x)->>'date_from')::timestamp,hr_parse_date(to_jsonb(x)->>'date_to')::timestamp,interval '1 day') dd where employee_id=p_employee_id and request_type='leave' and status='approved' and sub_type ~ 'مرض' and dd::date<=p_date order by dd loop
  if anchor is null or d.work_day>=(anchor+interval '1 year')::date then anchor:=d.work_day;sick:=0;end if;sick:=sick+1;
 end loop;if sick>120 then raise exception 'Sick entitlement exceeds 120 days';end if;return case when sick<=30 then 1 when sick<=90 then .75 else 0 end;
end $$;
revoke execute on function public.hr_contract_leave_factor(uuid,date,uuid) from public,anon,authenticated;
create or replace function public.hr_contract_guard() returns trigger language plpgsql security definer set search_path=pg_catalog,public as $$
declare j jsonb:=case when tg_op='DELETE' then to_jsonb(old) else to_jsonb(new) end; prior jsonb:=case when tg_op='INSERT' then '{}' else to_jsonb(old) end;
 co uuid:=(j->>'company_id')::uuid;em uuid:=(j->>'employee_id')::uuid;c public.hr_contracts;f jsonb;k text;total numeric;from_m text;to_m text;days integer;saudi boolean;chain_count integer;chain_start date;prior_contract public.hr_contracts;
begin
 perform public.hr_lock_company(co);
 if not exists(select 1 from public.employees where id=em and company_id=co) then raise exception 'Employee/company mismatch';end if;
 if tg_op='UPDATE' and (prior->>'company_id'<>j->>'company_id' or prior->>'employee_id'<>j->>'employee_id') then raise exception 'Tenant or employee move forbidden';end if;
 if tg_table_name='hr_contracts' then
  from_m:=least(left(j->>'start_date',7),left(prior->>'start_date',7));to_m:=greatest(coalesce(left(j->>'end_date',7),'9999-12'),coalesce(left(prior->>'end_date',7),'9999-12'));
  if prior->>'status'='approved' then
   if tg_op='DELETE' or (prior-'end_date'-'closure_evidence')<>(j-'end_date'-'closure_evidence') then raise exception 'Approved contract is immutable; create a new dated version';end if;
   if length(trim(coalesce(j->>'closure_evidence','')))=0 or j->>'end_date' is null then raise exception 'Contract closure needs dated evidence';end if;
   from_m:=least(left(j->>'end_date',7),coalesce(left(prior->>'end_date',7),'9999-12'));
  end if;
 elsif tg_table_name='hr_contract_entries' then from_m:=least(left(j->>'work_date',7),left(prior->>'work_date',7));to_m:=greatest(left(j->>'work_date',7),left(prior->>'work_date',7));
 else from_m:=least(j->>'month',prior->>'month');to_m:=greatest(j->>'month',prior->>'month');end if;
 if tg_table_name='hr_contracts' and coalesce((j->>'historical_record')::boolean,false) and (j->>'end_date' is null or (j->>'end_date')::date>=date_trunc('month',current_date)) then raise exception 'Historical contract must end before current month';end if;
 if not(tg_table_name='hr_contracts' and tg_op='INSERT' and coalesce((j->>'historical_record')::boolean,false)) and exists(select 1 from public.hr_payroll_runs where company_id=co and month between from_m and to_m) then raise exception 'Contract source affects closed payroll';end if;
 if tg_op='DELETE' then return old;end if;
 if tg_table_name='hr_contracts' then
  select public.hr_is_saudi(nationality) into saudi from public.employees where id=em;
  if new.end_date<new.start_date or new.start_date< (select public.hr_parse_date(to_jsonb(e)->>'start_date') from public.employees e where id=em) then raise exception 'Invalid contract period';end if;
  if new.term='indefinite' and (not saudi or new.end_date is not null and new.closure_evidence='') then raise exception 'Invalid indefinite contract';end if;
  if new.term not in ('indefinite','task') and new.end_date is null then raise exception 'Contract end date required';end if;
  if new.pattern='part' and (new.term<>'fixed' or not(new.daily_hours<new.facility_hours/2)) then raise exception 'Part-time must be fixed and below half facility hours';end if;
  if new.daily_hours<=0 or new.daily_hours>8 or new.facility_hours<=0 or new.facility_hours>8 or jsonb_typeof(new.work_days)<>'array' or jsonb_array_length(new.work_days)=0 or new.daily_hours*jsonb_array_length(new.work_days)>48
   or exists(select 1 from jsonb_array_elements_text(new.work_days) x where x !~ '^[0-6]$') or (select count(distinct x) from jsonb_array_elements_text(new.work_days) x)<>jsonb_array_length(new.work_days) then raise exception 'Invalid work schedule';end if;
  if new.probation_days not between 0 and 180 or new.annual_days not between 0 and 365 then raise exception 'Invalid probation or annual entitlement';end if;
  if new.pattern='flex' and (not saudi or new.term<>'fixed' or new.basis<>'hourly' or trim(new.platform_reference)='' or new.probation_days<>0 or new.annual_days<>0 or new.eos_policy<>'none') then raise exception 'Invalid flexible contract';end if;
  if new.pattern='flex' and new.end_date>=new.start_date+interval '1 year' and trim(new.extension_consent)='' then raise exception 'Flexible extension consent required';end if;
  if new.flex_same_rate and trim(new.extension_consent)='' then raise exception 'Flexible overtime agreement required';end if;
  if new.nature in ('temporary','incidental') and (new.end_date is null or new.end_date-new.start_date+1>90) then raise exception 'Temporary/incidental maximum 90 days; record continuation as ordinary';end if;
  if (new.term in ('task','training') or new.nature='seasonal') and trim(new.scope)='' then raise exception 'Scope/season/training plan required';end if;
  if new.basis='milestone' and new.term<>'task' or new.term='training' and new.basis='milestone' then raise exception 'Invalid production based training or milestone';end if;
  if new.nature='ordinary' and new.pattern='full' and new.term<>'training' and new.eos_policy<>'statutory' then raise exception 'Ordinary contract requires statutory EOS';end if;
  f:=new.financials;total:=0;
  foreach k in array array['total','basic','housing','transport','other'] loop if coalesce(f->>k,'') !~ '^\d+(\.\d+)?$' or (f->>k)::numeric>1000000000 then raise exception 'Invalid contract wage';end if;end loop;
  if (f->>'total')::numeric<=0 or abs((f->>'total')::numeric-(f->>'basic')::numeric-(f->>'housing')::numeric-(f->>'transport')::numeric-(f->>'other')::numeric)>.01 then raise exception 'Contract wage components mismatch';end if;
  if new.renewal_of is not null then
   select * into prior_contract from hr_contracts where id=new.renewal_of and employee_id=em and status='approved';if not found or prior_contract.end_date is null or new.start_date<>prior_contract.end_date+1 then raise exception 'Renewal must follow approved predecessor without a gap';end if;
   with recursive chain as(select id,start_date,renewal_of from hr_contracts where id=new.renewal_of union all select x.id,x.start_date,x.renewal_of from hr_contracts x join chain y on x.id=y.renewal_of) select count(*) filter(where renewal_of is not null),min(start_date) into chain_count,chain_start from chain;
   if saudi and new.pattern='full' and new.nature='ordinary' and new.term='fixed' and (chain_count>=3 or new.start_date>=chain_start+interval '4 years') then raise exception 'Article 55 continuation requires indefinite Saudi contract review';end if;
  end if;
  if new.basis<>'monthly' and trim(new.extension_consent)='' and exists(select 1 from hr_contracts where employee_id=em and id<>new.id and status='approved' and basis='monthly' and term<>'training' and start_date<new.start_date) then raise exception 'Article 59 employee consent required for monthly to unit wage transition';end if;
  if new.status='approved' then
   if trim(new.evidence)='' then raise exception 'Signed contract evidence required';end if;
   if exists(select 1 from public.hr_contracts x where x.employee_id=em and x.status='approved' and x.id<>new.id and x.start_date<=coalesce(new.end_date,'9999-12-31') and coalesce(x.end_date,'9999-12-31')>=new.start_date) then raise exception 'Approved contract overlap';end if;
  end if;
 elsif tg_table_name='hr_contract_entries' then
  select * into c from public.hr_contracts where id=new.contract_id and company_id=co and employee_id=em and status='approved';
  if not found or new.work_date<c.start_date or new.work_date>c.end_date or c.basis='monthly' then raise exception 'Work entry outside approved unit contract';end if;
  if new.quantity<=0 or new.quantity>1000000000 or c.basis='daily' and new.kind<>'overtime' and new.quantity>1 or c.basis='hourly' and new.quantity>12 or c.basis='milestone' and new.quantity<>1 then raise exception 'Invalid work quantity';end if;
  if new.kind='overtime' and (c.pattern='flex' or c.term='training' or c.basis='milestone') then raise exception 'Invalid overtime unit';end if;
  if trim(new.evidence)='' or trim(new.unit_reference)='' then raise exception 'Work evidence/reference required';end if;
  if c.pattern='flex' and new.kind<>'work' then raise exception 'Flexible ledger accepts worked hours only';end if;
  if new.kind='paid_leave' and c.pattern<>'part' and c.term<>'training' and not(c.pattern='full' and c.nature='ordinary') and c.annual_days=0 then raise exception 'Paid leave outside contract entitlement';end if;
  if new.kind='paid_leave' then perform public.hr_contract_leave_factor(em,new.work_date,new.leave_request_id);end if;
  if new.status='approved' and c.basis in ('daily','hourly') then
   select coalesce(sum(case when c.basis='daily' and kind<>'overtime' then quantity*c.daily_hours else quantity end),0)+case when c.basis='daily' and new.kind<>'overtime' then new.quantity*c.daily_hours else new.quantity end into total from public.hr_contract_entries where contract_id=c.id and work_date=new.work_date and status='approved' and id<>new.id;
   if total>12 then raise exception 'Daily quantity limit/duplication';end if;
   select coalesce(sum(quantity),0)+case when new.kind='overtime' then 0 else new.quantity end into total from public.hr_contract_entries where contract_id=c.id and work_date=new.work_date and status='approved' and id<>new.id and kind<>'overtime';
   if c.basis='daily' and total>1 or c.basis='hourly' and c.pattern<>'flex' and total>c.daily_hours then raise exception 'Daily quantity limit; record overtime separately';end if;
   if c.pattern='flex' then select coalesce(sum(quantity),0)+new.quantity into total from public.hr_contract_entries where employee_id=em and company_id=co and status='approved' and left(work_date::text,7)=left(new.work_date::text,7) and id<>new.id;if total>160 then raise exception 'Flexible maximum 160 monthly hours';end if;end if;
  end if;
 else
  if new.gosi_employee<0 or new.gosi_company<0 or new.eos_wage<0 or new.unpaid_wage<0 or greatest(new.gosi_employee,new.gosi_company,new.eos_wage,new.unpaid_wage)>1000000000 or trim(new.evidence)='' then raise exception 'Invalid monthly insurance statement';end if;
  if new.unpaid_wage>0 and trim(new.unpaid_evidence)='' then raise exception 'Unpaid wage reconciliation evidence required';end if;
  if new.eos_wage>0 and trim(new.eos_evidence)='' then raise exception 'EOS wage basis evidence required';end if;
 end if;return new;
end $$;
do $$declare t text;begin foreach t in array array['hr_contracts','hr_contract_entries','hr_contract_months'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('revoke all on public.%I from public,anon',t);
 execute format('grant select,insert,update,delete on public.%I to authenticated',t);
 execute format('drop policy if exists hr_contract_access on public.%I',t);
 execute format('create policy hr_contract_access on public.%I for all to authenticated using(public.hr_company_role(company_id) in (''owner'',''admin'',''hr'',''accountant'')) with check(public.hr_company_role(company_id) in (''owner'',''admin'',''hr'',''accountant''))',t);
 execute format('drop trigger if exists hr_contract_guard on public.%I',t);
 execute format('create trigger hr_contract_guard before insert or update or delete on public.%I for each row execute function public.hr_contract_guard()',t);
 execute format('drop trigger if exists hr_contract_audit on public.%I',t);
 execute format('create trigger hr_contract_audit after insert or update or delete on public.%I for each row execute function public.hr_log_change()',t);
 end loop;end $$;
create or replace function public.hr_contract_base(p_employee_id uuid,p_month text,p_require_statement boolean) returns jsonb language plpgsql security definer set search_path=pg_catalog,public as $$
declare e jsonb;pol jsonb;first_d date;last_d date;a date;b date;end_d date;calendar_days integer;pay_days integer;weight numeric;c public.hr_contracts;u record;d date;k text;
 pay_factor numeric;amounts jsonb:='{"basic":0,"housing":0,"transport":0,"other":0}';gross numeric:=0;v numeric;hours numeric:=0;prior_hours numeric;ids jsonb:='[]';unit boolean:=false;s public.hr_contract_months;monthly numeric;
begin
 select to_jsonb(x) into e from public.employees x where id=p_employee_id;perform public.hr_require_finance((e->>'company_id')::uuid);
 select coalesce(policy_settings,'{}') into pol from public.companies where id=(e->>'company_id')::uuid;
 if not exists(select 1 from public.hr_contracts where employee_id=p_employee_id and status='approved') then
  if pol->>'hr_contracts_required' is distinct from 'false' then raise exception 'Approved contract required before payroll';end if;return null;
 end if;
 first_d:=public.hr_parse_date(p_month||'-01');last_d:=(first_d+interval '1 month'-interval '1 day')::date;
 if coalesce((e->>'is_terminated')::boolean,false) then end_d:=public.hr_parse_date(e->>'clearance_last_day');end if;
 a:=greatest(public.hr_parse_date(e->>'start_date'),first_d);b:=least(coalesce(end_d,last_d),last_d);calendar_days:=greatest(0,b-a+1);
 pay_days:=case when calendar_days=0 then 0 when a=first_d and b=last_d then 30 else least(30,calendar_days) end;weight:=case when calendar_days>0 then pay_days::numeric/calendar_days else 0 end;
 for d in select generate_series(a::timestamp,b::timestamp,interval '1 day')::date loop
  select * into c from public.hr_contracts where employee_id=p_employee_id and status='approved' and start_date<=d and (end_date is null or end_date>=d);
  if not found then raise exception 'Contract coverage gap %',d;end if;
  if not ids ? c.id::text then ids:=ids||jsonb_build_array(c.id);end if;
  if c.basis='monthly' then foreach k in array array['basic','housing','transport','other'] loop v:=(amounts->>k)::numeric+(c.financials->>k)::numeric/30*weight;amounts:=jsonb_set(amounts,array[k],to_jsonb(v));end loop;else unit:=true;end if;
 end loop;
 if exists(select 1 from public.hr_contract_entries where employee_id=p_employee_id and left(work_date::text,7)=p_month and status='draft') then raise exception 'Unapproved work entries';end if;
 for u in select x.*,ct.financials,ct.basis,ct.pattern,ct.flex_same_rate from public.hr_contract_entries x join public.hr_contracts ct on ct.id=x.contract_id where x.employee_id=p_employee_id and x.status='approved' and left(x.work_date::text,7)=p_month order by x.work_date,x.id loop
  if u.work_date not between a and b or not ids ? u.contract_id::text then raise exception 'Work outside employment/contract period';end if;
  if u.basis='monthly' then raise exception 'Duplicate units in monthly wage';end if;
  pay_factor:=case when u.kind='paid_leave' then public.hr_contract_leave_factor(p_employee_id,u.work_date,u.leave_request_id) else 1 end;
  prior_hours:=hours;hours:=hours+case when u.pattern='flex' then u.quantity else 0 end;
  foreach k in array array['basic','housing','transport','other'] loop
   v:=(amounts->>k)::numeric+(u.financials->>k)::numeric*u.quantity*pay_factor/case when u.kind='overtime' and u.basis='daily' then (select daily_hours from hr_contracts where id=u.contract_id) else 1 end;
   if u.kind='overtime' and k='basic' then v:=v+(u.financials->>'basic')::numeric*.5*u.quantity/case when u.basis='daily' then (select daily_hours from hr_contracts where id=u.contract_id) else 1 end;end if;
   if u.pattern='flex' and not u.flex_same_rate and k='basic' then v:=v+(u.financials->>'basic')::numeric*.5*(greatest(0,hours-95)-greatest(0,prior_hours-95));end if;
   amounts:=jsonb_set(amounts,array[k],to_jsonb(v));
  end loop;
 end loop;
 if hours>160 then raise exception 'Flexible maximum 160 hours';end if;
 if jsonb_array_length(ids)>1 and exists(select 1 from public.hr_contracts where ids ? id::text and pattern='flex') then raise exception 'Flexible transition requires separate monthly period';end if;
 foreach k in array array['basic','housing','transport','other'] loop gross:=gross+(amounts->>k)::numeric;v:=round((amounts->>k)::numeric,2);amounts:=jsonb_set(amounts,array[k],to_jsonb(v));end loop;
 gross:=round(gross,2);amounts:=jsonb_set(amounts,'{other}',to_jsonb(round(gross-(amounts->>'basic')::numeric-(amounts->>'housing')::numeric-(amounts->>'transport')::numeric,2)));
 select * into s from public.hr_contract_months where employee_id=p_employee_id and month=p_month and status='approved';if not found and p_require_statement then raise exception 'Approved monthly insurance statement required';end if;
 monthly:=case when pay_days>0 then round(gross/(pay_days::numeric/30),2) else 0 end;
 return jsonb_build_object('components',amounts,'gross',gross,'monthlyTotal',monthly,'gosi',s.gosi_employee,'companyGosi',s.gosi_company,'contractIds',ids,'statementId',s.id,'unit',unit);
end $$;
create or replace function public.hr_contract_base(p_employee_id uuid,p_month text) returns jsonb language sql security definer set search_path=pg_catalog,public as $$select public.hr_contract_base(p_employee_id,p_month,true)$$;
revoke execute on function public.hr_contract_guard(),public.hr_contract_base(uuid,text),public.hr_contract_base(uuid,text,boolean) from public,anon;
grant execute on function public.hr_contract_base(uuid,text),public.hr_contract_base(uuid,text,boolean) to authenticated;
create or replace function public.hr_expected_payroll(p_employee_id uuid,p_month text) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public as $$
declare e jsonb;v public.hr_compensation_versions;f jsonb;c jsonb;pol jsonb;
  first_day date;last_day date;start_day date;end_day date;a date;b date;calendar_days integer;pay_days integer;ratio numeric;
  total_wage numeric;gross numeric;basic numeric;housing numeric;transport numeric;other numeric;
  rate_emp numeric;rate_co numeric;insured numeric;gosi numeric;factor numeric;is_new boolean;saudi boolean;status text;rate_key text;
  loss numeric:=0;time_deductions numeric:=0;absence_seen boolean:=false;leave_count integer:=0;leaf record;anchor date;next_anchor date;sick integer:=0;fraction numeric;
  adds numeric:=0;deds numeric:=0;loans numeric:=0;op record;j jsonb;value numeric;inst integer;em text;relevant boolean;sign integer;
  adjustment record;result jsonb;cb jsonb;ct public.hr_contracts;contract_loss numeric:=0;
begin
 if p_month !~ '^\d{4}-(0[1-9]|1[0-2])$' then raise exception 'Invalid payroll month';end if;
 select to_jsonb(x) into e from public.employees x where id=p_employee_id;
 if e is null then raise exception 'Employee not found';end if;
 perform public.hr_require_finance((e->>'company_id')::uuid);
 select to_jsonb(x) into c from public.companies x where id=(e->>'company_id')::uuid;pol:=coalesce(c->'policy_settings','{}');
 first_day:=to_date(p_month||'-01','YYYY-MM-DD');last_day:=(first_day+(interval '1 month' - interval '1 day'))::date;
 start_day:=public.hr_parse_date(e->>'start_date');
 if coalesce((e->>'is_terminated')::boolean,false) then end_day:=public.hr_parse_date(e->>'clearance_last_day');if end_day is null then raise exception 'Terminated employee missing end date';end if;end if;
 if start_day is null or end_day<start_day then raise exception 'Invalid employment period';end if;
 if coalesce((e->>'is_archived')::boolean,false) and end_day is null then raise exception 'Archived employee requires an employment end date';end if;
 a:=greatest(start_day,first_day);b:=least(coalesce(end_day,last_day),last_day);calendar_days:=greatest(0,b-a+1);
 pay_days:=case when calendar_days=0 then 0 when a=first_day and b=last_day then 30 else least(30,calendar_days) end;ratio:=pay_days::numeric/30;
 cb:=public.hr_contract_base(p_employee_id,p_month);
 select * into v from public.hr_compensation_versions where employee_id=p_employee_id and effective_from<=first_day order by effective_from desc limit 1;
 if not found and cb is null then raise exception 'No dated compensation for employee % month %',p_employee_id,p_month;end if;
 f:=v.financials;
 if cb is not null then f:=jsonb_build_object('total',cb->'monthlyTotal','basic',case when ratio>0 then (cb#>>'{components,basic}')::numeric/ratio else 0 end,'housing',case when ratio>0 then (cb#>>'{components,housing}')::numeric/ratio else 0 end,'transport',case when ratio>0 then (cb#>>'{components,transport}')::numeric/ratio else 0 end,'other',case when ratio>0 then (cb#>>'{components,other}')::numeric/ratio else 0 end,'isNewGosi',false);end if;
 total_wage:=(f->>'total')::numeric;
 if cb is null and pay_days>0 and total_wage<=0 then raise exception 'Eligible employee requires positive wage';end if;
 basic:=round((f->>'basic')::numeric*ratio,2);housing:=round((f->>'housing')::numeric*ratio,2);transport:=round((f->>'transport')::numeric*ratio,2);gross:=round(total_wage*ratio,2);other:=gross-basic-housing-transport;
 if (f->>'other')::numeric<0 or abs(total_wage-(f->>'basic')::numeric-(f->>'housing')::numeric-(f->>'transport')::numeric-(f->>'other')::numeric)>0.01 then raise exception 'Wage components mismatch';end if;
 status:=coalesce(v.gosi_status,case when public.hr_is_saudi(e->>'nationality') then 'سعودي بالتأمينات' else 'أجنبي بالتأمينات' end);
 saudi:=status like 'سعودي%';is_new:=coalesce((f->>'isNewGosi')::boolean,false);
 if saudi is distinct from public.hr_is_saudi(e->>'nationality') then raise exception 'Nationality/GOSI status conflict';end if;
 rate_key:=case when not saudi then 'nonsa' when is_new then 'saudi26' else 'saudi' end;
 rate_emp:=case when saudi then 9.75 else 0 end;rate_co:=case when saudi then 11.75 else 2 end;
 if saudi and is_new then
  rate_emp:=rate_emp+case when first_day>='2028-07-01' then 2 when first_day>='2027-07-01' then 1.5 when first_day>='2026-07-01' then 1 when first_day>='2025-07-01' then 0.5 else 0 end;rate_co:=rate_emp+2;
 end if;
 if status like '%خارج%' or pol#>>array['gosi',rate_key,'active']='false' then rate_emp:=0;rate_co:=0;
 elsif pol#>>array['gosi',rate_key,'exempt']='true' then rate_emp:=0;end if;
 if cb is null and not coalesce((e->>'hr_gosi_verified')::boolean,false) then raise exception 'Verify GOSI cohort against its statement before payroll close';end if;
 insured:=least(45000,(f->>'basic')::numeric+(f->>'housing')::numeric);
 factor:=case when pay_days=0 then 0 when is_new then ratio when end_day is null or end_day>=last_day or to_char(start_day,'YYYY-MM')=p_month then 1 else 0 end;
 gosi:=case when cb is null then round(insured*rate_emp/100*factor,2) else (cb->>'gosi')::numeric end;
 if cb is not null then gross:=(cb->>'gross')::numeric;basic:=(cb#>>'{components,basic}')::numeric;housing:=(cb#>>'{components,housing}')::numeric;transport:=(cb#>>'{components,transport}')::numeric;other:=(cb#>>'{components,other}')::numeric;end if;
 if cb is null and not is_new and factor=1 and abs((f->>'gosi')::numeric-gosi)>0.01 then raise exception 'Stored GOSI conflicts with verified amount';end if;
 if exists(select 1 from public.employee_requests r where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved'
  and ((to_jsonb(r)->>'days')::numeric<>public.hr_parse_date(to_jsonb(r)->>'date_to')-public.hr_parse_date(to_jsonb(r)->>'date_from')+1)) then raise exception 'Leave dates/days mismatch';end if;
 if exists(select d from public.employee_requests r cross join lateral generate_series(public.hr_parse_date(to_jsonb(r)->>'date_from')::timestamp,public.hr_parse_date(to_jsonb(r)->>'date_to')::timestamp,interval '1 day') d
  where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved' group by d having count(*)>1) then raise exception 'Approved leave overlap';end if;
 for leaf in select d::date as work_day,r.sub_type from public.employee_requests r
  cross join lateral generate_series(public.hr_parse_date(to_jsonb(r)->>'date_from')::timestamp,public.hr_parse_date(to_jsonb(r)->>'date_to')::timestamp,interval '1 day') d
  where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved' order by d loop
  fraction:=0;
  if cb is not null then
   select * into ct from public.hr_contracts ct0 where ct0.employee_id=p_employee_id and ct0.status='approved' and ct0.start_date<=leaf.work_day and (ct0.end_date is null or ct0.end_date>=leaf.work_day);
   if found and ct.basis<>'monthly' then continue;end if;
   if found and leaf.sub_type ~ 'مرض' and not(ct.pattern='part' or ct.pattern='full' and ct.nature='ordinary' and ct.term<>'training') then raise exception 'Sick leave outside contract entitlement';end if;
   if found and leaf.sub_type ~ 'سنوي' and ct.annual_days=0 and not(ct.pattern='part' or ct.term='training' or ct.pattern='full' and ct.nature='ordinary') then raise exception 'Annual leave outside contract entitlement';end if;
  end if;
  if leaf.sub_type ~ 'غير مدفوعة|دون أجر|بدون أجر' or leaf.sub_type='غياب بدون عذر' or coalesce(pol->'leavesUnpaid','{}') ? leaf.sub_type then fraction:=1;
  elsif leaf.sub_type ~ 'مرض' then
   if anchor is null or leaf.work_day>=(anchor+interval '1 year')::date then anchor:=leaf.work_day;sick:=0;end if;
   sick:=sick+1;fraction:=case when sick<=30 then 0 when sick<=90 then .25 else 1 end;
   if sick>120 and to_char(leaf.work_day,'YYYY-MM')=p_month then raise exception 'Sick entitlement exceeds 120 days';end if;
  end if;
  if leaf.work_day between a and b then leave_count:=leave_count+1;loss:=loss+fraction;if cb is not null then contract_loss:=contract_loss+(ct.financials->>'total')::numeric/30*fraction;end if;end if;
 end loop;
 if loss=calendar_days and calendar_days>0 then loss:=pay_days;end if;
 loss:=least(pay_days,loss);deds:=round(least(gross,case when cb is null then total_wage/30*loss when loss=pay_days and leave_count=calendar_days then gross else contract_loss end),2);
 time_deductions:=deds;
 for op in select * from public.hr_operations where employee_id=p_employee_id and company_id=(e->>'company_id')::uuid
  and module in ('fin_allowance','fin_deduction','fin_annual','fin_repay','fin_absence','fin_perf','fin_overtime','assignment','fin_extra') loop
  j:=to_jsonb(op);em:=j->>'effective_month';
  if pay_days=0 or j->>'status' in ('stopped','cancelled','rejected') or j#>>'{data,flow,state}' in ('cancelled','rejected') then continue;end if;
  if j->>'module'='fin_repay' then value:=public.hr_loan_installment((j->>'amount')::numeric,coalesce((j#>>'{data,installments}')::integer,1),em,p_month);relevant:=value>0;
  elsif coalesce((j->>'recurring')::boolean,false) then relevant:=em<=p_month;
  else relevant:=em=p_month;end if;
  if not coalesce(relevant,false) then continue;end if;
  if coalesce(j#>>'{data,flow,state}','new') not in ('approved','authorized','completed') then raise exception 'Unapproved financial operation %',j->>'id';end if;
  if cb->>'unit'='true' and j->>'module' in ('fin_absence','fin_overtime') then raise exception 'Unit contract absence/overtime must use contract work ledger';end if;
  sign:=case when j->>'module' in ('fin_deduction','fin_repay','fin_absence') then -1 else 1 end;
  if j->>'module'='fin_absence' then
   if absence_seen then raise exception 'Multiple active absence records require reconciliation';end if;absence_seen:=true;
   if (j->>'days')::numeric>calendar_days then raise exception 'Absence exceeds service period';end if;
   if jsonb_typeof(j#>'{data,absence_dates}')='array' then
    if (select count(distinct d) from jsonb_array_elements_text(j#>'{data,absence_dates}') d)<>(j->>'days')::numeric then raise exception 'Absence date count mismatch';end if;
    if exists(select 1 from jsonb_array_elements_text(j#>'{data,absence_dates}') ad
      where left(ad,7)<>p_month or public.hr_parse_date(ad) not between a and b or exists(select 1 from public.employee_requests r where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved' and public.hr_parse_date(ad) between public.hr_parse_date(to_jsonb(r)->>'date_from') and public.hr_parse_date(to_jsonb(r)->>'date_to'))) then raise exception 'Absence/leave date overlap';end if;
   elsif leave_count>0 and (j->>'days')::numeric>0 then raise exception 'Absence dates required to avoid leave double deduction';end if;
   if cb is not null and jsonb_typeof(j#>'{data,absence_dates}')='array' then select round(sum((ct0.financials->>'total')::numeric/30),2) into value from jsonb_array_elements_text(j#>'{data,absence_dates}') ad join hr_contracts ct0 on ct0.employee_id=p_employee_id and ct0.status='approved' and ad::date between ct0.start_date and coalesce(ct0.end_date,'9999-12-31');elsif cb is not null and jsonb_array_length(cb->'contractIds')>1 and (j->>'days')::numeric>0 then raise exception 'Absence dates required for mixed contracts';else value:=round(total_wage/30*(j->>'days')::numeric,2);end if;
   time_deductions:=time_deductions+value;
  elsif j->>'module'<>'fin_repay' then value:=coalesce((j->>'amount')::numeric,0);end if;
  if value<0 then raise exception 'Negative financial operation';end if;
  if j->>'module'='fin_extra' and j#>>'{data,auto}'='true' and coalesce(j#>>'{data,verified_unpaid_period}','false')<>'true' then raise exception 'Unverified starting wage duplication';end if;
  if j->>'module'='fin_repay' then loans:=loans+value;end if;
  if sign>0 then adds:=adds+value;else deds:=deds+value;end if;
 end loop;
 for adjustment in select * from public.salary_adjustments where employee_id=p_employee_id and (month=p_month or is_recurring and month<=p_month) loop
   j:=to_jsonb(adjustment);value:=(j->>'amount')::numeric;
   if value<0 or j->>'adjustment_type' not in ('increase','allowance','bonus','deduction') then raise exception 'Invalid wage adjustment';end if;
   if j->>'adjustment_type'='deduction' then deds:=deds+value;else adds:=adds+value;end if;
 end loop;
 adds:=round(adds,2);deds:=round(deds,2);
 if abs(adds)>1000000000 or abs(deds)>1000000000 or abs(gross+adds-gosi-deds)>1000000000 then raise exception 'Financial totals outside safe processing bounds';end if;
 if loans>round(greatest(0,gross-time_deductions)*.1,2) then raise exception 'Loan deduction exceeds 10 percent';end if;
 if gosi+deds-time_deductions>(gross-time_deductions+adds)/2 or gross+adds-gosi-deds<0 then raise exception 'Deduction cap or negative net';end if;
 result:=jsonb_build_object('basic',basic,'housing',housing,'transport',transport,'other',other,'total',gross,'monthlyTotal',total_wage,'gosi',gosi,'companyGosi',case when cb is null then round(insured*rate_co/100*factor,2) else (cb->>'companyGosi')::numeric end,'addT',adds,'dedT',deds,'net',round(gross+adds-gosi-deds,2),'payDays',pay_days,'compensationVersion',v.id,'contractIds',coalesce(cb->'contractIds','[]'),'contractStatementId',cb->'statementId');
 return result;
end $$;

create or replace function public.hr_loan_guard() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare e jsonb;f jsonb;r record;n integer;wage numeric;existing numeric;cap numeric;period date;a date;b date;days integer;ratio numeric;inst numeric;target text;cb jsonb;
begin
 if new.module<>'fin_repay' or new.status in ('cancelled','rejected','stopped') or new.data#>>'{flow,state}' in ('cancelled','rejected') then return new;end if;
 n:=coalesce((new.data->>'installments')::integer,1);
 if n not between 1 and 120 or new.amount<=0 or new.effective_month !~ '^\d{4}-(0[1-9]|1[0-2])$' then raise exception 'Invalid loan schedule';end if;
 select to_jsonb(x) into e from public.employees x where id=new.employee_id and company_id=new.company_id;
 if e is null then raise exception 'Employee/company mismatch';end if;
 for i in 0..n-1 loop
  period:=(to_date(new.effective_month||'-01','YYYY-MM-DD')+i*interval '1 month')::date;target:=to_char(period,'YYYY-MM');
  select financials into f from public.hr_compensation_versions where employee_id=new.employee_id and effective_from<=period order by effective_from desc limit 1;
  if f is null then raise exception 'Dated wage required for loan affordability';end if;wage:=(f->>'total')::numeric;
  a:=greatest(public.hr_parse_date(e->>'start_date'),period);b:=(period+interval '1 month'-interval '1 day')::date;
  if coalesce((e->>'is_terminated')::boolean,false) then b:=least(b,public.hr_parse_date(e->>'clearance_last_day'));end if;
  days:=greatest(0,b-a+1);ratio:=case when a=period and b=(period+interval '1 month'-interval '1 day')::date then 1 else least(30,days)::numeric/30 end;
  select coalesce(sum(public.hr_loan_installment(o.amount,coalesce((o.data->>'installments')::integer,1),o.effective_month,target)),0) into existing from public.hr_operations o where o.company_id=new.company_id and o.employee_id=new.employee_id and o.module='fin_repay' and o.id<>new.id and coalesce(o.status,'') not in ('cancelled','rejected','stopped') and coalesce(o.data#>>'{flow,state}','') not in ('cancelled','rejected');
  cb:=public.hr_contract_base(new.employee_id,target,false);if cb is not null then wage:=(cb->>'gross')::numeric;ratio:=1;end if;
  cap:=round(wage*ratio*.1,2);inst:=public.hr_loan_installment(new.amount,n,new.effective_month,target);
  if existing+inst>cap then raise exception 'Loan collision in %: installment % existing % cap %',target,inst,existing,cap;end if;
 end loop;return new;
end $$;
create or replace function public.hr_finance_fingerprint(p_company_id uuid) returns text
language plpgsql security definer set search_path=pg_catalog,public as $$
declare payload jsonb;begin
 perform public.hr_require_finance(p_company_id);
 select jsonb_build_object(
 'employees',coalesce((select jsonb_agg(to_jsonb(e) order by e.id) from public.employees e where e.company_id=p_company_id),'[]'),
 'versions',coalesce((select jsonb_agg(to_jsonb(v) order by v.id) from public.hr_compensation_versions v where v.company_id=p_company_id),'[]'),
 'operations',coalesce((select jsonb_agg(to_jsonb(o) order by o.id) from public.hr_operations o where o.company_id=p_company_id),'[]'),
 'requests',coalesce((select jsonb_agg(to_jsonb(r) order by r.id) from public.employee_requests r where r.company_id=p_company_id),'[]'),
 'adjustments',coalesce((select jsonb_agg(to_jsonb(a) order by a.id) from public.salary_adjustments a join public.employees e on e.id=a.employee_id where e.company_id=p_company_id),'[]'),
 'contracts',coalesce((select jsonb_agg(to_jsonb(x) order by x.id) from public.hr_contracts x where company_id=p_company_id),'[]'),
 'contract_entries',coalesce((select jsonb_agg(to_jsonb(x) order by x.id) from public.hr_contract_entries x where company_id=p_company_id),'[]'),
 'contract_months',coalesce((select jsonb_agg(to_jsonb(x) order by x.id) from public.hr_contract_months x where company_id=p_company_id),'[]'),
 'policy',(select to_jsonb(c) from public.companies c where c.id=p_company_id)) into payload;
 return md5(payload::text);
end $$;

create or replace function public.hr_backup_fingerprint(p_company_id uuid) returns text
language plpgsql security definer set search_path=pg_catalog,public as $$
declare t text;rows jsonb;payload jsonb:='{}';begin
 if coalesce(public.hr_company_role(p_company_id),'') not in ('owner','admin') then raise exception 'Backup administrator permission required' using errcode='42501';end if;
 foreach t in array array['employees','hr_operations','employee_requests','salary_adjustments','departments','custody_items','employee_documents','employee_attendance','document_templates','hr_communications','ask_knowledge','company_members','hr_compensation_versions','hr_payroll_runs','hr_audit_events','hr_finance_commands','hr_contracts','hr_contract_entries','hr_contract_months'] loop
  if t in ('salary_adjustments','custody_items','employee_documents') then
   execute format('select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]'') from public.%I x join public.employees e on e.id=x.employee_id where e.company_id=$1',t) into rows using p_company_id;
  else execute format('select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]'') from public.%I x where x.company_id=$1',t) into rows using p_company_id;end if;
  payload:=payload||jsonb_build_object(t,rows);
 end loop;
 select payload||jsonb_build_object('company',to_jsonb(c)) into payload from public.companies c where c.id=p_company_id;
 payload:=payload||jsonb_build_object('files',public.hr_backup_manifest(p_company_id));return md5(payload::text);
end $$;
create or replace function public.hr_close_payroll(p_company_id uuid,p_month text,p_rows jsonb,p_source_fingerprint text,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public as $$
declare cmd public.hr_finance_commands;body jsonb:=jsonb_build_object('month',p_month,'rows',p_rows,'fingerprint',p_source_fingerprint);
 run public.hr_payroll_runs;row jsonb;e jsonb;expected jsonb;key text;count_expected integer;count_actual integer;method text;first_day date;last_day date;result jsonb;
begin
 perform public.hr_lock_company(p_company_id);
 select * into cmd from public.hr_finance_commands where request_id=p_request_id;
 if found then if cmd.company_id<>p_company_id or cmd.command<>'close' or cmd.request_body<>body then raise exception 'Idempotency input mismatch';end if;return cmd.result;end if;
 if p_month !~ '^\d{4}-(0[1-9]|1[0-2])$' or jsonb_typeof(p_rows)<>'array' or jsonb_array_length(p_rows)=0 then raise exception 'Invalid payroll';end if;
 if exists(select 1 from public.hr_payroll_runs where company_id=p_company_id and month=p_month) then raise exception 'Month already closed';end if;
 if public.hr_finance_fingerprint(p_company_id)<>p_source_fingerprint then raise exception 'Sources changed; reload and review';end if;
 first_day:=to_date(p_month||'-01','YYYY-MM-DD');last_day:=(first_day+(interval '1 month' - interval '1 day'))::date;
 select count(*) into count_expected from public.employees x where company_id=p_company_id and public.hr_parse_date(to_jsonb(x)->>'start_date')<=last_day
  and (not coalesce((to_jsonb(x)->>'is_terminated')::boolean,false) or public.hr_parse_date(to_jsonb(x)->>'clearance_last_day')>=first_day);
 select count(distinct entry#>>'{e,id}') into count_actual from jsonb_array_elements(p_rows) entry;
 if count_actual<>jsonb_array_length(p_rows) or count_actual<>count_expected then raise exception 'Payroll employee coverage mismatch';end if;
 for row in select * from jsonb_array_elements(p_rows) loop
  select to_jsonb(x) into e from public.employees x where id=(row#>>'{e,id}')::uuid and company_id=p_company_id;
  if e is null then raise exception 'Employee/company mismatch';end if;
  expected:=public.hr_expected_payroll((e->>'id')::uuid,p_month);
  if coalesce(row#>'{p,contractIds}','[]')<>coalesce(expected->'contractIds','[]') or row#>'{p,contractStatementId}' is distinct from coalesce(expected->'contractStatementId','null') then raise exception 'Contract provenance mismatch';end if;
  if (expected->>'payDays')::integer<=0 then raise exception 'Ineligible employee in payroll';end if;
  foreach key in array array['basic','housing','transport','other','total','monthlyTotal','gosi','companyGosi','addT','dedT','net'] loop
   if row#>>array['p',key] is null or abs((row#>>array['p',key])::numeric-(expected->>key)::numeric)>0.009 then raise exception 'Payroll calculation mismatch %, employee %',key,e->>'id';end if;
  end loop;
  if row#>>'{p,service,payDays}' is null or (row#>>'{p,service,payDays}')::integer<>(expected->>'payDays')::integer
    or coalesce(jsonb_array_length(row#>'{p,errors}'),1)<>0 then raise exception 'Payroll validation mismatch';end if;
  foreach key in array array['name','nid','nationality','iban'] loop
   if coalesce(row#>>array['e',key],'')<>coalesce(e->>key,'') then raise exception 'Payroll identity differs from source';end if;
  end loop;
  if row#>>'{e,companyId}' is distinct from p_company_id::text or coalesce(row#>>'{e,empNumber}','')<>coalesce(e->>'emp_number','') or coalesce(row#>>'{e,departmentId}','')<>coalesce(e->>'department_id','') then raise exception 'Payroll organisation identity mismatch';end if;
  if e->>'nid' !~ '^\d{10}$' or length(trim(coalesce(e->>'name','')))=0 then raise exception 'Payroll employee identity incomplete';end if;
  if row->>'iban' is distinct from upper(regexp_replace(coalesce(e->>'iban',''),'\s','','g')) then raise exception 'Transfer IBAN differs from source';end if;
  if jsonb_typeof(row#>'{p,adds}') is distinct from 'array' or jsonb_typeof(row#>'{p,deds}') is distinct from 'array' then raise exception 'Missing payroll detail';end if;
  if abs(coalesce((select sum((x->>'amount')::numeric) from jsonb_array_elements(row#>'{p,adds}') x),0)-(expected->>'addT')::numeric)>0.009
     or abs(coalesce((select sum((x->>'amount')::numeric) from jsonb_array_elements(row#>'{p,deds}') x),0)-(expected->>'dedT')::numeric)>0.009 then raise exception 'Payroll detail totals mismatch';end if;
  if exists(select 1 from jsonb_array_elements((row#>'{p,adds}')||(row#>'{p,deds}')) x where x->>'amount' is null or (x->>'amount')::numeric<0) then raise exception 'Invalid payroll detail amount';end if;
  method:=coalesce(e->>'pay_method','');
  if method not in ('wps','bank','cash') then method:='wps';end if;
  if coalesce(row->>'method','')<>method then raise exception 'Payment method mismatch';end if;
  if method<>'cash' and not public.hr_iban_valid(e->>'iban') then raise exception 'Invalid IBAN';end if;
  if method<>'cash' and (public.hr_bank_info(p_company_id,e->>'iban') is null or row->'bank' is distinct from public.hr_bank_info(p_company_id,e->>'iban')) then raise exception 'Bank identity differs from approved register';end if;
  if method='cash' and length(trim(coalesce(e->>'pay_method_note','')))=0 then raise exception 'Cash exception must be documented';end if;
 end loop;
 insert into public.hr_payroll_runs(company_id,month,rows,source_fingerprint,closed_by) values(p_company_id,p_month,p_rows,p_source_fingerprint,auth.uid()) returning * into run;
 result:=jsonb_build_object('ok',true,'id',run.id,'month',p_month);
 insert into public.hr_finance_commands values(p_request_id,p_company_id,'close',body,result,auth.uid(),now());return result;
end $$;
revoke execute on function public.hr_expected_payroll(uuid,text),public.hr_close_payroll(uuid,text,jsonb,text,uuid) from public,anon;
grant execute on function public.hr_expected_payroll(uuid,text),public.hr_close_payroll(uuid,text,jsonb,text,uuid) to authenticated;
create or replace function public.hr_employee_integrity_guard() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
begin
 if tg_op='UPDATE' and row(new.total_salary,new.basic_salary,new.housing_allowance,new.transport_allowance,new.other_allowances) is distinct from row(old.total_salary,old.basic_salary,old.housing_allowance,old.transport_allowance,old.other_allowances) and exists(select 1 from public.hr_contracts where employee_id=new.id and status='approved') then raise exception 'Registered wage must change through an evidenced contract version';end if;
 if new.annual_leave_days is not null and (new.annual_leave_days<21 or new.annual_leave_days>366) then raise exception 'Annual contractual entitlement out of range';end if;
 if new.leave_opening_balance is not null then
  if coalesce(new.leave_opening_balance->>'year','') !~ '^\d{4}$' or coalesce(new.leave_opening_balance->>'days','') !~ '^\d+(\.\d+)?$' or length(trim(coalesce(new.leave_opening_balance->>'evidence','')))=0 then raise exception 'Opening leave balance requires year, nonnegative days, evidence';end if;
 end if;
 if new.hr_gosi_verified and length(trim(coalesce(new.hr_gosi_evidence,'')))<4 then raise exception 'Verified GOSI requires evidence reference';end if;
 if tg_op='UPDATE' and (new.is_new_gosi is distinct from old.is_new_gosi or new.gosi_status is distinct from old.gosi_status or new.nationality is distinct from old.nationality) then new.hr_gosi_verified:=false;new.hr_gosi_evidence:=null;end if;
 return new;
end $$;

create or replace function public.hr_portal_contracts(p_token text,p_last4 text) returns jsonb language plpgsql security definer set search_path=pg_catalog,public as $$
declare e jsonb;eid uuid;co uuid;result jsonb;begin
 if length(coalesce(p_token,''))<16 or p_last4 !~ '^\d{4}$' then raise exception 'Invalid portal credentials';end if;
 select to_jsonb(x) into e from public.employees x where portal_token=p_token and coalesce((to_jsonb(x)->>'portal_enabled')::boolean,false) and right(nid,4)=p_last4;
 if e is null then raise exception 'Invalid portal credentials';end if;eid:=(e->>'id')::uuid;co:=(e->>'company_id')::uuid;
 select jsonb_build_object('contracts',coalesce((select jsonb_agg(to_jsonb(x)-'evidence'-'platform_reference'-'extension_consent'-'closure_evidence' order by start_date) from public.hr_contracts x where employee_id=eid and status='approved'),'[]'),
 'months',coalesce((select jsonb_agg((to_jsonb(x)-'evidence'-'eos_evidence')||jsonb_build_object('eos_basis_verified',length(x.eos_evidence)>0)) from public.hr_contract_months x where employee_id=eid and status='approved'),'[]'),
 'required',coalesce((policy_settings->>'hr_contracts_required')::boolean,true)) into result from public.companies where id=co;return result;
end $$;
revoke execute on function public.hr_portal_contracts(text,text) from public;
grant execute on function public.hr_portal_contracts(text,text) to anon,authenticated;
commit;
