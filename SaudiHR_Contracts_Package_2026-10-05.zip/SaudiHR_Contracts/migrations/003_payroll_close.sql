-- Independent server verification of every closed payroll row.
begin;
create or replace function public.hr_parse_date(value text) returns date
language plpgsql stable set search_path=pg_catalog,public as $$
declare d date;begin
 if value is null or value='' then return null;end if;
 if value !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'Invalid civil date: %',value;end if;
 if left(value,4)::integer>=1700 then
   d:=value::date;
   if to_char(d,'YYYY-MM-DD')<>value then raise exception 'Invalid date';end if;
 else select gregorian into d from public.hr_calendar_dates where hijri=value;
   if d is null then raise exception 'Hijri date outside verified calendar';end if;
 end if;return d;
end $$;
create or replace function public.hr_iban_valid(value text) returns boolean
language plpgsql immutable as $$
declare s text:=upper(regexp_replace(coalesce(value,''),'\s','','g'));digits text;r integer:=0;i integer;
begin
 if s !~ '^SA\d{22}$' then return false;end if;
 digits:=substring(s from 5)||'2810'||substring(s from 3 for 2);
 for i in 1..length(digits) loop r:=(r*10+substring(digits from i for 1)::integer)%97;end loop;
 return r=1;
end $$;
create or replace function public.hr_loan_installment(amount numeric,n integer,start_month text,target_month text) returns numeric
language plpgsql immutable as $$
declare i integer;cents numeric;base numeric;
begin
 if n not between 1 and 120 or amount<=0 or start_month !~ '^\d{4}-(0[1-9]|1[0-2])$' then raise exception 'Invalid loan';end if;
 i:=(left(target_month,4)::integer-left(start_month,4)::integer)*12+right(target_month,2)::integer-right(start_month,2)::integer;
 if i<0 or i>=n then return 0;end if;
 cents:=round(amount*100);base:=floor(cents/n);
 return (case when i=n-1 then cents-base*(n-1) else base end)/100;
end $$;
create or replace function public.hr_expected_payroll(p_employee_id uuid,p_month text) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public as $$
declare e jsonb;v public.hr_compensation_versions;f jsonb;c jsonb;pol jsonb;
  first_day date;last_day date;start_day date;end_day date;a date;b date;calendar_days integer;pay_days integer;ratio numeric;
  total_wage numeric;gross numeric;basic numeric;housing numeric;transport numeric;other numeric;
  rate_emp numeric;rate_co numeric;insured numeric;gosi numeric;factor numeric;is_new boolean;saudi boolean;status text;rate_key text;
  loss numeric:=0;time_deductions numeric:=0;absence_seen boolean:=false;leave_count integer:=0;leaf record;anchor date;next_anchor date;sick integer:=0;fraction numeric;
  adds numeric:=0;deds numeric:=0;loans numeric:=0;op record;j jsonb;value numeric;inst integer;em text;relevant boolean;sign integer;
  adjustment record;result jsonb;
begin
 if p_month !~ '^\d{4}-(0[1-9]|1[0-2])$' then raise exception 'Invalid payroll month';end if;
 select to_jsonb(x) into e from public.employees x where id=p_employee_id;
 if e is null then raise exception 'Employee not found';end if;
 perform public.hr_require_finance((e->>'company_id')::uuid);
 select to_jsonb(x) into c from public.companies x where id=(e->>'company_id')::uuid;pol:=coalesce(c->'policy_settings','{}');
 first_day:=to_date(p_month||'-01','YYYY-MM-DD');last_day:=(first_day+(interval '1 month' - interval '1 day'))::date;
 start_day:=public.hr_parse_date(e->>'start_date');
 if coalesce((e->>'is_terminated')::boolean,false) then end_day:=public.hr_parse_date(e->>'clearance_last_day');if end_day is null then raise exception 'Terminated employee missing end date';end if;end if;
 if start_day is null or end_day<start_day then raise exception 'Invalid employment period';end if;
 if coalesce((e->>'is_archived')::boolean,false) and end_day is null then raise exception 'Archived employee requires an employment end date';end if;
 a:=greatest(start_day,first_day);b:=least(coalesce(end_day,last_day),last_day);calendar_days:=greatest(0,b-a+1);
 pay_days:=case when calendar_days=0 then 0 when a=first_day and b=last_day then 30 else least(30,calendar_days) end;ratio:=pay_days::numeric/30;
 select * into v from public.hr_compensation_versions where employee_id=p_employee_id and effective_from<=first_day order by effective_from desc limit 1;
 if not found then raise exception 'No dated compensation for employee % month %',p_employee_id,p_month;end if;
 f:=v.financials;
 total_wage:=(f->>'total')::numeric;
 if pay_days>0 and total_wage<=0 then raise exception 'Eligible employee requires positive wage';end if;
 basic:=round((f->>'basic')::numeric*ratio,2);housing:=round((f->>'housing')::numeric*ratio,2);transport:=round((f->>'transport')::numeric*ratio,2);gross:=round(total_wage*ratio,2);other:=gross-basic-housing-transport;
 if (f->>'other')::numeric<0 or abs(total_wage-(f->>'basic')::numeric-(f->>'housing')::numeric-(f->>'transport')::numeric-(f->>'other')::numeric)>0.01 then raise exception 'Wage components mismatch';end if;
 status:=coalesce(v.gosi_status,case when public.hr_is_saudi(e->>'nationality') then 'سعودي بالتأمينات' else 'أجنبي بالتأمينات' end);
 saudi:=status like 'سعودي%';is_new:=coalesce((f->>'isNewGosi')::boolean,false);
 if saudi is distinct from public.hr_is_saudi(e->>'nationality') then raise exception 'Nationality/GOSI status conflict';end if;
 rate_key:=case when not saudi then 'nonsa' when is_new then 'saudi26' else 'saudi' end;
 rate_emp:=case when saudi then 9.75 else 0 end;rate_co:=case when saudi then 11.75 else 2 end;
 if saudi and is_new then
  rate_emp:=rate_emp+case when first_day>='2028-07-01' then 2 when first_day>='2027-07-01' then 1.5 when first_day>='2026-07-01' then 1 when first_day>='2025-07-01' then 0.5 else 0 end;rate_co:=rate_emp+2;
 end if;
 if status like '%خارج%' or pol#>>array['gosi',rate_key,'active']='false' then rate_emp:=0;rate_co:=0;
 elsif pol#>>array['gosi',rate_key,'exempt']='true' then rate_emp:=0;end if;
 if not coalesce((e->>'hr_gosi_verified')::boolean,false) then raise exception 'Verify GOSI cohort against its statement before payroll close';end if;
 insured:=least(45000,(f->>'basic')::numeric+(f->>'housing')::numeric);
 factor:=case when pay_days=0 then 0 when is_new then ratio when end_day is null or end_day>=last_day or to_char(start_day,'YYYY-MM')=p_month then 1 else 0 end;
 gosi:=round(insured*rate_emp/100*factor,2);
 if not is_new and factor=1 and abs((f->>'gosi')::numeric-gosi)>0.01 then raise exception 'Stored GOSI conflicts with verified amount';end if;
 if exists(select 1 from public.employee_requests r where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved'
  and ((to_jsonb(r)->>'days')::numeric<>public.hr_parse_date(to_jsonb(r)->>'date_to')-public.hr_parse_date(to_jsonb(r)->>'date_from')+1)) then raise exception 'Leave dates/days mismatch';end if;
 if exists(select d from public.employee_requests r cross join lateral generate_series(public.hr_parse_date(to_jsonb(r)->>'date_from')::timestamp,public.hr_parse_date(to_jsonb(r)->>'date_to')::timestamp,interval '1 day') d
  where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved' group by d having count(*)>1) then raise exception 'Approved leave overlap';end if;
 for leaf in select d::date as work_day,r.sub_type from public.employee_requests r
  cross join lateral generate_series(public.hr_parse_date(to_jsonb(r)->>'date_from')::timestamp,public.hr_parse_date(to_jsonb(r)->>'date_to')::timestamp,interval '1 day') d
  where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved' order by d loop
  fraction:=0;
  if leaf.sub_type ~ 'غير مدفوعة|دون أجر|بدون أجر' or leaf.sub_type='غياب بدون عذر' or coalesce(pol->'leavesUnpaid','{}') ? leaf.sub_type then fraction:=1;
  elsif leaf.sub_type ~ 'مرض' then
   if anchor is null or leaf.work_day>=(anchor+interval '1 year')::date then anchor:=leaf.work_day;sick:=0;end if;
   sick:=sick+1;fraction:=case when sick<=30 then 0 when sick<=90 then .25 else 1 end;
   if sick>120 and to_char(leaf.work_day,'YYYY-MM')=p_month then raise exception 'Sick entitlement exceeds 120 days';end if;
  end if;
  if leaf.work_day between a and b then leave_count:=leave_count+1;loss:=loss+fraction;end if;
 end loop;
 if loss=calendar_days and calendar_days>0 then loss:=pay_days;end if;
 loss:=least(pay_days,loss);deds:=round(least(gross,total_wage/30*loss),2);
 time_deductions:=deds;
 for op in select * from public.hr_operations where employee_id=p_employee_id and company_id=(e->>'company_id')::uuid
  and module in ('fin_allowance','fin_deduction','fin_annual','fin_repay','fin_absence','fin_perf','fin_overtime','assignment','fin_extra') loop
  j:=to_jsonb(op);em:=j->>'effective_month';
  if pay_days=0 or j->>'status' in ('stopped','cancelled','rejected') or j#>>'{data,flow,state}' in ('cancelled','rejected') then continue;end if;
  if j->>'module'='fin_repay' then value:=public.hr_loan_installment((j->>'amount')::numeric,coalesce((j#>>'{data,installments}')::integer,1),em,p_month);relevant:=value>0;
  elsif coalesce((j->>'recurring')::boolean,false) then relevant:=em<=p_month;
  else relevant:=em=p_month;end if;
  if not coalesce(relevant,false) then continue;end if;
  if coalesce(j#>>'{data,flow,state}','new') not in ('approved','authorized','completed') then raise exception 'Unapproved financial operation %',j->>'id';end if;
  sign:=case when j->>'module' in ('fin_deduction','fin_repay','fin_absence') then -1 else 1 end;
  if j->>'module'='fin_absence' then
   if absence_seen then raise exception 'Multiple active absence records require reconciliation';end if;absence_seen:=true;
   if (j->>'days')::numeric>calendar_days then raise exception 'Absence exceeds service period';end if;
   if jsonb_typeof(j#>'{data,absence_dates}')='array' then
    if (select count(distinct d) from jsonb_array_elements_text(j#>'{data,absence_dates}') d)<>(j->>'days')::numeric then raise exception 'Absence date count mismatch';end if;
    if exists(select 1 from jsonb_array_elements_text(j#>'{data,absence_dates}') ad
      where left(ad,7)<>p_month or public.hr_parse_date(ad) not between a and b or exists(select 1 from public.employee_requests r where r.employee_id=p_employee_id and r.request_type='leave' and r.status='approved' and public.hr_parse_date(ad) between public.hr_parse_date(to_jsonb(r)->>'date_from') and public.hr_parse_date(to_jsonb(r)->>'date_to'))) then raise exception 'Absence/leave date overlap';end if;
   elsif leave_count>0 and (j->>'days')::numeric>0 then raise exception 'Absence dates required to avoid leave double deduction';end if;
   value:=round(total_wage/30*(j->>'days')::numeric,2);
   time_deductions:=time_deductions+value;
  elsif j->>'module'<>'fin_repay' then value:=coalesce((j->>'amount')::numeric,0);end if;
  if value<0 then raise exception 'Negative financial operation';end if;
  if j->>'module'='fin_extra' and j#>>'{data,auto}'='true' and coalesce(j#>>'{data,verified_unpaid_period}','false')<>'true' then raise exception 'Unverified starting wage duplication';end if;
  if j->>'module'='fin_repay' then loans:=loans+value;end if;
  if sign>0 then adds:=adds+value;else deds:=deds+value;end if;
 end loop;
 for adjustment in select * from public.salary_adjustments where employee_id=p_employee_id and (month=p_month or is_recurring and month<=p_month) loop
   j:=to_jsonb(adjustment);value:=(j->>'amount')::numeric;
   if value<0 or j->>'adjustment_type' not in ('increase','allowance','bonus','deduction') then raise exception 'Invalid wage adjustment';end if;
   if j->>'adjustment_type'='deduction' then deds:=deds+value;else adds:=adds+value;end if;
 end loop;
 adds:=round(adds,2);deds:=round(deds,2);
 if abs(adds)>1000000000 or abs(deds)>1000000000 or abs(gross+adds-gosi-deds)>1000000000 then raise exception 'Financial totals outside safe processing bounds';end if;
 if loans>round(greatest(0,gross-time_deductions)*.1,2) then raise exception 'Loan deduction exceeds 10 percent';end if;
 if gosi+deds-time_deductions>(gross-time_deductions+adds)/2 or gross+adds-gosi-deds<0 then raise exception 'Deduction cap or negative net';end if;
 result:=jsonb_build_object('basic',basic,'housing',housing,'transport',transport,'other',other,'total',gross,'monthlyTotal',total_wage,'gosi',gosi,'companyGosi',round(insured*rate_co/100*factor,2),'addT',adds,'dedT',deds,'net',round(gross+adds-gosi-deds,2),'payDays',pay_days,'compensationVersion',v.id);
 return result;
end $$;

create or replace function public.hr_bank_info(p_company_id uuid,p_iban text) returns jsonb
language plpgsql stable security definer set search_path=pg_catalog,public as $$
declare pol jsonb;item jsonb;merged jsonb;code text:=substring(upper(regexp_replace(coalesce(p_iban,''),'\s','','g')) from 5 for 2);
 banks jsonb:='[{"ar":"مصرف الراجحي","en":"Al Rajhi Bank","code":"80","swift":"RJHISARI"},{"ar":"البنك الأهلي","en":"Saudi National Bank (SNB)","code":"10","swift":"NCBKSAJE"},{"ar":"بنك الجزيرة","en":"Bank AlJazira","code":"60","swift":"BJAZSAJE"},{"ar":"بنك الإنماء","en":"Alinma Bank","code":"05","swift":"INMASARI"},{"ar":"بنك الرياض","en":"Riyad Bank","code":"20","swift":"RIBLSARI"},{"ar":"البنك العربي","en":"Arab National Bank (ANB)","code":"30","swift":"ARNBSARI"},{"ar":"البنك الأول ساب","en":"Saudi Awwal Bank (SAB)","code":"45","swift":"SABBSARI"},{"ar":"البنك السعودي للإستثمار","en":"Saudi Investment Bank","code":"65","swift":"SIBCSARI"},{"ar":"بنك البلاد","en":"Bank Albilad","code":"15","swift":"ALBISARI"},{"ar":"البنك السعودي الفرنسي","en":"Banque Saudi Fransi (BSF)","code":"55","swift":"BSFRSARI"}]';
begin
 perform hr_require_finance(p_company_id);select coalesce(policy_settings,'{}') into pol from companies where id=p_company_id;
 for item in select * from jsonb_array_elements(banks||coalesce(pol->'customBanks','[]')) loop
  merged:=item||coalesce(pol#>array['banks',item->>'en'],'{}');
  if merged->>'code'=code then return jsonb_build_array(merged->>'ar',coalesce(merged->>'swift',''));end if;
 end loop;
 -- The original UI falls back to its statutory default register if an override changes a code.
 for item in select * from jsonb_array_elements(banks) loop if item->>'code'=code then return jsonb_build_array(item->>'ar',item->>'swift');end if;end loop;return null;
end $$;
revoke execute on function public.hr_bank_info(uuid,text) from public,anon;
grant execute on function public.hr_bank_info(uuid,text) to authenticated;
create or replace function public.hr_close_payroll(p_company_id uuid,p_month text,p_rows jsonb,p_source_fingerprint text,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public as $$
declare cmd public.hr_finance_commands;body jsonb:=jsonb_build_object('month',p_month,'rows',p_rows,'fingerprint',p_source_fingerprint);
 run public.hr_payroll_runs;row jsonb;e jsonb;expected jsonb;key text;count_expected integer;count_actual integer;method text;first_day date;last_day date;result jsonb;
begin
 perform public.hr_lock_company(p_company_id);
 select * into cmd from public.hr_finance_commands where request_id=p_request_id;
 if found then if cmd.company_id<>p_company_id or cmd.command<>'close' or cmd.request_body<>body then raise exception 'Idempotency input mismatch';end if;return cmd.result;end if;
 if p_month !~ '^\d{4}-(0[1-9]|1[0-2])$' or jsonb_typeof(p_rows)<>'array' or jsonb_array_length(p_rows)=0 then raise exception 'Invalid payroll';end if;
 if exists(select 1 from public.hr_payroll_runs where company_id=p_company_id and month=p_month) then raise exception 'Month already closed';end if;
 if public.hr_finance_fingerprint(p_company_id)<>p_source_fingerprint then raise exception 'Sources changed; reload and review';end if;
 first_day:=to_date(p_month||'-01','YYYY-MM-DD');last_day:=(first_day+(interval '1 month' - interval '1 day'))::date;
 select count(*) into count_expected from public.employees x where company_id=p_company_id and public.hr_parse_date(to_jsonb(x)->>'start_date')<=last_day
  and (not coalesce((to_jsonb(x)->>'is_terminated')::boolean,false) or public.hr_parse_date(to_jsonb(x)->>'clearance_last_day')>=first_day);
 select count(distinct entry#>>'{e,id}') into count_actual from jsonb_array_elements(p_rows) entry;
 if count_actual<>jsonb_array_length(p_rows) or count_actual<>count_expected then raise exception 'Payroll employee coverage mismatch';end if;
 for row in select * from jsonb_array_elements(p_rows) loop
  select to_jsonb(x) into e from public.employees x where id=(row#>>'{e,id}')::uuid and company_id=p_company_id;
  if e is null then raise exception 'Employee/company mismatch';end if;
  expected:=public.hr_expected_payroll((e->>'id')::uuid,p_month);
  if (expected->>'payDays')::integer<=0 then raise exception 'Ineligible employee in payroll';end if;
  foreach key in array array['basic','housing','transport','other','total','monthlyTotal','gosi','companyGosi','addT','dedT','net'] loop
   if row#>>array['p',key] is null or abs((row#>>array['p',key])::numeric-(expected->>key)::numeric)>0.009 then raise exception 'Payroll calculation mismatch %, employee %',key,e->>'id';end if;
  end loop;
  if row#>>'{p,service,payDays}' is null or (row#>>'{p,service,payDays}')::integer<>(expected->>'payDays')::integer
    or coalesce(jsonb_array_length(row#>'{p,errors}'),1)<>0 then raise exception 'Payroll validation mismatch';end if;
  foreach key in array array['name','nid','nationality','iban'] loop
   if coalesce(row#>>array['e',key],'')<>coalesce(e->>key,'') then raise exception 'Payroll identity differs from source';end if;
  end loop;
  if row#>>'{e,companyId}' is distinct from p_company_id::text or coalesce(row#>>'{e,empNumber}','')<>coalesce(e->>'emp_number','') or coalesce(row#>>'{e,departmentId}','')<>coalesce(e->>'department_id','') then raise exception 'Payroll organisation identity mismatch';end if;
  if e->>'nid' !~ '^\d{10}$' or length(trim(coalesce(e->>'name','')))=0 then raise exception 'Payroll employee identity incomplete';end if;
  if row->>'iban' is distinct from upper(regexp_replace(coalesce(e->>'iban',''),'\s','','g')) then raise exception 'Transfer IBAN differs from source';end if;
  if jsonb_typeof(row#>'{p,adds}') is distinct from 'array' or jsonb_typeof(row#>'{p,deds}') is distinct from 'array' then raise exception 'Missing payroll detail';end if;
  if abs(coalesce((select sum((x->>'amount')::numeric) from jsonb_array_elements(row#>'{p,adds}') x),0)-(expected->>'addT')::numeric)>0.009
     or abs(coalesce((select sum((x->>'amount')::numeric) from jsonb_array_elements(row#>'{p,deds}') x),0)-(expected->>'dedT')::numeric)>0.009 then raise exception 'Payroll detail totals mismatch';end if;
  if exists(select 1 from jsonb_array_elements((row#>'{p,adds}')||(row#>'{p,deds}')) x where x->>'amount' is null or (x->>'amount')::numeric<0) then raise exception 'Invalid payroll detail amount';end if;
  method:=coalesce(e->>'pay_method','');
  if method not in ('wps','bank','cash') then method:='wps';end if;
  if coalesce(row->>'method','')<>method then raise exception 'Payment method mismatch';end if;
  if method<>'cash' and not public.hr_iban_valid(e->>'iban') then raise exception 'Invalid IBAN';end if;
  if method<>'cash' and (public.hr_bank_info(p_company_id,e->>'iban') is null or row->'bank' is distinct from public.hr_bank_info(p_company_id,e->>'iban')) then raise exception 'Bank identity differs from approved register';end if;
  if method='cash' and length(trim(coalesce(e->>'pay_method_note','')))=0 then raise exception 'Cash exception must be documented';end if;
 end loop;
 insert into public.hr_payroll_runs(company_id,month,rows,source_fingerprint,closed_by) values(p_company_id,p_month,p_rows,p_source_fingerprint,auth.uid()) returning * into run;
 result:=jsonb_build_object('ok',true,'id',run.id,'month',p_month);
 insert into public.hr_finance_commands values(p_request_id,p_company_id,'close',body,result,auth.uid(),now());return result;
end $$;
revoke execute on function public.hr_expected_payroll(uuid,text),public.hr_close_payroll(uuid,text,jsonb,text,uuid) from public,anon;
grant execute on function public.hr_expected_payroll(uuid,text),public.hr_close_payroll(uuid,text,jsonb,text,uuid) to authenticated;
-- All changes to employee identity are serialized with close, including IBAN and payment method.
drop trigger if exists hr_source_guard on public.employees;
create trigger hr_source_guard before insert or update or delete on public.employees for each row execute function public.hr_source_guard();
commit;
