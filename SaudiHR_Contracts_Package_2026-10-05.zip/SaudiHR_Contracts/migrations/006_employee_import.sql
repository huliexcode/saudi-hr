begin;
create or replace function public.hr_employee_integrity_guard() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
begin
 if new.annual_leave_days is not null and (new.annual_leave_days<21 or new.annual_leave_days>366) then raise exception 'Annual contractual entitlement out of range';end if;
 if new.leave_opening_balance is not null then
  if coalesce(new.leave_opening_balance->>'year','') !~ '^\d{4}$' or coalesce(new.leave_opening_balance->>'days','') !~ '^\d+(\.\d+)?$' or length(trim(coalesce(new.leave_opening_balance->>'evidence','')))=0 then raise exception 'Opening leave balance requires year, nonnegative days, evidence';end if;
 end if;
 if new.hr_gosi_verified and length(trim(coalesce(new.hr_gosi_evidence,'')))<4 then raise exception 'Verified GOSI requires evidence reference';end if;
 if tg_op='UPDATE' and (new.is_new_gosi is distinct from old.is_new_gosi or new.gosi_status is distinct from old.gosi_status or new.nationality is distinct from old.nationality) then new.hr_gosi_verified:=false;new.hr_gosi_evidence:=null;end if;
 return new;
end $$;
drop trigger if exists hr_employee_integrity_guard on employees;
create trigger hr_employee_integrity_guard before insert or update on employees for each row execute function hr_employee_integrity_guard();
create or replace function public.hr_company_identity_guard() returns trigger language plpgsql as $$
begin if new.owner_id is distinct from old.owner_id then raise exception 'Ownership transfer requires a separate administrator procedure';end if;return new;end $$;
drop trigger if exists hr_company_identity_guard on companies;
create trigger hr_company_identity_guard before update on companies for each row execute function hr_company_identity_guard();
create or replace function public.hr_import_salaries(p_company_id uuid,p_rows jsonb,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public as $$
declare cmd public.hr_finance_commands;entry jsonb;patch jsonb;e public.employees;merged public.employees;result jsonb;body jsonb:=jsonb_build_object('rows',p_rows);begin
 perform public.hr_lock_company(p_company_id);
 select * into cmd from hr_finance_commands where request_id=p_request_id;
 if found then if cmd.company_id<>p_company_id or cmd.command<>'salary_import' or cmd.request_body<>body then raise exception 'Idempotency input mismatch';end if;return cmd.result;end if;
 if jsonb_typeof(p_rows)<>'array' or jsonb_array_length(p_rows) not between 1 and 5000 then raise exception 'Invalid salary import';end if;
 if (select count(distinct x->>'employee_id') from jsonb_array_elements(p_rows) x)<>jsonb_array_length(p_rows) then raise exception 'Duplicate salary import employee';end if;
 for entry in select * from jsonb_array_elements(p_rows) loop
  select * into e from employees where id=(entry->>'employee_id')::uuid and company_id=p_company_id;
  if not found then raise exception 'Employee/company mismatch';end if;patch:=entry->'patch';
  if jsonb_typeof(patch)<>'object' or exists(select 1 from jsonb_object_keys(patch) k where k not in ('total_salary','basic_salary','housing_allowance','transport_allowance','other_allowances','gosi_deduction','hr_salary_effective_month','iban','bank','pay_method','pay_method_note')) then raise exception 'Invalid import field';end if;
  if patch ? 'iban' and not public.hr_iban_valid(patch->>'iban') then raise exception 'Invalid imported IBAN';end if;
  if patch ? 'pay_method' and patch->>'pay_method' not in ('wps','bank','cash') then raise exception 'Invalid payment method';end if;
  select * into merged from jsonb_populate_record(e,patch);
  update employees set total_salary=merged.total_salary,basic_salary=merged.basic_salary,housing_allowance=merged.housing_allowance,transport_allowance=merged.transport_allowance,other_allowances=merged.other_allowances,gosi_deduction=merged.gosi_deduction,hr_salary_effective_month=merged.hr_salary_effective_month,iban=merged.iban,bank=merged.bank,pay_method=merged.pay_method,pay_method_note=merged.pay_method_note where id=e.id;
 end loop;
 result:=jsonb_build_object('ok',true,'rows',jsonb_array_length(p_rows));insert into hr_finance_commands values(p_request_id,p_company_id,'salary_import',body,result,auth.uid(),now());return result;
end $$;
revoke execute on function public.hr_employee_integrity_guard(),public.hr_company_identity_guard() from public,anon,authenticated;
revoke execute on function public.hr_import_salaries(uuid,jsonb,uuid) from public,anon;
grant execute on function public.hr_import_salaries(uuid,jsonb,uuid) to authenticated;
create or replace function public.hr_log_change() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare p jsonb:=case when tg_op='DELETE' then to_jsonb(old) else to_jsonb(new) end;company uuid;
begin
 company:=case when tg_table_name='companies' then (p->>'id')::uuid else (p->>'company_id')::uuid end;
 if company is null and p->>'employee_id' is not null then select company_id into company from employees where id=(p->>'employee_id')::uuid;end if;
 if company is not null then insert into hr_audit_events(company_id,table_name,row_id,action,actor_id,before_data,after_data) values(company,tg_table_name,coalesce(p->>'id',p->>'request_id'),tg_op,auth.uid(),case when tg_op='INSERT' then null else to_jsonb(old) end,case when tg_op='DELETE' then null else to_jsonb(new) end);end if;
 if tg_op='DELETE' then return old;end if;return new;
end $$;
do $$declare t text;begin
 foreach t in array array['companies','company_members','custody_items','employee_documents','employee_attendance','document_templates','hr_communications','ask_knowledge','hr_finance_commands'] loop
  execute format('drop trigger if exists hr_log_change on public.%I',t);
  execute format('create trigger hr_log_change after insert or update or delete on public.%I for each row execute function hr_log_change()',t);
 end loop;
end $$;
commit;
