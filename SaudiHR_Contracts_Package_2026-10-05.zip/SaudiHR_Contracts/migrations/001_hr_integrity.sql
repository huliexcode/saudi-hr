-- Saudi HR integrity upgrade. Run first in a staging copy of the existing database.
-- Transactional and re-runnable. Existing rows are retained; unknown past wages are NOT invented.
begin;
do $$
begin
  if to_regclass('public.companies') is null or to_regclass('public.employees') is null
     or to_regclass('public.hr_operations') is null or to_regclass('public.employee_requests') is null
     or to_regclass('public.salary_adjustments') is null or to_regclass('public.company_members') is null then
    raise exception 'Required HR tables are missing. Apply the original database schema first.';
  end if;
end $$;

alter table public.employees add column if not exists hr_salary_effective_month date;
alter table public.employees add column if not exists annual_leave_days numeric;
alter table public.employees add column if not exists leave_opening_balance jsonb;
alter table public.employees add column if not exists hr_gosi_verified boolean not null default false;
alter table public.employees add column if not exists hr_gosi_evidence text;

create table if not exists public.hr_compensation_versions (
  id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id),
  employee_id uuid not null references public.employees(id), effective_from date not null,
  financials jsonb not null, gosi_status text, created_by uuid, created_at timestamptz not null default now(),
  unique(employee_id,effective_from), check(extract(day from effective_from)=1)
);
create table if not exists public.hr_payroll_runs (
  id uuid primary key default gen_random_uuid(),company_id uuid not null references public.companies(id),
  month text not null check(month ~ '^\d{4}-(0[1-9]|1[0-2])$'),status text not null default 'closed' check(status='closed'),
  rows jsonb not null check(jsonb_typeof(rows)='array'),source_fingerprint text not null,
  calculation_version text not null default '2026-10-05.1',closed_by uuid not null,closed_at timestamptz not null default now(),
  unique(company_id,month)
);
create table if not exists public.hr_finance_commands (
  request_id uuid primary key,company_id uuid not null references public.companies(id),command text not null,
  request_body jsonb not null,result jsonb not null,created_by uuid not null,created_at timestamptz not null default now()
);
create table if not exists public.hr_audit_events (
  id uuid primary key default gen_random_uuid(),company_id uuid not null references public.companies(id),
  table_name text not null,row_id text,action text not null,actor_id uuid,occurred_at timestamptz not null default now(),
  before_data jsonb,after_data jsonb
);
create index if not exists hr_audit_company_time on public.hr_audit_events(company_id,occurred_at);
create index if not exists hr_compensation_effective on public.hr_compensation_versions(company_id,employee_id,effective_from);
alter table public.hr_audit_events alter column row_id type text using row_id::text;

create or replace function public.hr_company_role(p_company_id uuid) returns text
language sql stable security definer set search_path=pg_catalog,public as $$
  select case when c.owner_id=auth.uid() then 'owner' else
    (select m.role from public.company_members m where m.company_id=c.id and m.user_id=auth.uid() limit 1) end
  from public.companies c where c.id=p_company_id
$$;
create or replace function public.hr_require_finance(p_company_id uuid) returns void
language plpgsql security definer set search_path=pg_catalog,public as $$
begin
  if auth.uid() is null or coalesce(public.hr_company_role(p_company_id),'') not in ('owner','admin','hr','accountant') then
    raise exception 'Financial permission required' using errcode='42501';
  end if;
end $$;
create or replace function public.hr_lock_company(p_company_id uuid) returns void
language plpgsql security definer set search_path=pg_catalog,public as $$
begin
  perform public.hr_require_finance(p_company_id);
  perform 1 from public.companies where id=p_company_id for update;
  if not found then raise exception 'Company not found'; end if;
end $$;

alter table public.hr_compensation_versions enable row level security;
alter table public.hr_payroll_runs enable row level security;
alter table public.hr_finance_commands enable row level security;
alter table public.hr_audit_events enable row level security;
revoke all on public.hr_compensation_versions,public.hr_payroll_runs,public.hr_finance_commands,public.hr_audit_events from anon,authenticated;
grant select on public.hr_compensation_versions,public.hr_payroll_runs,public.hr_audit_events to authenticated;
do $$ declare t text;begin
  foreach t in array array['hr_compensation_versions','hr_payroll_runs','hr_audit_events'] loop
    execute format('drop policy if exists hr_finance_read on public.%I',t);
    execute format('create policy hr_finance_read on public.%I for select to authenticated using (public.hr_company_role(company_id) in (''owner'',''admin'',''hr'',''accountant''))',t);
  end loop;
end $$;

create or replace function public.hr_is_saudi(value text) returns boolean
language sql immutable as $$
 select coalesce(lower(value),'') !~ 'غير|non' and replace(regexp_replace(lower(coalesce(value,'')),'[[:space:]ـًٌٍَُِّْ-]','','g'),'ى','ي') ~ '^(سعودية?|السعودية|المملكةالعربيةالسعودية|saudi(arabia)?|ksa|sa)$'
$$;
create or replace function public.hr_financials(p jsonb) returns jsonb
language sql immutable set search_path=pg_catalog,public as $$
select jsonb_build_object('total',coalesce((p->>'total_salary')::numeric,0),'basic',coalesce((p->>'basic_salary')::numeric,0),
  'housing',coalesce((p->>'housing_allowance')::numeric,0),'transport',coalesce((p->>'transport_allowance')::numeric,0),
  'other',coalesce((p->>'other_allowances')::numeric,(p->>'total_salary')::numeric-coalesce((p->>'basic_salary')::numeric,0)-coalesce((p->>'housing_allowance')::numeric,0)-coalesce((p->>'transport_allowance')::numeric,0)),
  'gosi',coalesce((p->>'gosi_deduction')::numeric,0),'isNewGosi',coalesce((p->>'is_new_gosi')::boolean,false))
$$;
-- Installation baseline is only known for the current month. Historical months require real evidence.
insert into public.hr_compensation_versions(company_id,employee_id,effective_from,financials,gosi_status,created_by)
select e.company_id,e.id,date_trunc('month',now() at time zone 'Asia/Riyadh')::date,public.hr_financials(to_jsonb(e)),to_jsonb(e)->>'gosi_status',c.owner_id
from public.employees e join public.companies c on c.id=e.company_id
where not exists(select 1 from public.hr_compensation_versions v where v.employee_id=e.id);

create or replace function public.hr_capture_compensation() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare p jsonb:=to_jsonb(new);from_date date;f jsonb;key text;value numeric;
begin
  if tg_op='UPDATE' and public.hr_financials(to_jsonb(old))=public.hr_financials(p)
     and (to_jsonb(old)->>'gosi_status') is not distinct from (p->>'gosi_status') then return new;end if;
  perform public.hr_lock_company(new.company_id);
  f:=public.hr_financials(p);
  foreach key in array array['total','basic','housing','transport','other','gosi'] loop
    value:=(f->>key)::numeric;
    if value<0 or value>1000000000 or value::text in ('NaN','Infinity','-Infinity') then raise exception 'Invalid compensation %',key;end if;
  end loop;
  if abs((f->>'total')::numeric-(f->>'basic')::numeric-(f->>'housing')::numeric-(f->>'transport')::numeric-(f->>'other')::numeric)>0.01 then
    raise exception 'Salary components do not reconcile';
  end if;
  from_date:=coalesce(new.hr_salary_effective_month,date_trunc('month',now() at time zone 'Asia/Riyadh')::date);
  if extract(day from from_date)<>1 then raise exception 'Compensation effective date must be first day of month';end if;
  if from_date<date_trunc('month',now() at time zone 'Asia/Riyadh')::date and tg_op='UPDATE' then raise exception 'No silent backdating. Use a documented historical migration or a current adjustment.';end if;
  if exists(select 1 from public.hr_payroll_runs where company_id=new.company_id and month>=to_char(from_date,'YYYY-MM')) then raise exception 'Compensation affects a closed month';end if;
  insert into public.hr_compensation_versions(company_id,employee_id,effective_from,financials,gosi_status,created_by)
  values(new.company_id,new.id,from_date,f,p->>'gosi_status',auth.uid())
  on conflict(employee_id,effective_from) do update set financials=excluded.financials,gosi_status=excluded.gosi_status,created_by=excluded.created_by,created_at=now();
  return new;
end $$;
drop trigger if exists hr_capture_compensation on public.employees;
create trigger hr_capture_compensation after insert or update on public.employees for each row execute function public.hr_capture_compensation();

create or replace function public.hr_source_guard() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare p jsonb:=case when tg_op='DELETE' then to_jsonb(old) else to_jsonb(new) end;
  prior jsonb:=case when tg_op='INSERT' then null else to_jsonb(old) end;
  company uuid;emp_company uuid;key text;value text;flow text;from_month text;to_month text;
begin
  company:=(p->>'company_id')::uuid;
  if p ? 'employee_id' and p->>'employee_id' is not null then
    select company_id into emp_company from public.employees where id=(p->>'employee_id')::uuid;
    if emp_company is null or company is not null and company<>emp_company then raise exception 'Employee/company mismatch';end if;
    company:=emp_company;
  end if;
  if company is null then raise exception 'Company context missing';end if;
  if tg_table_name='employee_requests' and coalesce(p->>'status','')<>'approved' and coalesce(prior->>'status','')<>'approved' then
    perform 1 from public.companies where id=company for update;
  else perform public.hr_lock_company(company);end if;
  if prior is not null and prior ? 'company_id' and prior->>'company_id' is distinct from p->>'company_id' then raise exception 'Tenant move is forbidden';end if;
  if prior is not null and prior ? 'employee_id' and prior->>'employee_id' is distinct from p->>'employee_id' then raise exception 'Employee move is forbidden';end if;
  if tg_op<>'DELETE' then
    foreach key in array array['amount','days'] loop
      value:=p->>key;
      if value is not null and (value !~ '^\d+(\.\d+)?$' or value::numeric>1000000000) then raise exception 'Invalid %',key;end if;
    end loop;
    if tg_table_name='hr_operations' and p->>'module'='fin_absence' and ((p->>'days')::numeric<>trunc((p->>'days')::numeric) or (p->>'days')::numeric>31) then raise exception 'Invalid absence days';end if;
    flow:=p#>>'{data,flow,state}';
    if flow is not null and flow not in ('new','review','approved','authorized','completed','rejected','cancelled','paused','in_progress','waiting','escalated') then raise exception 'Invalid workflow state';end if;
    if tg_table_name='hr_operations' and p->>'module'='fin_repay' and coalesce((p#>>'{data,installments}')::integer,1) not between 1 and 120 then raise exception 'Invalid installment count';end if;
    if tg_table_name='employee_requests' and p->>'request_type'='leave' and p->>'status'='approved' then
      if p->>'date_from' is null or p->>'date_to' is null or public.hr_parse_date(p->>'date_from')>public.hr_parse_date(p->>'date_to')
         or (p->>'days')::numeric<>(public.hr_parse_date(p->>'date_to')-public.hr_parse_date(p->>'date_from')+1) then raise exception 'Leave dates/days mismatch';end if;
      if exists(select 1 from public.employee_requests r where r.employee_id=(p->>'employee_id')::uuid
        and r.request_type='leave' and r.status='approved' and r.id<>coalesce((p->>'id')::uuid,'00000000-0000-0000-0000-000000000000')
        and public.hr_parse_date(to_jsonb(r)->>'date_from')<=public.hr_parse_date(p->>'date_to') and public.hr_parse_date(to_jsonb(r)->>'date_to')>=public.hr_parse_date(p->>'date_from')) then raise exception 'Approved leave overlap';end if;
    end if;
  end if;
  if tg_table_name='employee_requests' and coalesce(p->>'status','')<>'approved' and coalesce(prior->>'status','')<>'approved' then
    if tg_op='DELETE' then return old;else return new;end if;
  end if;
  if tg_table_name='employee_requests' and coalesce(p->>'request_type',prior->>'request_type')='leave' then
    from_month:=least(to_char(public.hr_parse_date(p->>'date_from'),'YYYY-MM'),to_char(public.hr_parse_date(prior->>'date_from'),'YYYY-MM'));to_month:=greatest(to_char(public.hr_parse_date(p->>'date_to'),'YYYY-MM'),to_char(public.hr_parse_date(prior->>'date_to'),'YYYY-MM'));
  else
    from_month:=least(coalesce(p->>'effective_month',p->>'month'),coalesce(prior->>'effective_month',prior->>'month'));
    to_month:=greatest(coalesce(p->>'effective_month',p->>'month'),coalesce(prior->>'effective_month',prior->>'month'));
    if coalesce((p->>'recurring')::boolean,false) or coalesce((p->>'is_recurring')::boolean,false)
       or p->>'module'='fin_repay' or prior->>'module'='fin_repay' then to_month:='9999-12';end if;
  end if;
  if exists(select 1 from public.hr_payroll_runs where company_id=company and month between from_month and to_month) then raise exception 'Source affects a closed payroll month; create a current adjustment instead';end if;
  if tg_op='DELETE' then return old;end if;return new;
end $$;
do $$ declare t text;begin
 foreach t in array array['hr_operations','employee_requests','salary_adjustments'] loop
  execute format('drop trigger if exists hr_source_guard on public.%I',t);
  execute format('create trigger hr_source_guard before insert or update or delete on public.%I for each row execute function public.hr_source_guard()',t);
 end loop;
end $$;

create or replace function public.hr_log_change() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare p jsonb:=case when tg_op='DELETE' then to_jsonb(old) else to_jsonb(new) end;company uuid;
begin
  company:=(p->>'company_id')::uuid;
  if company is null and p->>'employee_id' is not null then select company_id into company from public.employees where id=(p->>'employee_id')::uuid;end if;
  if company is not null then
    insert into public.hr_audit_events(company_id,table_name,row_id,action,actor_id,before_data,after_data)
    values(company,tg_table_name,p->>'id',tg_op,auth.uid(),case when tg_op='INSERT' then null else to_jsonb(old) end,case when tg_op='DELETE' then null else to_jsonb(new) end);
  end if;
  if tg_op='DELETE' then return old;end if;return new;
end $$;
do $$ declare t text;begin
 foreach t in array array['employees','hr_operations','employee_requests','salary_adjustments','hr_compensation_versions','hr_payroll_runs'] loop
  execute format('drop trigger if exists hr_log_change on public.%I',t);
  execute format('create trigger hr_log_change after insert or update or delete on public.%I for each row execute function public.hr_log_change()',t);
 end loop;
end $$;
create or replace function public.hr_immutable() returns trigger language plpgsql as $$
begin raise exception 'Immutable financial record';end $$;
drop trigger if exists hr_immutable on public.hr_payroll_runs;
create trigger hr_immutable before update or delete on public.hr_payroll_runs for each row execute function public.hr_immutable();
drop trigger if exists hr_immutable on public.hr_audit_events;
create trigger hr_immutable before update or delete on public.hr_audit_events for each row execute function public.hr_immutable();

create or replace function public.hr_finance_fingerprint(p_company_id uuid) returns text
language plpgsql security definer set search_path=pg_catalog,public as $$
declare payload jsonb;begin
 perform public.hr_require_finance(p_company_id);
 select jsonb_build_object(
 'employees',coalesce((select jsonb_agg(to_jsonb(e) order by e.id) from public.employees e where e.company_id=p_company_id),'[]'),
 'versions',coalesce((select jsonb_agg(to_jsonb(v) order by v.id) from public.hr_compensation_versions v where v.company_id=p_company_id),'[]'),
 'operations',coalesce((select jsonb_agg(to_jsonb(o) order by o.id) from public.hr_operations o where o.company_id=p_company_id),'[]'),
 'requests',coalesce((select jsonb_agg(to_jsonb(r) order by r.id) from public.employee_requests r where r.company_id=p_company_id),'[]'),
 'adjustments',coalesce((select jsonb_agg(to_jsonb(a) order by a.id) from public.salary_adjustments a join public.employees e on e.id=a.employee_id where e.company_id=p_company_id),'[]'),
 'policy',(select to_jsonb(c) from public.companies c where c.id=p_company_id)) into payload;
 return md5(payload::text);
end $$;

create or replace function public.hr_apply_absence(p_company_id uuid,p_month text,p_source text,p_rows jsonb,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public as $$
declare body jsonb:=jsonb_build_object('month',p_month,'source',p_source,'rows',p_rows);cmd public.hr_finance_commands;
  r jsonb;emp uuid;v_days integer;op_id uuid;v_data jsonb;result jsonb;count_rows integer:=0;
begin
 perform public.hr_lock_company(p_company_id);
 select * into cmd from public.hr_finance_commands where request_id=p_request_id;
 if found then
   if cmd.company_id<>p_company_id or cmd.command<>'absence' or cmd.request_body<>body then raise exception 'Idempotency key reused with different input';end if;
   return cmd.result;
 end if;
 if p_month !~ '^\d{4}-(0[1-9]|1[0-2])$' or jsonb_typeof(p_rows)<>'array' then raise exception 'Invalid absence batch';end if;
 if jsonb_array_length(p_rows)>5000 then raise exception 'Batch too large';end if;
 if exists(select 1 from public.hr_payroll_runs where company_id=p_company_id and month=p_month) then raise exception 'Month closed';end if;
 if (select count(*) from jsonb_array_elements(p_rows))<>(select count(distinct entry->>'employee_id') from jsonb_array_elements(p_rows) entry) then raise exception 'Duplicate employee in batch';end if;
 for r in select * from jsonb_array_elements(p_rows) loop
   emp:=(r->>'employee_id')::uuid;
   if r->>'days' is null or (r->>'days') !~ '^\d+$' then raise exception 'Invalid days';end if;v_days:=(r->>'days')::integer;
   if v_days<0 or v_days>extract(day from (to_date(p_month||'-01','YYYY-MM-DD')+(interval '1 month' - interval '1 day'))) then raise exception 'Invalid absence days';end if;
   if not exists(select 1 from public.employees where id=emp and company_id=p_company_id) then raise exception 'Employee/company mismatch';end if;
   if (select count(*) from public.hr_operations where employee_id=emp and company_id=p_company_id and module='fin_absence' and effective_month=p_month)>1 then raise exception 'Multiple absence records require review';end if;
   select id into op_id from public.hr_operations where employee_id=emp and company_id=p_company_id and module='fin_absence' and effective_month=p_month;
   if v_days=0 then if op_id is not null then delete from public.hr_operations where id=op_id;end if;continue;end if;
   v_data:=jsonb_build_object('source',p_source,'absence_dates',r->'absence_dates','flow',jsonb_build_object('state','approved','by',auth.uid(),'at',now()),'request_id',p_request_id);
   if op_id is null then
     insert into public.hr_operations(company_id,employee_id,owner_id,module,status,effective_month,days,notes,sub_type,data)
     values(p_company_id,emp,auth.uid(),'fin_absence','open',p_month,v_days,r->>'note','غياب بدون عذر',v_data);
   else update public.hr_operations set days=v_days,notes=r->>'note',data=v_data,updated_at=now() where id=op_id;end if;
   count_rows:=count_rows+1;
 end loop;
 result:=jsonb_build_object('ok',true,'rows',count_rows,'month',p_month);
 insert into public.hr_finance_commands(request_id,company_id,command,request_body,result,created_by) values(p_request_id,p_company_id,'absence',body,result,auth.uid());
 return result;
end $$;

-- A receipt and its loan are one transaction. The caller retries with the SAME request UUID.
create or replace function public.hr_create_entitlement(p_company_id uuid,p_row jsonb,p_loan jsonb,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public as $$
declare cmd public.hr_finance_commands;body jsonb:=jsonb_build_object('row',p_row,'loan',p_loan);r jsonb;id uuid;ref text;emp uuid;v jsonb;
begin
 perform public.hr_lock_company(p_company_id);
 select * into cmd from public.hr_finance_commands where request_id=p_request_id;
 if found then
   if cmd.company_id<>p_company_id or cmd.command<>'entitlement' or cmd.request_body<>body then raise exception 'Idempotency key input mismatch';end if;return cmd.result;
 end if;
 emp:=(p_row->>'employee_id')::uuid;
 if not exists(select 1 from public.employees e where e.id=emp and e.company_id=p_company_id) then raise exception 'Employee/company mismatch';end if;
 if p_row->>'module' not in ('receipt','fin_overtime','assignment','fin_extra') then raise exception 'Invalid entitlement module';end if;
 if p_loan is not null and p_loan<>'null'::jsonb and (p_row->>'module'<>'receipt' or p_row->>'sub_type'<>'سلفة') then raise exception 'Loan requires its receipt';end if;
 insert into public.hr_operations(company_id,employee_id,owner_id,module,status,effective_month,amount,days,start_date,end_date,notes,sub_type,data)
 values(p_company_id,emp,auth.uid(),p_row->>'module',p_row->>'status',p_row->>'effective_month',(p_row->>'amount')::numeric,(p_row->>'days')::numeric,
 (p_row->>'start_date')::date,(p_row->>'end_date')::date,p_row->>'notes',p_row->>'sub_type',coalesce(p_row->'data','{}')||jsonb_build_object('request_id',p_request_id,'flow',jsonb_build_object('state','new')))
 returning hr_operations.id,hr_operations.ref_no::text into id,ref;
 if p_loan is not null and p_loan<>'null'::jsonb then
   if (p_loan->>'amount')::numeric<>(p_row->>'amount')::numeric then raise exception 'Loan amount differs from receipt';end if;
   insert into public.hr_operations(company_id,employee_id,owner_id,module,status,effective_month,amount,sub_type,data,notes)
   values(p_company_id,emp,auth.uid(),'fin_repay','active',p_loan->>'effective_month',(p_loan->>'amount')::numeric,'سلفة على الراتب',
     coalesce(p_loan->'data','{}')||jsonb_build_object('receipt_id',id,'request_id',p_request_id,'flow',jsonb_build_object('state','new')),'سند '||ref);
 end if;
 r:=jsonb_build_object('ok',true,'id',id,'ref_no',ref);
 insert into public.hr_finance_commands values(p_request_id,p_company_id,'entitlement',body,r,auth.uid(),now());return r;
end $$;

-- Required authorization is inside every public RPC. Helper functions are not public write APIs.
revoke execute on function public.hr_require_finance(uuid),public.hr_lock_company(uuid),public.hr_capture_compensation(),public.hr_source_guard(),public.hr_log_change(),public.hr_immutable() from public,anon,authenticated;
revoke execute on function public.hr_finance_fingerprint(uuid),public.hr_apply_absence(uuid,text,text,jsonb,uuid),public.hr_create_entitlement(uuid,jsonb,jsonb,uuid) from public,anon;
grant execute on function public.hr_company_role(uuid),public.hr_finance_fingerprint(uuid),public.hr_apply_absence(uuid,text,text,jsonb,uuid),public.hr_create_entitlement(uuid,jsonb,jsonb,uuid) to authenticated;
commit;
