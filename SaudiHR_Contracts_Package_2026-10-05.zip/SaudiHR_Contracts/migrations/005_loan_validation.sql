begin;
create or replace function public.hr_loan_guard() returns trigger
language plpgsql security definer set search_path=pg_catalog,public as $$
declare e jsonb;f jsonb;r record;n integer;wage numeric;existing numeric;cap numeric;period date;a date;b date;days integer;ratio numeric;inst numeric;target text;
begin
 if new.module<>'fin_repay' or new.status in ('cancelled','rejected','stopped') or new.data#>>'{flow,state}' in ('cancelled','rejected') then return new;end if;
 n:=coalesce((new.data->>'installments')::integer,1);
 if n not between 1 and 120 or new.amount<=0 or new.effective_month !~ '^\d{4}-(0[1-9]|1[0-2])$' then raise exception 'Invalid loan schedule';end if;
 select to_jsonb(x) into e from public.employees x where id=new.employee_id and company_id=new.company_id;
 if e is null then raise exception 'Employee/company mismatch';end if;
 for i in 0..n-1 loop
  period:=(to_date(new.effective_month||'-01','YYYY-MM-DD')+i*interval '1 month')::date;target:=to_char(period,'YYYY-MM');
  select financials into f from public.hr_compensation_versions where employee_id=new.employee_id and effective_from<=period order by effective_from desc limit 1;
  if f is null then raise exception 'Dated wage required for loan affordability';end if;wage:=(f->>'total')::numeric;
  a:=greatest(public.hr_parse_date(e->>'start_date'),period);b:=(period+interval '1 month'-interval '1 day')::date;
  if coalesce((e->>'is_terminated')::boolean,false) then b:=least(b,public.hr_parse_date(e->>'clearance_last_day'));end if;
  days:=greatest(0,b-a+1);ratio:=case when a=period and b=(period+interval '1 month'-interval '1 day')::date then 1 else least(30,days)::numeric/30 end;
  select coalesce(sum(public.hr_loan_installment(o.amount,coalesce((o.data->>'installments')::integer,1),o.effective_month,target)),0) into existing from public.hr_operations o where o.company_id=new.company_id and o.employee_id=new.employee_id and o.module='fin_repay' and o.id<>new.id and coalesce(o.status,'') not in ('cancelled','rejected','stopped') and coalesce(o.data#>>'{flow,state}','') not in ('cancelled','rejected');
  cap:=round(wage*ratio*.1,2);inst:=public.hr_loan_installment(new.amount,n,new.effective_month,target);
  if existing+inst>cap then raise exception 'Loan collision in %: installment % existing % cap %',target,inst,existing,cap;end if;
 end loop;return new;
end $$;
drop trigger if exists hr_loan_guard on hr_operations;
create trigger hr_loan_guard before insert or update on hr_operations for each row execute function public.hr_loan_guard();
revoke execute on function public.hr_loan_guard() from public,anon,authenticated;
commit;
