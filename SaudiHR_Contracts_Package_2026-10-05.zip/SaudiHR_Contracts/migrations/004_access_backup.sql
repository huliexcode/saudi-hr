-- Restrictive tenant policies narrow existing permissive policies; they never widen a tenant scope.
begin;
do $$declare t text;scope text;write_scope text;begin
 foreach t in array array['employees','hr_operations','employee_requests','salary_adjustments','departments','custody_items','employee_documents','employee_attendance','document_templates','hr_communications','ask_knowledge','company_members'] loop
  if to_regclass('public.'||t) is null then raise exception 'Required backup table missing: %',t;end if;
  if t in ('salary_adjustments','custody_items','employee_documents') then
   scope:='public.hr_company_role((select e.company_id from public.employees e where e.id=employee_id))';
  else scope:='public.hr_company_role(company_id)';end if;
  write_scope:=scope||case when t='company_members' then ' in (''owner'',''admin'')' else ' in (''owner'',''admin'',''hr'',''accountant'')' end;
  execute format('alter table public.%I enable row level security',t);
  execute format('revoke all on public.%I from public,anon',t);
  execute format('drop policy if exists hr_tenant_read on public.%I',t);
  execute format('create policy hr_tenant_read on public.%I as restrictive for select to authenticated using (%s in (''owner'',''admin'',''hr'',''accountant'',''viewer''))',t,scope);
  execute format('drop policy if exists hr_tenant_insert on public.%I',t);
  execute format('create policy hr_tenant_insert on public.%I as restrictive for insert to authenticated with check (%s)',t,write_scope);
  execute format('drop policy if exists hr_tenant_update on public.%I',t);
  execute format('create policy hr_tenant_update on public.%I as restrictive for update to authenticated using (%s) with check (%s)',t,write_scope,write_scope);
  execute format('drop policy if exists hr_tenant_delete on public.%I',t);
  execute format('create policy hr_tenant_delete on public.%I as restrictive for delete to authenticated using (%s)',t,write_scope);
  -- Provide a tenant-scoped permissive policy if the original installation has no policy at all.
  if not exists(select 1 from pg_policies where schemaname='public' and tablename=t and permissive='PERMISSIVE') then
   execute format('create policy hr_tenant_base on public.%I for all to authenticated using (%s is not null) with check (%s is not null)',t,scope,scope);
  end if;
 end loop;
end $$;
alter table companies enable row level security;
revoke all on companies from public,anon;
drop policy if exists hr_company_read on companies;
create policy hr_company_read on companies as restrictive for select to authenticated using(public.hr_company_role(id) is not null);
drop policy if exists hr_company_write on companies;
create policy hr_company_write on companies as restrictive for update to authenticated using(public.hr_company_role(id) in ('owner','admin')) with check(public.hr_company_role(id) in ('owner','admin'));
drop policy if exists hr_company_insert on companies;
create policy hr_company_insert on companies as restrictive for insert to authenticated with check(owner_id=auth.uid());
drop policy if exists hr_company_delete on companies;
create policy hr_company_delete on companies as restrictive for delete to authenticated using(owner_id=auth.uid());
do $$begin if not exists(select 1 from pg_policies where schemaname='public' and tablename='companies' and permissive='PERMISSIVE') then
 create policy hr_company_base on companies for all to authenticated using(public.hr_company_role(id) is not null) with check(owner_id=auth.uid() or public.hr_company_role(id) in ('owner','admin'));
end if;end $$;
grant select on public.hr_finance_commands to authenticated;
drop policy if exists hr_commands_backup_read on hr_finance_commands;
create policy hr_commands_backup_read on hr_finance_commands for select to authenticated using(public.hr_company_role(company_id) in ('owner','admin'));
create or replace function public.hr_backup_manifest(p_company_id uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog,public,storage as $$
declare result jsonb;begin
 if coalesce(public.hr_company_role(p_company_id),'') not in ('owner','admin') then raise exception 'Backup administrator permission required' using errcode='42501';end if;
 select coalesce(jsonb_agg(jsonb_build_object('bucket',o.bucket_id,'path',o.name,'metadata',o.metadata) order by o.bucket_id,o.name),'[]') into result from storage.objects o
 where o.bucket_id in ('employee-docs','hr-documents','company-assets') and (
  exists(select 1 from public.employee_documents d join public.employees e on e.id=d.employee_id where e.company_id=p_company_id and d.file_path=o.name)
  or o.name like '%/'||p_company_id::text||'/%'
  or exists(select 1 from public.employees e where e.company_id=p_company_id and e.portal_token is not null and o.name like 'portal/'||e.portal_token||'/%'));
 return result;
end $$;
revoke execute on function public.hr_backup_manifest(uuid) from public,anon;
grant execute on function public.hr_backup_manifest(uuid) to authenticated;
create or replace function public.hr_backup_fingerprint(p_company_id uuid) returns text
language plpgsql security definer set search_path=pg_catalog,public as $$
declare t text;rows jsonb;payload jsonb:='{}';begin
 if coalesce(public.hr_company_role(p_company_id),'') not in ('owner','admin') then raise exception 'Backup administrator permission required' using errcode='42501';end if;
 foreach t in array array['employees','hr_operations','employee_requests','salary_adjustments','departments','custody_items','employee_documents','employee_attendance','document_templates','hr_communications','ask_knowledge','company_members','hr_compensation_versions','hr_payroll_runs','hr_audit_events','hr_finance_commands'] loop
  if t in ('salary_adjustments','custody_items','employee_documents') then
   execute format('select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]'') from public.%I x join public.employees e on e.id=x.employee_id where e.company_id=$1',t) into rows using p_company_id;
  else execute format('select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),''[]'') from public.%I x where x.company_id=$1',t) into rows using p_company_id;end if;
  payload:=payload||jsonb_build_object(t,rows);
 end loop;
 select payload||jsonb_build_object('company',to_jsonb(c)) into payload from public.companies c where c.id=p_company_id;
 payload:=payload||jsonb_build_object('files',public.hr_backup_manifest(p_company_id));return md5(payload::text);
end $$;
revoke execute on function public.hr_backup_fingerprint(uuid) from public,anon;
grant execute on function public.hr_backup_fingerprint(uuid) to authenticated;
commit;
