// Every production connection is replaced; no live Supabase calls can leave this test.
window.__auditCalls=[];window.__auditRows={};window.__auditErrors={};window.__auditRpcErrors={};window.__runtimeErrors=[];
addEventListener('error',e=>window.__runtimeErrors.push(String(e.message)));addEventListener('unhandledrejection',e=>window.__runtimeErrors.push(String(e.reason)));
window.supabase={createClient(){
 function query(table){let action='select',payload=null,single=false,start=0,end=Infinity,filters=[],chain;
 chain=new Proxy({},{get(_,key){if(key==='then')return(resolve,reject)=>{
   window.__auditCalls.push({table,action,payload});let data=window.__auditRows[table]||[];
   data=data.filter(x=>filters.every(f=>f(x))).slice(start,end+1);if(single)data=action==='select'?(data[0]||null):{id:'audit-row',ref_no:99,...payload};return Promise.resolve({data,error:window.__auditErrors[table]||null}).then(resolve,reject);
 };return(...args)=>{if(['insert','update','upsert','delete'].includes(key)){action=key;payload=args[0];}
 if(key==='eq')filters.push(x=>x[args[0]]===args[1]);if(key==='in')filters.push(x=>args[1].includes(x[args[0]]));if(key==='gte')filters.push(x=>x[args[0]]>=args[1]);if(key==='lte')filters.push(x=>x[args[0]]<=args[1]);if(key==='range'){start=args[0];end=args[1];}if(key==='limit')end=args[0]-1;if(key==='single'||key==='maybeSingle')single=true;return chain;};}});return chain;}
 return {from:query,rpc:async(name,args)=>{window.__auditCalls.push({rpc:name,args});const error=window.__auditRpcErrors[name];return {data:error?null:name.includes('fingerprint')?'stable-fingerprint':name==='hr_backup_manifest'?[]:name==='hr_apply_absence'||name==='hr_create_entitlement'||name==='hr_close_payroll'?{ok:true,id:'test-rpc',ref_no:99}:[],error:error||null}},
 auth:{onAuthStateChange:()=>({data:{subscription:{unsubscribe(){}}}}),getSession:async()=>({data:{session:null},error:null}),getUser:async()=>({data:{user:null}}),signOut:async()=>({error:null})},
 functions:{invoke:async()=>({data:{},error:null})},storage:{from(){return {download:async()=>({data:new Blob(['fixture']),error:null}),upload:async()=>({data:{path:'fixture'},error:null}),remove:async()=>({error:null}),getPublicUrl:()=>({data:{publicUrl:''}}),createSignedUrl:async()=>({data:{signedUrl:''},error:null})}}},channel(){return {on(){return this},subscribe(){return this}}},removeChannel(){}};
}};
window.fetch=async()=>({ok:true,json:async()=>({})});
