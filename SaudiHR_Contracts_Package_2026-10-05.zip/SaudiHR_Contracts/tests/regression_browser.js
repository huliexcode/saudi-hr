addEventListener('DOMContentLoaded',()=>setTimeout(async()=>{
 const cases=[]; const same=(a,b)=>Math.abs(a-b)<0.011;
 function check(id,name,actual,expected,pass){cases.push({id,name,actual,expected,pass:pass===undefined?JSON.stringify(actual)===JSON.stringify(expected):pass});}
 const mk=()=>({id:'audit-emp',companyId:'audit-co',name:'موظف اختبار',nid:'1000000000',nationality:'سعودي',startDate:'2020-01-01',isArchived:false,isTerminated:false,clearanceData:{},financials:{total:6000,basic:4000,housing:1000,transport:1000,gosi:487.5},payMethod:'wps',gosiVerified:true,iban:'SA0380000000608010167519',tasksCompleted:[],clearanceTasks:[]});
 try {
 currentUser={id:'audit-user',email:'test@example.invalid'};companies=[{id:'audit-co',ownerId:'audit-user',nameAr:'منشأة اختبار معزولة',workingHours:'8 ساعات يوميا لمدة 5 أيام في الأسبوع',annualLeaveDays:30}];activeCompanyId='audit-co';myRole='owner';departments=[];hrOps=[];hrRequests=[];salaryAdjustments=[];hrOpsLoaded=true;hrReqLoaded=true;employees=[mk()];
 const emp=employees[0];
 check('C01','رفض تاريخ غير موجود',HRCore.date('2026-02-30'),null);
 check('C02','قبول السنة الكبيسة',HRCore.iso(HRCore.date('2024-02-29')),'2024-02-29');
 check('C03','استحقاق شهر فبراير كامل',HRCore.servicePeriod('2020-01-01',null,'2026-02').payDays,30);
 check('C04','الالتحاق في منتصف الشهر',HRCore.servicePeriod('2026-04-16',null,'2026-04').payDays,15);
 check('C05','لا راتب قبل المباشرة',HRCore.servicePeriod('2026-11-01',null,'2026-10').payDays,0);
 check('C06','رفض نهاية قبل البداية',HRCore.servicePeriod('2026-10-20','2026-10-10','2026-10').errors.length>0,true);
 check('C07','كامل التأمينات في شهر الالتحاق',HRCore.gosiDue('2026-10-25',null,'2026-10'),true);
 check('C08','خروج جزئي بعد أشهر خدمة',HRCore.gosiDue('2020-01-01','2026-10-20','2026-10'),false);
 check('C09','الدخول والخروج في الشهر نفسه',HRCore.gosiDue('2026-10-05','2026-10-20','2026-10'),true);
 check('C10','استثناء اتفاق حفظ الخدمة',HRCore.unpaidServiceDays({days:60,preserve_service:true}),0);
 check('C11','تعليق خدمة غير مدفوعة فوق 20',HRCore.unpaidServiceDays({days:60}),40);
 check('C12','أجر إضافي: 6000 و4000 أساسي و4 ساعات',HRCore.overtime(emp.financials,4,1,8).amount,133.33);
 check('C13','رفض إضافي سالب',(()=>{try{HRCore.overtime(emp.financials,-1);return false}catch(_){return true}})(),true);
 check('C14','جدول يحافظ على مجموع الأقساط',repaySchedule(100,3,'2026-10').reduce((s,r)=>s+r.amount,0),100);
 check('C15','آخر قسط يعالج الكسور',repaySchedule(100,3,'2026-10').map(r=>r.amount),[33.33,33.33,33.34]);
 check('C16','عدم اعتبار 7 أيام عمل جدولاً صحيحاً',HRCore.scheduleValid({hours:8,days:[0,1,2,3,4,5,6]}),false);
 check('C17','جدول ساري بتاريخ محدد',HRCore.chooseSchedule({workSchedules:[{hours:8,days:[0,1,2,3,4],effectiveFrom:'2026-01-01'},{hours:6,days:[0,1,2,3,4],effectiveFrom:'2026-11-01'}]},emp.id,'2026-10-01').hours,8);
 check('C18','تطبيع البحث العربي',HRCore.normalizeArabic('إدارة'),'اداره');
 check('C19','نهاية خدمة كاملة: خمس سنوات',computeEndOfService('2020-01-01','2024-12-31',6000,'full',[]).total,15000);
 check('C20','نهاية خدمة: سنة سادسة كاملة',computeEndOfService('2020-01-01','2025-12-31',6000,'full',[]).total,21000);
 check('C21','استقالة أقل من سنتين',computeEndOfService('2025-01-01','2026-01-01',6000,'resignation',[]).total,0);
 check('C22','استقالة بعد خمس سنوات بالضبط',computeEndOfService('2020-01-01','2024-12-31',6000,'resignation',[]).total,5000);
 check('C23','الراتب الشهري الأساسي',payrollFor(emp,'2026-10',[]).net,5512.5);
 // Scenarios expected to expose defects.
 hrRequests=[{employee_id:emp.id,request_type:'leave',status:'approved',sub_type:'إجازة غير مدفوعة الأجر',date_from:'2026-10-01',date_to:'2026-10-10',days:10}];
 check('D01','10 أيام غير مدفوعة تؤثر على الراتب',payrollFor(emp,'2026-10',[]).net,3512.5);
 hrRequests=[{employee_id:emp.id,request_type:'leave',status:'approved',sub_type:'الإجازة المرضية',date_from:'2026-09-01',date_to:'2026-09-30',days:30},{employee_id:emp.id,request_type:'leave',status:'approved',sub_type:'الإجازة المرضية',date_from:'2026-10-01',date_to:'2026-10-30',days:30}];
 check('D02','المرضية الثانية في السنة بثلاثة أرباع الأجر',payrollFor(emp,'2026-10',[]).net,4012.5);
 hrRequests=[];emp.compensationHistory=[{id:'dated-salary',effective_from:'2026-01-01',financials:{...emp.financials},gosi_status:emp.gosiStatus}];let old=payrollFor(emp,'2026-01',[]).total;emp.financials.total=8000;let changed=payrollFor(emp,'2026-01',[]).total;check('D03','الأشهر الماضية تحفظ الأجر السابق',{old,changed},{old:6000,changed:6000});emp.financials.total=6000;emp.compensationHistory=[];
 check('D04','رفض آيبان SA00 مع 22 صفراً',ibanValid('SA0000000000000000000000'),false);
 hrOps=[{id:'bad-absence',company_id:activeCompanyId,employee_id:emp.id,module:'fin_absence',status:'open',effective_month:'2026-10',days:-2}];
 check('D05','الغياب السالب لا يزيد الصافي',{net:payrollFor(emp,'2026-10',[]).net,errors:payrollFor(emp,'2026-10',[]).errors},'رفض إدخال غياب سالب',payrollFor(emp,'2026-10',[]).errors.length>0);
 hrOps=[{id:'bad-money',company_id:activeCompanyId,employee_id:emp.id,module:'fin_perf',status:'active',effective_month:'2026-10',amount:'broken'}];
 check('D06','المبلغ النصي الفاسد يوقف الصرف',payrollFor(emp,'2026-10',[]).errors,'خطأ تحقق',payrollFor(emp,'2026-10',[]).errors.length>0);
 hrOps=[];emp.financials.total='broken';check('D07','الراتب النصي الفاسد يظهر خطأ',payrollFor(emp,'2026-10',[]).errors,'خطأ تحقق',payrollFor(emp,'2026-10',[]).errors.length>0);emp.financials.total=6000;
 const ded=computeEndOfService('2020-01-01','2025-12-31',6000,'full',[{date:'2024-12-21',days:40}]);check('D08','خصم إجازة عابرة للسنة يوزع حسب الخدمة الفعلية',ded.total,20333.33,same(ded.total,20333.33));
 const single=computeEndOfService('2026-02-28','2026-02-28',6000,'full',[]);check('D09','يوم خدمة واحد في فبراير لا يتحول إلى ثلاثة',{days:single.totalDays,total:single.total},{days:1,total:8.33});
 // Failure injection: no production requests are possible.
 window.__auditRows.hr_operations=[];window.__auditRpcErrors.hr_apply_absence={message:'injected save failure'};absenceDraft={month:'2026-10',source:'sheet',rows:[{emp,days:2,note:''}]};
 const messages=[];const toast=window.showToast;window.showToast=(m,t)=>messages.push({message:m,type:t});await window.applyAbsenceDraft();check('D10','فشل حفظ الغياب لا يعلن الاعتماد',{messages,draft:absenceDraft},'رسالة فشل مع إبقاء المسودة',messages.some(m=>m.type==='error')&&absenceDraft!==null);window.showToast=toast;window.__auditErrors={};window.__auditRpcErrors={};hrOps=[];hrOpsLoaded=true;
 // Bank export must not silently ignore missing salary adjustments.
 const host=document.createElement('div');host.id='audit-bank-host';document.body.append(host);renderBankFile(host);document.getElementById('bf-month').value='2026-10';
 window.__auditRows.employees=[{id:emp.id,company_id:activeCompanyId,owner_id:currentUser.id,name:emp.name,nid:emp.nid,nationality:emp.nationality,start_date:emp.startDate,total_salary:6000,basic_salary:4000,housing_allowance:1000,transport_allowance:1000,gosi_deduction:487.5,iban:emp.iban,pay_method:'wps',hr_gosi_verified:true}];
 window.__auditErrors.salary_adjustments={message:'injected adjustment read failure'};
 let blocked=false;try{await buildBankFile()}catch(e){blocked=true}check('D11','فشل تحميل تعديلات الراتب يمنع ملف البنك',blocked,true);window.__auditErrors={};host.remove();employees=[emp];hrOpsLoaded=true;hrReqLoaded=true;
 // Partial imported absence list should not create implicit zero rows for everyone else.
 check('D12','نسخ كاملة للعهد تشمل سجل custody_items',BACKUP_TABLES.some(x=>x[0]==='custody_items'),true);
 const settings=structuredClone(policySettings);settings.gosi={saudi:{exempt:true}};applyPolicySettings(settings);check('D13','اختلاف سياسة التأمينات عن الخصم المخزن يوقف الصرف',{configured:gosiRateFor('سعودي',false).emp,actual:payrollFor(emp,'2026-10',[]).gosi},'خصم صفر أو تنبيه اختلاف',same(payrollFor(emp,'2026-10',[]).gosi,0)||payrollFor(emp,'2026-10',[]).errors.length>0);applyPolicySettings({});
 check('D14','راتب 60 ألف يراعي سقف الأجر التأميني 45000',HRCore.distribute(60000,0,gosiRateFor('سعودي',false)).gosi,4387.5);
 emp.financials.isNewGosi=true;emp.financials.gosi=537.5;emp.startDate='2026-10-25';check('D15','النظام الجديد: شهر الدخول الجزئي لا يخصم اشتراك شهر كامل',payrollFor(emp,'2026-10',[]).gosi,'اشتراك نسبي للأيام',payrollFor(emp,'2026-10',[]).gosi>0&&payrollFor(emp,'2026-10',[]).gosi<537.5);
 emp.startDate='2025-01-01';emp.isTerminated=true;emp.clearanceData.lastDay='2026-10-20';check('D16','النظام الجديد: الخروج في منتصف الشهر لا يلغي الاشتراك',payrollFor(emp,'2026-10',[]).gosi,'اشتراك نسبي موجب',payrollFor(emp,'2026-10',[]).gosi>0);emp.startDate='2020-01-01';emp.isTerminated=false;emp.clearanceData={};emp.financials.isNewGosi=false;emp.financials.gosi=487.5;
 const bal=essLeaveBalance({start_date:'2026-01-01',annual_leave_days:30},[]);check('D17','رصيد بوابة الموظف يراعي ميزة العقد 30 يوماً',bal.entitled,30);
 const year=new Date().getFullYear();const cross=essLeaveBalance({start_date:'2020-01-01'},[{request_type:'leave',status:'approved',sub_type:'الإجازة السنوية',date_from:(year-1)+'-12-29',date_to:year+'-01-04',days:7}]);check('D18','إجازة عابرة للسنة تخصم أيام السنة الحالية',cross.used,4);
 const previous=payrollRows('2026-01').length;emp.isArchived=true;check('D19','أرشفة الموظف لا تزيل راتبه التاريخي',{before:previous,after:payrollRows('2026-01').length},{before:previous,after:previous});emp.isArchived=false;
 const operation={id:'flow-test',company_id:activeCompanyId,employee_id:emp.id,module:'fin_perf',status:'active',effective_month:'2026-10',amount:500,data:{}};hrOps=[operation];const flowHost=document.createElement('div');flowHost.innerHTML=flowControlsHtml(operation);document.body.append(flowHost);document.getElementById('flow-state-flow-test').value='rejected';await window.setOpFlow(operation.id,'');check('D20','رفض الحركة في مسار الاعتماد يوقف أثرها المالي',{flow:wfState(operation),status:operation.status,addition:payrollFor(emp,'2026-10',[]).addT},{flow:'rejected',status:'rejected',addition:0},payrollFor(emp,'2026-10',[]).addT===0);flowHost.remove();
 hrOps=[{id:'future-loan',company_id:activeCompanyId,employee_id:emp.id,module:'fin_repay',status:'active',effective_month:'2026-11',amount:1000,data:{installments:2}}];const loanRec={type:'receipt',sub:'سلفة',amount:1200,installments:4,payroll:true,month:'2026-10',from:'2026-10-01'};const loanErrors=validateEntitlementForEmployee(loanRec,emp);check('D21','سند السلفة يفحص تزاحم أقساط جميع الأشهر المقبلة',{errors:loanErrors,fullCheck:repayCheck(emp,1200,4,'2026-10').ok},'رفض تزاحم نوفمبر وديسمبر',loanErrors.length>0);hrOps=[];
 window.__tagProbe=0;const probe="x');window.__tagProbe=1;//";standardTags.push(probe);window.toggleTagMenu({clientY:100,clientX:300,target:document.body},emp.id);document.querySelector('#tags-list-container .tag-item:last-child').click();check('D22','التصنيف النصي لا ينفذ JavaScript عند الضغط',window.__tagProbe,0);standardTags.pop();document.getElementById('tag-dropdown-menu')?.remove();
 let count=0;
 for(let a=1;a<=100;a++)for(let n=1;n<=12;n++){const amount=a+0.01;const rows=repaySchedule(amount,n,'2026-10');if(same(rows.reduce((s,r)=>s+r.amount,0),amount)&&rows.every(r=>r.amount>=0))count++;}
 check('P01','1200 جدول سلفة: مجموع صحيح وغير سالب',count,1200);
 let distributed=0;for(let a=1;a<=1000;a++){const d=HRCore.distribute(a+0.37,0,gosiRateFor('سعودي',false));if(same(d.basic+d.housing+d.transport,a+0.37))distributed++;}check('P02','1000 توزيع أجر: البنود تطابق الإجمالي',distributed,1000);
 // Prepare a realistic isolated UI for inspection.
 employees=[mk(),{...mk(),id:'audit-emp2',name:'موظفة اختبار',jobTitle:'معلمة',nationality:'غير سعودي',startDate:'2026-09-01',financials:{total:5000,basic:3703.7,housing:925.93,transport:370.37,gosi:0}}];hrOps=[];hrRequests=[];hrOpsLoaded=true;hrReqLoaded=true;window.__auditErrors={};
 document.getElementById('auth-screen').classList.add('hidden');document.getElementById('auth-loading-screen').classList.add('hidden');document.getElementById('hr-layout').classList.remove('hidden');document.getElementById('hr-layout').classList.add('flex');renderCompanySelector();populateDepartmentDropdowns();window.switchView('overview');
 } catch(e){cases.push({id:'RUNTIME',name:'اختبار التشغيل',actual:String(e.stack||e),expected:'لا خطأ',pass:false});}
 const result={cases,runtimeErrors:window.__runtimeErrors,calls:window.__auditCalls,meta:{network:'isolated; production client replaced',pass:cases.filter(x=>x.pass).length,fail:cases.filter(x=>!x.pass).length}};window.__auditResult=result;

 const badge=document.createElement('div');badge.id='audit-test-result';badge.textContent=`اختبار معزول: ${result.meta.pass} ناجح، ${result.meta.fail} يحتاج إصلاح`;badge.style.cssText='position:fixed;bottom:8px;left:8px;background:#fff;padding:8px;z-index:99999;font:12px Arial;color:#111;box-shadow:0 0 5px #777';document.body.append(badge);
},150));
