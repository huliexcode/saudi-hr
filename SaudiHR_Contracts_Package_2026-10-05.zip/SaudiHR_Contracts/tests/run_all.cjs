const {spawnSync}=require('child_process'),path=require('path');
for(const test of ['sql_tests.cjs','contracts_tests.cjs','restore_tests.cjs','browser_runner.cjs']){const r=spawnSync(process.execPath,[path.join(__dirname,test)],{stdio:'inherit',env:process.env});if(r.status!==0)process.exit(r.status||1);}
