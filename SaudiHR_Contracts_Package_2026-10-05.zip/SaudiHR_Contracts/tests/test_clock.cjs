// Freeze only the isolated test process. Production calculations still use real Riyadh dates.
require('node:test').mock.timers.enable({apis:['Date'],now:Date.UTC(2026,9,5,12)});
