/* Database completeness, payroll versioning, safe UI actions. Embedded into the existing application. */
let hrIntegrityState = {companyId:null,loading:null,ready:false,error:'لم تُحمّل بيانات اعتماد المسير',snapshots:[],versions:[]};
let salaryAdjustmentsLoaded = false;
let absenceSaving = false;
const entitlementRetryIds=Object.create(null);
function integrityCommandPrefix(kind) {return 'hr_command:'+currentUser.id+':'+activeCompanyId+':'+kind+':';}
async function integrityEntitlementToken(body) {
    const key=integrityCommandPrefix('entitlement')+await integritySha256(new TextEncoder().encode(JSON.stringify(body)));
    try {const old=JSON.parse(localStorage.getItem(key)||'null');if(old?.id)return {key,...old};const token={id:crypto.randomUUID(),confirmed:false};localStorage.setItem(key,JSON.stringify(token));return {key,...token};}
    catch(e){throw new Error('تعذر حفظ مفتاح إعادة المحاولة؛ لم يرسل المستحق حتى تتوفر مساحة التخزين في المتصفح');}
}
function integrityConfirmEntitlementToken(token) {localStorage.setItem(token.key,JSON.stringify({id:token.id,confirmed:true}));}
window.integrityStartNewEntitlement=function() {
    const prefix=integrityCommandPrefix('entitlement');
    for(const key of Object.keys(localStorage))if(key.startsWith(prefix)){try{if(JSON.parse(localStorage.getItem(key))?.confirmed)localStorage.removeItem(key);}catch(_){} }
    window.showToast('سيكون الحفظ القادم مستحقًا مستقلًا؛ استخدمه عند إصدار عملية جديدة فعلًا');
};
window.integritySaveLeaveOpening=async function(id) {
    try {
        integrityRequireFinance();const days=Number(document.getElementById('ss-leave-opening')?.value),evidence=document.getElementById('ss-leave-evidence')?.value.trim();
        if(!Number.isFinite(days)||days<0||!evidence)throw new Error('أدخل رصيدًا افتتاحيًا غير سالب ومرجع الكشف');
        const opening={year:Number(HRIntegrity.today().slice(0,4)),days,evidence},r=await supabaseClient.from('employees').update({leave_opening_balance:opening}).eq('id',id).eq('company_id',activeCompanyId);if(r.error)throw r.error;
        const e=employees.find(e=>e.id===id);if(e)e.leaveOpeningBalance=opening;integrityInvalidate();window.showToast('حُفظ الرصيد الافتتاحي الموثق');
    }catch(e){window.showToast(e.message,'error');}
};
window.integrityVerifyGosi=async function(id) {
    try {
        integrityRequireFinance();const evidence=document.getElementById('ss-gosi-evidence')?.value.trim();if(!evidence||evidence.length<4)throw new Error('أدخل مرجع بيان الاشتراكات الذي راجعته');
        const r=await supabaseClient.from('employees').update({hr_gosi_verified:true,hr_gosi_evidence:evidence}).eq('id',id).eq('company_id',activeCompanyId);if(r.error)throw r.error;
        const emp=employees.find(e=>e.id===id);if(emp){emp.gosiVerified=true;emp.gosiEvidence=evidence;}integrityInvalidate();window.showToast('حُفظ إثبات المطابقة');
    }catch(e){window.showToast(e.message,'error');}
};
function integrityInvalidate() {
    hrIntegrityState.ready=false;
    hrIntegrityState.error='تغيرت البيانات؛ أعد المراجعة قبل الصرف';
    bankFileCache=null;
}
async function integrityReadAll(table, build) {
    const result=[],size=500; let offset=0;
    for(;;) {
        const q=build(supabaseClient.from(table).select('*')).range(offset,offset+size-1);
        const r=await q;
        if(r.error) throw new Error('تعذر تحميل '+table+': '+r.error.message);
        if(!Array.isArray(r.data)) throw new Error('استجابة بيانات غير صالحة: '+table);
        result.push(...r.data);
        if(r.data.length<size) return result;
        offset+=size;
        if(offset>500000) throw new Error('تجاوز حجم البيانات المسموح في هذه الجلسة؛ يلزم استعلام مخصص');
    }
}
async function loadIntegrityData() {
    const companyId=activeCompanyId,revision=companyRevision;
    if(hrIntegrityState.loading&&hrIntegrityState.companyId===companyId) return hrIntegrityState.loading;
    const state={companyId,ready:false,error:'جاري تحميل بيانات اعتماد المسير',snapshots:[],versions:[],loading:null};
    hrIntegrityState=state;
    state.loading=(async()=>{
        try {
            const [snapshots,versions,contracts,entries,months]=await Promise.all([
                integrityReadAll('hr_payroll_runs',q=>q.eq('company_id',companyId).order('month').order('id')),
                integrityReadAll('hr_compensation_versions',q=>q.eq('company_id',companyId).order('effective_from').order('id')),
                integrityReadAll('hr_contracts',q=>q.eq('company_id',companyId).order('start_date').order('id')),
                integrityReadAll('hr_contract_entries',q=>q.eq('company_id',companyId).order('work_date').order('id')),
                integrityReadAll('hr_contract_months',q=>q.eq('company_id',companyId).order('month').order('id'))
            ]);
            if(companyId!==activeCompanyId||revision!==companyRevision) throw new Error('تغيرت المنشأة أثناء التحميل');
            state.contracts=contracts;state.entries=entries;state.months=months;state.snapshots=snapshots;state.versions=versions;state.ready=true;state.error='';
            employees.forEach(e=>{e.compensationHistory=versions.filter(v=>v.employee_id===e.id);e.contracts=contracts.filter(c=>c.employee_id===e.id);e.contractEntries=entries.filter(c=>c.employee_id===e.id);e.contractMonths=months.filter(c=>c.employee_id===e.id);const c=HRContracts.active(e,HRIntegrity.today());if(c){e.financials={...c.financials,gosi:e.financials?.gosi||0,isNewGosi:e.financials?.isNewGosi};e.contractDuration=HRContracts.summary(c);e.contractBasis=c.basis;}e.contractsRequired=getActiveCompany()?.policySettings?.hr_contracts_required!==false&&policySettings.hr_contracts_required!==false;});
            return true;
        } catch(e) {state.error='تعذر تجهيز سجل الرواتب المعتمد: '+e.message;return false;}
        finally {state.loading=null;}
    })();
    return state.loading;
}
function integritySnapshot(month) {
    if(hrIntegrityState.companyId!==activeCompanyId||!hrIntegrityState.ready) return null;
    return hrIntegrityState.snapshots.find(r=>r.month===month&&r.status==='closed')||null;
}
function integrityStoredRows(run) {
    const rows=run?.rows;
    if(!Array.isArray(rows)) throw new Error('بيانات المسير المقفل غير سليمة');
    return rows.map(row=>{
        if(!row.e||!row.p||!Number.isFinite(Number(row.p.net))) throw new Error('صف مسير مقفل غير صالح');
        const r=structuredClone(row);
        for(const k of ['first','last','from','to']) if(r.p.service?.[k]) r.p.service[k]=HRCore.date(String(r.p.service[k]).slice(0,10));
        r.p.closedRunId=run.id;r.p.closed=true;
        return r;
    });
}
async function integrityPreparePayroll(month) {
    HRCore.monthBounds(month);
    if(pendingEmployeePatches.size) throw new Error('توجد تغييرات موظفين لم تُحفظ؛ انتظر الحفظ أو أصلح الخطأ');
    const revision=companyRevision,companyId=activeCompanyId;
    const before=await supabaseClient.rpc('hr_finance_fingerprint',{p_company_id:companyId});
    if(before.error||typeof before.data!=='string')throw new Error(before.error?.message||'تعذر تثبيت مصادر المسير');
    await loadEmployeesFromDb();
    await Promise.all([loadHrOps(),loadHrRequests(),loadSalaryAdjustmentsFromDb(),loadIntegrityData()]);
    if(revision!==companyRevision||companyId!==activeCompanyId) throw new Error('تغيرت المنشأة أثناء تجهيز المسير');
    if(hrOpsLoaded!==true||hrReqLoaded!==true||salaryAdjustmentsLoaded!==true||!hrIntegrityState.ready) throw new Error(hrIntegrityState.error||'تعذر تحميل جميع مصادر الرواتب؛ التصدير موقوف');
    const after=await supabaseClient.rpc('hr_finance_fingerprint',{p_company_id:companyId});
    if(after.error||after.data!==before.data)throw new Error('تغيرت مصادر المسير أثناء التحميل؛ أعد المراجعة');
    hrIntegrityState.fingerprint=before.data;
    return payrollRows(month);
}
function integrityCanFinance() {
    return ['owner','admin','hr','accountant'].includes(myRole);
}
function integrityRequireFinance() {
    if(!integrityCanFinance()) throw new Error('هذا الإجراء يتطلب صلاحية مالية؛ يتحقق الخادم من الصلاحية أيضًا');
}
window.closePayrollMonth=async function() {
    try {
        integrityRequireFinance();
        const month=document.getElementById('crx-month-select')?.value||thisMonthStr();
        const rows=await integrityPreparePayroll(month);
        if(integritySnapshot(month)) return window.showToast('المسير مقفل مسبقًا');
        if(!rows.length) throw new Error('لا يوجد موظفون مستحقون');
        const problems=rows.flatMap(r=>payrollValidation(r.p).map(x=>r.e.name+': '+x));
        if(problems.length) throw new Error([...new Set(problems)].join('، '));
        const safeRows=rows.map(row=>({...row,e:{...Object.fromEntries(['id','companyId','name','nid','nationality','iban','bank','startDate','isTerminated','terminationRecorded','isUnderNotice','isArchived','departmentId','empNumber','payMethod','payMethodNote'].map(k=>[k,row.e[k]??null])),clearanceData:{lastDay:employmentEnd(row.e)}}}));
        const r=await supabaseClient.rpc('hr_close_payroll',{p_company_id:activeCompanyId,p_month:month,p_rows:safeRows,p_source_fingerprint:hrIntegrityState.fingerprint,p_request_id:crypto.randomUUID()});
        if(r.error) throw r.error;
        integrityInvalidate();await loadIntegrityData();await renderPayrollRegister();
        window.showToast('تم اعتماد وإقفال المسير على الخادم؛ التصدير يستخدم هذه النسخة فقط');
    } catch(e) {window.showToast(e.message||'تعذر إقفال المسير','error');}
};
window.integrityReviewReload=async()=>{integrityInvalidate();await renderPayrollRegister();};
function integrityPayrollBanner(month) {
    const run=integritySnapshot(month);
    const contractsButton='<button type="button" onclick="window.openContracts()" class="border rounded-lg px-3 py-1 text-xs">العقود ووحدات العمل</button>';
    const text=run?'مسير مقفل • '+month+' • تصدير ثابت من النسخة المعتمدة':hrIntegrityState.ready?'مسودة • راجع البنود ثم اعتمد وأقفل الشهر قبل الصرف':hrIntegrityState.error;
    return `<div class="p-3 mb-3 rounded-xl border ${run?'border-emerald-300 bg-emerald-50':'border-amber-300 bg-amber-50'}"><p class="text-xs font-bold">${escapeHtml(text)}</p><div class="flex gap-2 mt-2">${contractsButton}<button type="button" onclick="window.integrityReviewReload()" class="border rounded-lg px-3 py-1 text-xs">تحديث المراجعة</button>${!run&&integrityCanFinance()?'<button type="button" onclick="window.closePayrollMonth()" class="bg-emerald-700 text-white rounded-lg px-3 py-1 text-xs">اعتماد وإقفال الشهر</button>':''}</div></div>`;
}
async function integrityExportRows(month) {
    integrityRequireFinance();
    await integrityPreparePayroll(month);
    const snapshot=integritySnapshot(month);
    if(!snapshot) throw new Error('اعتمد وأقفل المسير أولًا؛ لا يصدر ملف صرف من مسودة');
    return integrityStoredRows(snapshot);
}
function integrityPaintTags(container,query,empId) {
    container.replaceChildren();const q=String(query||'').trim().toLowerCase();
    const tags=standardTags.filter(t=>String(t).toLowerCase().includes(q));
    for(const tag of tags) {
        const button=document.createElement('button');button.type='button';button.className='tag-item block w-full text-right p-2 hover:bg-slate-100 rounded-lg';
        button.textContent=String(tag);button.addEventListener('click',()=>window.addTagToEmployee(empId,tag));container.append(button);
    }
    if(!tags.length&&q) {
        const button=document.createElement('button');button.type='button';button.className='tag-item block w-full text-right p-2 bg-blue-50';button.textContent='إضافة «'+String(query).trim()+'»';
        button.addEventListener('click',()=>window.addCustomTag(empId,String(query).trim()));container.append(button);
    }
}
function integrityA11y(root=document) {
    root.querySelectorAll('button[onclick="window.generateEntDoc(true)"]').forEach(save=>{if(save.parentElement.querySelector('[data-integrity-new-ent]'))return;const button=document.createElement('button');button.type='button';button.dataset.integrityNewEnt='';button.className='border rounded-full px-4 py-2 text-xs font-bold';button.textContent='بدء مستحق جديد';button.addEventListener('click',window.integrityStartNewEntitlement);save.before(button);});
    root.querySelectorAll('input,select,textarea').forEach(el=>{
        if(el.type==='hidden'||el.labels?.length||el.hasAttribute('aria-label')||el.hasAttribute('aria-labelledby')) return;
        const parent=el.parentElement,previous=el.previousElementSibling;
        const label=parent?.querySelector(':scope > label')||previous&&/LABEL|SPAN|P/.test(previous.tagName)&&previous;
        const text=label?.textContent?.trim()||el.getAttribute('placeholder')||el.title;
        if(text) el.setAttribute('aria-label',text);
    });
}
document.addEventListener('DOMContentLoaded',()=>{
    integrityA11y();
    let scheduled=false;
    new MutationObserver(()=>{if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;integrityA11y();});}).observe(document.body,{childList:true,subtree:true});
    let lastModal=null,returnFocus=null;
    document.addEventListener('keydown',e=>{
        if(e.key!=='Tab') return;
        const modal=[...document.querySelectorAll('[id$="-modal"]')].reverse().find(x=>!x.classList.contains('hidden')&&x.getClientRects().length);
        if(!modal) {lastModal=null;return;}
        if(lastModal!==modal) {returnFocus=document.activeElement;lastModal=modal;modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');}
        const items=[...modal.querySelectorAll('button,input,select,textarea,a[href],[tabindex="0"]')].filter(x=>!x.disabled&&x.getClientRects().length);
        if(!items.length)return;
        const first=items[0],last=items.at(-1);
        if(e.shiftKey&&(document.activeElement===first||!modal.contains(document.activeElement))) {e.preventDefault();last.focus();}
        else if(!e.shiftKey&&(document.activeElement===last||!modal.contains(document.activeElement))) {e.preventDefault();first.focus();}
    });
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&lastModal){queueMicrotask(()=>{if(lastModal?.classList.contains('hidden'))returnFocus?.focus();lastModal=null;});}});
});
