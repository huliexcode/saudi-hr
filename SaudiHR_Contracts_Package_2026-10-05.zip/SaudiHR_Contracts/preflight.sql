-- Read-only checks for the actual Supabase schema. Do not print function bodies or credentials.
select version() as postgres_version;
select tablename,rowsecurity from pg_tables where schemaname='public' and tablename in
('companies','company_members','employees','departments','hr_operations','employee_requests','salary_adjustments','employee_attendance','employee_documents','custody_items','document_templates','hr_communications','ask_knowledge','hr_contracts','hr_contract_entries','hr_contract_months') order by tablename;
select table_name,column_name,data_type,is_nullable from information_schema.columns where table_schema='public' and table_name in ('employees','hr_operations','company_members','employee_requests','companies') order by table_name,ordinal_position;
select p.proname,pg_get_function_identity_arguments(p.oid) arguments,p.prosecdef security_definer,pg_get_function_result(p.oid) result_type
from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and (p.proname like 'portal_%' or p.proname like 'hr_contact_%' or p.proname like 'hr_contract_%' or p.proname='hr_portal_contracts' or p.proname in ('accept_company_invites','my_company_ids','next_employee_number','registration_conflicts')) order by p.proname;
select schemaname,tablename,policyname,permissive,roles,cmd from pg_policies where schemaname in ('public','storage') order by schemaname,tablename,policyname;
select id,name,public,file_size_limit,allowed_mime_types from storage.buckets order by id;
-- New fields must be included in the authenticated employee portal response where a reduced JSON projection is used:
-- annual_leave_days, leave_opening_balance, hr_gosi_verified, hr_gosi_evidence.
-- Do not add anonymous raw-table access. Test portal credentials and storage permissions in staging.

-- Contract upgrade: require ISO civil start_date/end_date in the registry; portal_token TEXT and portal_enabled BOOLEAN.
-- Test hr_portal_contracts with one valid employee credential and one invalid credential.
-- Verify hr_contracts_required is true; reviewed historic contracts may be appended but closed snapshots stay unchanged.
