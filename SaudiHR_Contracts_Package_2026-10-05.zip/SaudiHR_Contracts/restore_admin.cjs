/* Restore into an EMPTY company scope in a database with the same schema and Auth accounts.
 * Default: verify only. Execution requires --execute and an administrator DATABASE_URL.
 * Storage and PostgreSQL do not share a transaction: upload/verify storage first, then one DB transaction.
 * Existing storage is never overwritten. A failure leaves added objects for retry, not a partial database.
 */
const fs=require('fs'),crypto=require('crypto');
const tables=['companies','departments','company_members','employees','custody_items','hr_operations','employee_requests','employee_attendance','salary_adjustments','employee_documents','document_templates','hr_communications','ask_knowledge','hr_compensation_versions','hr_contracts','hr_contract_entries','hr_contract_months','hr_payroll_runs','hr_finance_commands','hr_audit_events'];
const child=new Set(['custody_items','salary_adjustments','employee_documents']);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function verify(b){
 if(b?.meta?.version!==2||b.meta.complete!==true||!Array.isArray(b.files)||!b.data)throw Error('Complete v2 backup required');
 const id=b.meta.companyId;if(!/^[0-9a-f-]{36}$/i.test(id||''))throw Error('Invalid company');
 const ids=new Set((b.data.employees||[]).map(e=>e.id));
 for(const t of tables){const rows=b.data[t];if(!Array.isArray(rows)||rows.length!==b.meta.counts[t])throw Error('Missing table/count '+t);const keys=new Set();for(const r of rows){const key=t==='hr_finance_commands'?r.request_id:r.id;if(!key||keys.has(key))throw Error('Invalid/duplicate identity '+t);keys.add(key);if(t==='companies'?r.id!==id:child.has(t)?!ids.has(r.employee_id):r.company_id!==id)throw Error('Cross-tenant record '+t);}}
 if(b.data.companies.length!==1||b.files.length!==b.meta.fileCount||!Number.isSafeInteger(b.meta.totalBytes)||b.meta.totalBytes<0)throw Error('Invalid company/files');
 if(sha(JSON.stringify({data:b.data,files:b.files}))!==b.meta.payloadSha256)throw Error('Payload hash mismatch');
 const fileKeys=new Set();let bytes=0;
 for(const f of b.files){const key=f.bucket+'/'+f.path;if(!['employee-docs','hr-documents','company-assets'].includes(f.bucket)||typeof f.path!=='string'||!f.path||f.path.split('/').some(x=>x==='..'||x==='.')||fileKeys.has(key))throw Error('Invalid/duplicate storage path');fileKeys.add(key);if(!Number.isSafeInteger(f.bytes)||f.bytes<0||typeof f.base64!=='string'||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(f.base64))throw Error('Invalid file encoding/size');const content=Buffer.from(f.base64,'base64');bytes+=content.length;if(content.length!==f.bytes||sha(content)!==f.sha256)throw Error('File hash mismatch');}
 if(bytes!==b.meta.totalBytes)throw Error('File byte total mismatch');return id;
}
async function restoreDatabase(db,b){
 const company=verify(b);await db.query('begin');
 try {
  await db.query('select pg_advisory_xact_lock(hashtext($1))',[company]);
  await db.query("set local lock_timeout='10s'");
  await db.query('lock table '+tables.map(t=>'public."'+t+'"').join(',')+' in share row exclusive mode');
  // No merge into existing data: immutable records and relationships must restore together.
  for(const t of tables.slice(1)){const scope=child.has(t)?'employee_id in (select id from employees where company_id=$1)':'company_id=$1';const r=await db.query(`select count(*)::int n from public."${t}" where ${scope}`,[company]);if(r.rows[0].n)throw Error('Target company scope is not empty: '+t);}
  const co=await db.query('select to_jsonb(c) row from public.companies c where id=$1',[company]);if(co.rows.length&&co.rows[0].row.owner_id!==b.data.companies[0].owner_id)throw Error('Target company owner differs');
  const triggers={};for(const t of tables){triggers[t]=(await db.query('select tgname name,tgenabled enabled from pg_trigger where tgrelid=$1::regclass and not tgisinternal',['public.'+t])).rows;await db.query(`alter table public."${t}" disable trigger user`);}
  await db.query('set constraints all deferred');
  for(const t of tables){let rows=b.data[t];if(!rows.length)continue;
   const meta=await db.query("select a.attname name,a.attgenerated generated from pg_attribute a where a.attrelid=$1::regclass and a.attnum>0 and not a.attisdropped order by a.attnum",['public.'+t]);
   const columns=meta.rows.filter(c=>!c.generated&&rows.some(r=>Object.hasOwn(r,c.name))).map(c=>c.name),known=new Set(meta.rows.map(c=>c.name));
   if(rows.some(r=>Object.keys(r).some(k=>!known.has(k))))throw Error('Backup/schema column mismatch '+t);
   if(t==='companies'&&co.rows.length){const vals=columns.filter(c=>c!=='id').map(c=>`"${c}"=src."${c}"`).join(',');await db.query(`update public.companies c set ${vals} from jsonb_populate_record(null::public.companies,$1::jsonb) src where c.id=src.id`,[JSON.stringify(rows[0])]);}
   else {const cols=columns.map(c=>'"'+c+'"').join(',');await db.query(`insert into public."${t}" (${cols}) overriding system value select ${cols} from jsonb_populate_recordset(null::public."${t}",$1::jsonb)`,[JSON.stringify(rows)]);}
  }
  // The operations identity counter must be ahead of preserved receipt references.
  const seq=await db.query("select pg_get_serial_sequence('public.hr_operations','ref_no') name");if(seq.rows[0]?.name)await db.query('select setval($1::regclass,greatest(coalesce((select max(ref_no) from hr_operations),0)+1,1),false)',[seq.rows[0].name]);
  for(const t of tables)for(const trigger of triggers[t]){const action=trigger.enabled==='D'?'disable':trigger.enabled==='R'?'enable replica':trigger.enabled==='A'?'enable always':'enable';await db.query(`alter table public."${t}" ${action} trigger "${trigger.name.replace(/"/g,'""')}"`);}
  await db.query('commit');return {company,records:tables.reduce((s,t)=>s+b.data[t].length,0)};
 }catch(e){await db.query('rollback');throw e;}
}
async function restoreStorage(b,url,key){
 for(const f of b.files){const encoded=f.path.split('/').map(encodeURIComponent).join('/'),endpoint=url.replace(/\/$/,'')+'/storage/v1/object/'+f.bucket+'/'+encoded,headers={apikey:key,Authorization:'Bearer '+key};let current=await fetch(endpoint,{headers});
  if(current.ok){if(sha(Buffer.from(await current.arrayBuffer()))!==f.sha256)throw Error('Existing storage differs: '+f.path);continue;}
  if(current.status!==404)throw Error('Storage lookup failed '+current.status);
  const put=await fetch(endpoint,{method:'POST',headers:{...headers,'Content-Type':f.metadata?.mimetype||'application/octet-stream','x-upsert':'false'},body:Buffer.from(f.base64,'base64')});if(!put.ok)throw Error('Storage upload failed '+put.status);
  current=await fetch(endpoint,{headers});if(!current.ok||sha(Buffer.from(await current.arrayBuffer()))!==f.sha256)throw Error('Stored object verification failed');
 }
}
module.exports={verify,restoreDatabase,restoreStorage,tables,sha};
if(require.main===module)(async()=>{const file=process.argv[2];if(!file)throw Error('Usage: node restore_admin.cjs backup.json [--execute]');const b=JSON.parse(fs.readFileSync(file));const company=verify(b);console.log('Verified complete backup for '+company);if(!process.argv.includes('--execute'))return;
 if(!process.env.DATABASE_URL)throw Error('Administrator DATABASE_URL required');if(b.files.length&&(!process.env.SUPABASE_URL||!process.env.SUPABASE_SERVICE_ROLE_KEY))throw Error('Storage administrator configuration required');
 if(b.files.length)await restoreStorage(b,process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY);const {Client}=require('pg'),db=new Client({connectionString:process.env.DATABASE_URL});await db.connect();try{console.log(await restoreDatabase(db,b));}finally{await db.end();}
})().catch(e=>{console.error(e.message);process.exitCode=1});
