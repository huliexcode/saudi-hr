const fs=require('fs'),path=require('path'),acorn=require('acorn');const root=__dirname,file=path.join(root,'index_78.html');let html=fs.readFileSync(file,'utf8');
html=html.replace(/(<script id="hr-integrity-core">)[\s\S]*?(<\/script>)/,(_,a,b)=>a+'\n'+fs.readFileSync(path.join(root,'hr_integrity.js'),'utf8')+'\n'+b);
if(!html.includes('id="hr-contract-core"'))html=html.replace('<script id="hr-integrity-core">','<script id="hr-contract-core"></script>\n<script id="hr-integrity-core">');
html=html.replace(/(<script id="hr-contract-core">)[\s\S]*?(<\/script>)/,(_,a,b)=>a+'\n'+fs.readFileSync(path.join(root,'contract_core.js'),'utf8')+'\n'+b);
if(!html.includes('/* HR_CONTRACT_UI_BEGIN */'))html=html.replace('/* HR_UI_BEGIN */','/* HR_CONTRACT_UI_BEGIN *//* HR_CONTRACT_UI_END */\n/* HR_UI_BEGIN */');
for(const [mark,source]of [['HR_UI','integrity_ui.js'],['HR_BACKUP','backup_integrity.js'],['HR_CONTRACT_UI','contract_ui.js']]){const re=new RegExp('/\\* '+mark+'_BEGIN \\*/[\\s\\S]*?/\\* '+mark+'_END \\*/');if(!re.test(html))throw Error('Build marker missing '+mark);html=html.replace(re,()=>`/* ${mark}_BEGIN */\n${fs.readFileSync(path.join(root,source),'utf8')}\n/* ${mark}_END */`);}
for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/g)){if(!/src=/.test(m[1]))acorn.parse(m[2],{ecmaVersion:'latest'});}
fs.writeFileSync(file,html);console.log('Embedded sources and parsed every inline script');
